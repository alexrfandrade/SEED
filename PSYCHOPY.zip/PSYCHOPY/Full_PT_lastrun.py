#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
This experiment was created using PsychoPy3 Experiment Builder (v2025.2.4),
    on fevereiro 03, 2026, at 11:50
If you publish work using this script the most relevant publication is:

    Peirce J, Gray JR, Simpson S, MacAskill M, Höchenberger R, Sogo H, Kastman E, Lindeløv JK. (2019) 
        PsychoPy2: Experiments in behavior made easy Behav Res 51: 195. 
        https://doi.org/10.3758/s13428-018-01193-y

"""

# --- Import packages ---
from psychopy import locale_setup
from psychopy import prefs
from psychopy import plugins
plugins.activatePlugins()
from psychopy import sound, gui, visual, core, data, event, logging, clock, colors, layout, hardware
from psychopy.tools import environmenttools
from psychopy.constants import (
    NOT_STARTED, STARTED, PLAYING, PAUSED, STOPPED, STOPPING, FINISHED, PRESSED, 
    RELEASED, FOREVER, priority
)

import numpy as np  # whole numpy lib is available, prepend 'np.'
from numpy import (sin, cos, tan, log, log10, pi, average,
                   sqrt, std, deg2rad, rad2deg, linspace, asarray)
from numpy.random import random, randint, normal, shuffle, choice as randchoice
import os  # handy system and path functions
import sys  # to get file system encoding

from psychopy.hardware import keyboard

# --- Setup global variables (available in all functions) ---
# create a device manager to handle hardware (keyboards, mice, mirophones, speakers, etc.)
deviceManager = hardware.DeviceManager()
# ensure that relative paths start from the same directory as this script
_thisDir = os.path.dirname(os.path.abspath(__file__))
# store info about the experiment session
psychopyVersion = '2025.2.4'
expName = 'Full_PT'  # from the Builder filename that created this script
expVersion = ''
# a list of functions to run when the experiment ends (starts off blank)
runAtExit = []
# information about this experiment
expInfo = {
    'participant': f"{randint(0, 999999):06.0f}",
    'session': '001',
    'date|hid': data.getDateStr(),
    'expName|hid': expName,
    'expVersion|hid': expVersion,
    'psychopyVersion|hid': psychopyVersion,
}

# --- Define some variables which will change depending on pilot mode ---
'''
To run in pilot mode, either use the run/pilot toggle in Builder, Coder and Runner, 
or run the experiment with `--pilot` as an argument. To change what pilot 
#mode does, check out the 'Pilot mode' tab in preferences.
'''
# work out from system args whether we are running in pilot mode
PILOTING = core.setPilotModeFromArgs()
# start off with values from experiment settings
_fullScr = True
_winSize = [1440, 900]
# if in pilot mode, apply overrides according to preferences
if PILOTING:
    # force windowed mode
    if prefs.piloting['forceWindowed']:
        _fullScr = False
        # set window size
        _winSize = prefs.piloting['forcedWindowSize']
    # replace default participant ID
    if prefs.piloting['replaceParticipantID']:
        expInfo['participant'] = 'pilot'

def showExpInfoDlg(expInfo):
    """
    Show participant info dialog.
    Parameters
    ==========
    expInfo : dict
        Information about this experiment.
    
    Returns
    ==========
    dict
        Information about this experiment.
    """
    # show participant info dialog
    dlg = gui.DlgFromDict(
        dictionary=expInfo, sortKeys=False, title=expName, alwaysOnTop=True
    )
    if dlg.OK == False:
        core.quit()  # user pressed cancel
    # return expInfo
    return expInfo


def setupData(expInfo, dataDir=None):
    """
    Make an ExperimentHandler to handle trials and saving.
    
    Parameters
    ==========
    expInfo : dict
        Information about this experiment, created by the `setupExpInfo` function.
    dataDir : Path, str or None
        Folder to save the data to, leave as None to create a folder in the current directory.    
    Returns
    ==========
    psychopy.data.ExperimentHandler
        Handler object for this experiment, contains the data to save and information about 
        where to save it to.
    """
    # remove dialog-specific syntax from expInfo
    for key, val in expInfo.copy().items():
        newKey, _ = data.utils.parsePipeSyntax(key)
        expInfo[newKey] = expInfo.pop(key)
    
    # data file name stem = absolute path + name; later add .psyexp, .csv, .log, etc
    if dataDir is None:
        dataDir = _thisDir
    filename = u'data/%s_%s_%s' % (expInfo['participant'], expName, expInfo['date'])
    # make sure filename is relative to dataDir
    if os.path.isabs(filename):
        dataDir = os.path.commonprefix([dataDir, filename])
        filename = os.path.relpath(filename, dataDir)
    
    # an ExperimentHandler isn't essential but helps with data saving
    thisExp = data.ExperimentHandler(
        name=expName, version=expVersion,
        extraInfo=expInfo, runtimeInfo=None,
        originPath='C:\\Users\\Utilizador\\Desktop\\PSYCHOPY\\Full_PT_lastrun.py',
        savePickle=True, saveWideText=True,
        dataFileName=dataDir + os.sep + filename, sortColumns='time'
    )
    thisExp.setPriority('thisRow.t', priority.CRITICAL)
    thisExp.setPriority('expName', priority.LOW)
    # return experiment handler
    return thisExp


def setupLogging(filename):
    """
    Setup a log file and tell it what level to log at.
    
    Parameters
    ==========
    filename : str or pathlib.Path
        Filename to save log file and data files as, doesn't need an extension.
    
    Returns
    ==========
    psychopy.logging.LogFile
        Text stream to receive inputs from the logging system.
    """
    # set how much information should be printed to the console / app
    if PILOTING:
        logging.console.setLevel(
            prefs.piloting['pilotConsoleLoggingLevel']
        )
    else:
        logging.console.setLevel('warning')
    # save a log file for detail verbose info
    logFile = logging.LogFile(filename+'.log')
    if PILOTING:
        logFile.setLevel(
            prefs.piloting['pilotLoggingLevel']
        )
    else:
        logFile.setLevel(
            logging.getLevel('info')
        )
    
    return logFile


def setupWindow(expInfo=None, win=None):
    """
    Setup the Window
    
    Parameters
    ==========
    expInfo : dict
        Information about this experiment, created by the `setupExpInfo` function.
    win : psychopy.visual.Window
        Window to setup - leave as None to create a new window.
    
    Returns
    ==========
    psychopy.visual.Window
        Window in which to run this experiment.
    """
    if PILOTING:
        logging.debug('Fullscreen settings ignored as running in pilot mode.')
    
    if win is None:
        # if not given a window to setup, make one
        win = visual.Window(
            size=_winSize, fullscr=_fullScr, screen=0,
            winType='pyglet', allowGUI=True, allowStencil=False,
            monitor='testMonitor', color=[0,0,0], colorSpace='rgb',
            backgroundImage='', backgroundFit='none',
            blendMode='avg', useFBO=True,
            units='height',
            checkTiming=False  # we're going to do this ourselves in a moment
        )
    else:
        # if we have a window, just set the attributes which are safe to set
        win.color = [0,0,0]
        win.colorSpace = 'rgb'
        win.backgroundImage = ''
        win.backgroundFit = 'none'
        win.units = 'height'
    if expInfo is not None:
        # get/measure frame rate if not already in expInfo
        if win._monitorFrameRate is None:
            win._monitorFrameRate = win.getActualFrameRate(infoMsg='Attempting to measure frame rate of screen, please wait...')
        expInfo['frameRate'] = win._monitorFrameRate
    win.hideMessage()
    if PILOTING:
        # show a visual indicator if we're in piloting mode
        if prefs.piloting['showPilotingIndicator']:
            win.showPilotingIndicator()
        # always show the mouse in piloting mode
        if prefs.piloting['forceMouseVisible']:
            win.mouseVisible = True
    
    return win


def setupDevices(expInfo, thisExp, win):
    """
    Setup whatever devices are available (mouse, keyboard, speaker, eyetracker, etc.) and add them to 
    the device manager (deviceManager)
    
    Parameters
    ==========
    expInfo : dict
        Information about this experiment, created by the `setupExpInfo` function.
    thisExp : psychopy.data.ExperimentHandler
        Handler object for this experiment, contains the data to save and information about 
        where to save it to.
    win : psychopy.visual.Window
        Window in which to run this experiment.
    Returns
    ==========
    bool
        True if completed successfully.
    """
    # --- Setup input devices ---
    ioConfig = {}
    ioSession = ioServer = eyetracker = None
    
    # store ioServer object in the device manager
    deviceManager.ioServer = ioServer
    
    # create a default keyboard (e.g. to check for escape)
    if deviceManager.getDevice('defaultKeyboard') is None:
        deviceManager.addDevice(
            deviceClass='keyboard', deviceName='defaultKeyboard', backend='ptb'
        )
    # return True if completed successfully
    return True

def pauseExperiment(thisExp, win=None, timers=[], currentRoutine=None):
    """
    Pause this experiment, preventing the flow from advancing to the next routine until resumed.
    
    Parameters
    ==========
    thisExp : psychopy.data.ExperimentHandler
        Handler object for this experiment, contains the data to save and information about 
        where to save it to.
    win : psychopy.visual.Window
        Window for this experiment.
    timers : list, tuple
        List of timers to reset once pausing is finished.
    currentRoutine : psychopy.data.Routine
        Current Routine we are in at time of pausing, if any. This object tells PsychoPy what Components to pause/play/dispatch.
    """
    # if we are not paused, do nothing
    if thisExp.status != PAUSED:
        return
    
    # start a timer to figure out how long we're paused for
    pauseTimer = core.Clock()
    # pause any playback components
    if currentRoutine is not None:
        for comp in currentRoutine.getPlaybackComponents():
            comp.pause()
    # make sure we have a keyboard
    defaultKeyboard = deviceManager.getDevice('defaultKeyboard')
    if defaultKeyboard is None:
        defaultKeyboard = deviceManager.addKeyboard(
            deviceClass='keyboard',
            deviceName='defaultKeyboard',
            backend='PsychToolbox',
        )
    # run a while loop while we wait to unpause
    while thisExp.status == PAUSED:
        # check for quit (typically the Esc key)
        if defaultKeyboard.getKeys(keyList=['escape']):
            endExperiment(thisExp, win=win)
        # dispatch messages on response components
        if currentRoutine is not None:
            for comp in currentRoutine.getDispatchComponents():
                comp.device.dispatchMessages()
        # sleep 1ms so other threads can execute
        clock.time.sleep(0.001)
    # if stop was requested while paused, quit
    if thisExp.status == FINISHED:
        endExperiment(thisExp, win=win)
    # resume any playback components
    if currentRoutine is not None:
        for comp in currentRoutine.getPlaybackComponents():
            comp.play()
    # reset any timers
    for timer in timers:
        timer.addTime(-pauseTimer.getTime())


def run(expInfo, thisExp, win, globalClock=None, thisSession=None):
    """
    Run the experiment flow.
    
    Parameters
    ==========
    expInfo : dict
        Information about this experiment, created by the `setupExpInfo` function.
    thisExp : psychopy.data.ExperimentHandler
        Handler object for this experiment, contains the data to save and information about 
        where to save it to.
    psychopy.visual.Window
        Window in which to run this experiment.
    globalClock : psychopy.core.clock.Clock or None
        Clock to get global time from - supply None to make a new one.
    thisSession : psychopy.session.Session or None
        Handle of the Session object this experiment is being run from, if any.
    """
    # mark experiment as started
    thisExp.status = STARTED
    # update experiment info
    expInfo['date'] = data.getDateStr()
    expInfo['expName'] = expName
    expInfo['expVersion'] = expVersion
    expInfo['psychopyVersion'] = psychopyVersion
    # make sure window is set to foreground to prevent losing focus
    win.winHandle.activate()
    # make sure variables created by exec are available globally
    exec = environmenttools.setExecEnvironment(globals())
    # get device handles from dict of input devices
    ioServer = deviceManager.ioServer
    # get/create a default keyboard (e.g. to check for escape)
    defaultKeyboard = deviceManager.getDevice('defaultKeyboard')
    if defaultKeyboard is None:
        deviceManager.addDevice(
            deviceClass='keyboard', deviceName='defaultKeyboard', backend='PsychToolbox'
        )
    eyetracker = deviceManager.getDevice('eyetracker')
    # make sure we're running in the directory for this experiment
    os.chdir(_thisDir)
    # get filename from ExperimentHandler for convenience
    filename = thisExp.dataFileName
    frameTolerance = 0.001  # how close to onset before 'same' frame
    endExpNow = False  # flag for 'escape' or other condition => quit the exp
    # get frame duration from frame rate in expInfo
    if 'frameRate' in expInfo and expInfo['frameRate'] is not None:
        frameDur = 1.0 / round(expInfo['frameRate'])
    else:
        frameDur = 1.0 / 60.0  # could not measure, so guess
    
    # Start Code - component code to be run after the window creation
    
    # --- Initialize components for Routine "Welcome" ---
    text_hi = visual.TextStim(win=win, name='text_hi',
        text='Bem-vindo!\n\nObrigada por participar nesta experiência.\n\n\n\nPrime ESPAÇO para avançar',
        font='Arial',
        pos=(0, 0), draggable=False, height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=0.0);
    key_welcome = keyboard.Keyboard(deviceName='defaultKeyboard')
    
    # --- Initialize components for Routine "Explanation_PAL" ---
    text_Explain_PAL = visual.TextStim(win=win, name='text_Explain_PAL',
        text='Vais ver duas imagens :\n uma cena e um objeto. \n\nDECORA O PAR DE IMAGENS!\n\n Mais tarde vamos testar se te lembras destes pares de imagens.\n\nPrime ESPAÇO para avançar',
        font='Arial',
        pos=(0, 0), draggable=False, height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=0.0);
    key_start_example = keyboard.Keyboard(deviceName='defaultKeyboard')
    
    # --- Initialize components for Routine "Explain_Rating" ---
    text_explain_rate = visual.TextStim(win=win, name='text_explain_rate',
        text='Ao fim de 2,5 segundos, vai aparecer uma barra de avaliação de 1 a 5.\nPedimos que seleciones o nível de congruência/compatibilidade entre as duas imagens.\n\n1- Incongruente\n5- Congruente\n\n\nPrime ESPAÇO para um exemplo',
        font='Arial',
        pos=(0, 0), draggable=False, height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=0.0);
    key_explainPAL = keyboard.Keyboard(deviceName='defaultKeyboard')
    
    # --- Initialize components for Routine "Example_PAL" ---
    image_ex_scene = visual.ImageStim(
        win=win,
        name='image_ex_scene', units='pix', 
        image='default.png', mask=None, anchor='center',
        ori=0.0, pos=(-200,0), draggable=False, size=1.0,
        color=[1,1,1], colorSpace='rgb', opacity=None,
        flipHoriz=False, flipVert=False,
        texRes=128.0, interpolate=True, depth=0.0)
    image_ex_object = visual.ImageStim(
        win=win,
        name='image_ex_object', units='pix', 
        image='default.png', mask=None, anchor='center',
        ori=0.0, pos=(300, 0), draggable=False, size=1.0,
        color=[1,1,1], colorSpace='rgb', opacity=None,
        flipHoriz=False, flipVert=False,
        texRes=128.0, interpolate=True, depth=-1.0)
    slider_example = visual.Slider(win=win, name='slider_example',
        startValue=None, size=(0.8, 0.05), pos=(0, -0.35), units=win.units,
        labels=['1','2','3','4','5'], ticks=(1, 2, 3, 4, 5), granularity=1.0,
        style='rating', styleTweaks=(), opacity=None,
        labelColor='LightGray', markerColor='Red', lineColor='White', colorSpace='rgb',
        font='Open Sans', labelHeight=0.05,
        flip=False, ori=0.0, depth=-2, readOnly=False)
    text_example = visual.TextStim(win=win, name='text_example',
        text='Qual o nível de congruência/compatibilidade entre as duas imagens?\n1- Incongruente                 5 - Congruente',
        font='Arial',
        pos=(0, 0.35), draggable=False, height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-3.0);
    
    # --- Initialize components for Routine "blank" ---
    cross_25 = visual.ShapeStim(
        win=win, name='cross_25', vertices='cross',
        size=(0.25, 0.25),
        ori=0.0, pos=(0, 0), draggable=False, anchor='center',
        lineWidth=1.0,
        colorSpace='rgb', lineColor='white', fillColor='white',
        opacity=None, depth=0.0, interpolate=True)
    image_blank = visual.ImageStim(
        win=win,
        name='image_blank', 
        image=None, mask=None, anchor='center',
        ori=0.0, pos=(0, 0), draggable=False, size=(0.5, 0.5),
        color=[1,1,1], colorSpace='rgb', opacity=None,
        flipHoriz=False, flipVert=False,
        texRes=128.0, interpolate=True, depth=-1.0)
    
    # --- Initialize components for Routine "Start_PAL" ---
    text_end_ex = visual.TextStim(win=win, name='text_end_ex',
        text='Exemplo concluído.\n\n',
        font='Arial',
        pos=(0, 0), draggable=False, height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=0.0);
    text_start_PAL = visual.TextStim(win=win, name='text_start_PAL',
        text='Vamos começar?\n\nPrime a tecla ESPAÇO quando estiveres pronto\nSe tiveres alguma dúvida chama o experimentador.',
        font='Arial',
        pos=(0, 0), draggable=False, height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-1.0);
    key_start_PAL = keyboard.Keyboard(deviceName='defaultKeyboard')
    
    # --- Initialize components for Routine "Encode" ---
    image_scene_encode = visual.ImageStim(
        win=win,
        name='image_scene_encode', units='pix', 
        image='default.png', mask=None, anchor='center',
        ori=0.0, pos=(-200, 0), draggable=False, size=1.0,
        color=[1,1,1], colorSpace='rgb', opacity=None,
        flipHoriz=False, flipVert=False,
        texRes=128.0, interpolate=True, depth=0.0)
    image_object_encode = visual.ImageStim(
        win=win,
        name='image_object_encode', units='pix', 
        image='default.png', mask=None, anchor='center',
        ori=0.0, pos=(300, 0), draggable=False, size=1.0,
        color=[1,1,1], colorSpace='rgb', opacity=None,
        flipHoriz=False, flipVert=False,
        texRes=128.0, interpolate=True, depth=-1.0)
    text_rating = visual.TextStim(win=win, name='text_rating',
        text='Qual o nível de congruência entre o par?\n1 - Incongruente        5- Congruente',
        font='Arial',
        pos=(0, 0.35), draggable=False, height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-3.0);
    slider_cong = visual.Slider(win=win, name='slider_cong',
        startValue=None, size=(0.8, 0.05), pos=(0, -0.35), units=win.units,
        labels=['1','2','3','4','5'], ticks=(1, 2, 3, 4, 5), granularity=1.0,
        style='rating', styleTweaks=(), opacity=None,
        labelColor='LightGray', markerColor='Red', lineColor='White', colorSpace='rgb',
        font='Ariel', labelHeight=0.05,
        flip=False, ori=0.0, depth=-4, readOnly=False)
    
    # --- Initialize components for Routine "blank" ---
    cross_25 = visual.ShapeStim(
        win=win, name='cross_25', vertices='cross',
        size=(0.25, 0.25),
        ori=0.0, pos=(0, 0), draggable=False, anchor='center',
        lineWidth=1.0,
        colorSpace='rgb', lineColor='white', fillColor='white',
        opacity=None, depth=0.0, interpolate=True)
    image_blank = visual.ImageStim(
        win=win,
        name='image_blank', 
        image=None, mask=None, anchor='center',
        ori=0.0, pos=(0, 0), draggable=False, size=(0.5, 0.5),
        color=[1,1,1], colorSpace='rgb', opacity=None,
        flipHoriz=False, flipVert=False,
        texRes=128.0, interpolate=True, depth=-1.0)
    
    # --- Initialize components for Routine "Pause_1" ---
    text_pausa1 = visual.TextStim(win=win, name='text_pausa1',
        text='A primeira parte está concluída. Bom trabalho!\n\nPrime ESPAÇO quando estiveres pronto para a próxima tarefa.',
        font='Arial',
        pos=(0, 0), draggable=False, height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=0.0);
    key_Start_Cog = keyboard.Keyboard(deviceName='defaultKeyboard')
    
    # --- Initialize components for Routine "Explanation_GoNo" ---
    text_explanation_GoNo = visual.TextStim(win=win, name='text_explanation_GoNo',
        text='INSERT EXPLANATION GO/NO-GO',
        font='Arial',
        pos=(0, 0), draggable=False, height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=0.0);
        
        
    ##Raquel

#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
This experiment was created using PsychoPy3 Experiment Builder (v2025.2.4),
    on fevereiro 03, 2026, at 11:50
If you publish work using this script the most relevant publication is:

    Peirce J, Gray JR, Simpson S, MacAskill M, Höchenberger R, Sogo H, Kastman E, Lindeløv JK. (2019) 
        PsychoPy2: Experiments in behavior made easy Behav Res 51: 195. 
        https://doi.org/10.3758/s13428-018-01193-y

"""

# --- Import packages ---
from psychopy import locale_setup
from psychopy import prefs
from psychopy import plugins
plugins.activatePlugins()
from psychopy import sound, gui, visual, core, data, event, logging, clock, colors, layout, hardware
from psychopy.tools import environmenttools
from psychopy.constants import (
    NOT_STARTED, STARTED, PLAYING, PAUSED, STOPPED, STOPPING, FINISHED, PRESSED, 
    RELEASED, FOREVER, priority
)

import numpy as np  # whole numpy lib is available, prepend 'np.'
from numpy import (sin, cos, tan, log, log10, pi, average,
                   sqrt, std, deg2rad, rad2deg, linspace, asarray)
from numpy.random import random, randint, normal, shuffle, choice as randchoice
import os  # handy system and path functions
import sys  # to get file system encoding

from psychopy.hardware import keyboard

# --- Setup global variables (available in all functions) ---
# create a device manager to handle hardware (keyboards, mice, mirophones, speakers, etc.)
deviceManager = hardware.DeviceManager()
# ensure that relative paths start from the same directory as this script
_thisDir = os.path.dirname(os.path.abspath(__file__))
# store info about the experiment session
psychopyVersion = '2025.2.4'
expName = 'Full_PT'  # from the Builder filename that created this script
expVersion = ''
# a list of functions to run when the experiment ends (starts off blank)
runAtExit = []
# information about this experiment
expInfo = {
    'participant': f"{randint(0, 999999):06.0f}",
    'session': '001',
    'date|hid': data.getDateStr(),
    'expName|hid': expName,
    'expVersion|hid': expVersion,
    'psychopyVersion|hid': psychopyVersion,
}

# --- Define some variables which will change depending on pilot mode ---
'''
To run in pilot mode, either use the run/pilot toggle in Builder, Coder and Runner, 
or run the experiment with `--pilot` as an argument. To change what pilot 
#mode does, check out the 'Pilot mode' tab in preferences.
'''
# work out from system args whether we are running in pilot mode
PILOTING = core.setPilotModeFromArgs()
# start off with values from experiment settings
_fullScr = True
_winSize = [1440, 900]
# if in pilot mode, apply overrides according to preferences
if PILOTING:
    # force windowed mode
    if prefs.piloting['forceWindowed']:
        _fullScr = False
        # set window size
        _winSize = prefs.piloting['forcedWindowSize']
    # replace default participant ID
    if prefs.piloting['replaceParticipantID']:
        expInfo['participant'] = 'pilot'

def showExpInfoDlg(expInfo):
    """
    Show participant info dialog.
    Parameters
    ==========
    expInfo : dict
        Information about this experiment.
    
    Returns
    ==========
    dict
        Information about this experiment.
    """
    # show participant info dialog
    dlg = gui.DlgFromDict(
        dictionary=expInfo, sortKeys=False, title=expName, alwaysOnTop=True
    )
    if dlg.OK == False:
        core.quit()  # user pressed cancel
    # return expInfo
    return expInfo


def setupData(expInfo, dataDir=None):
    """
    Make an ExperimentHandler to handle trials and saving.
    
    Parameters
    ==========
    expInfo : dict
        Information about this experiment, created by the `setupExpInfo` function.
    dataDir : Path, str or None
        Folder to save the data to, leave as None to create a folder in the current directory.    
    Returns
    ==========
    psychopy.data.ExperimentHandler
        Handler object for this experiment, contains the data to save and information about 
        where to save it to.
    """
    # remove dialog-specific syntax from expInfo
    for key, val in expInfo.copy().items():
        newKey, _ = data.utils.parsePipeSyntax(key)
        expInfo[newKey] = expInfo.pop(key)
    
    # data file name stem = absolute path + name; later add .psyexp, .csv, .log, etc
    if dataDir is None:
        dataDir = _thisDir
    filename = u'data/%s_%s_%s' % (expInfo['participant'], expName, expInfo['date'])
    # make sure filename is relative to dataDir
    if os.path.isabs(filename):
        dataDir = os.path.commonprefix([dataDir, filename])
        filename = os.path.relpath(filename, dataDir)
    
    # an ExperimentHandler isn't essential but helps with data saving
    thisExp = data.ExperimentHandler(
        name=expName, version=expVersion,
        extraInfo=expInfo, runtimeInfo=None,
        originPath='C:\\Users\\Utilizador\\Desktop\\PSYCHOPY\\Full_PT_lastrun.py',
        savePickle=True, saveWideText=True,
        dataFileName=dataDir + os.sep + filename, sortColumns='time'
    )
    thisExp.setPriority('thisRow.t', priority.CRITICAL)
    thisExp.setPriority('expName', priority.LOW)
    # return experiment handler
    return thisExp


def setupLogging(filename):
    """
    Setup a log file and tell it what level to log at.
    
    Parameters
    ==========
    filename : str or pathlib.Path
        Filename to save log file and data files as, doesn't need an extension.
    
    Returns
    ==========
    psychopy.logging.LogFile
        Text stream to receive inputs from the logging system.
    """
    # set how much information should be printed to the console / app
    if PILOTING:
        logging.console.setLevel(
            prefs.piloting['pilotConsoleLoggingLevel']
        )
    else:
        logging.console.setLevel('warning')
    # save a log file for detail verbose info
    logFile = logging.LogFile(filename+'.log')
    if PILOTING:
        logFile.setLevel(
            prefs.piloting['pilotLoggingLevel']
        )
    else:
        logFile.setLevel(
            logging.getLevel('info')
        )
    
    return logFile


def setupWindow(expInfo=None, win=None):
    """
    Setup the Window
    
    Parameters
    ==========
    expInfo : dict
        Information about this experiment, created by the `setupExpInfo` function.
    win : psychopy.visual.Window
        Window to setup - leave as None to create a new window.
    
    Returns
    ==========
    psychopy.visual.Window
        Window in which to run this experiment.
    """
    if PILOTING:
        logging.debug('Fullscreen settings ignored as running in pilot mode.')
    
    if win is None:
        # if not given a window to setup, make one
        win = visual.Window(
            size=_winSize, fullscr=_fullScr, screen=0,
            winType='pyglet', allowGUI=True, allowStencil=False,
            monitor='testMonitor', color=[0,0,0], colorSpace='rgb',
            backgroundImage='', backgroundFit='none',
            blendMode='avg', useFBO=True,
            units='height',
            checkTiming=False  # we're going to do this ourselves in a moment
        )
    else:
        # if we have a window, just set the attributes which are safe to set
        win.color = [0,0,0]
        win.colorSpace = 'rgb'
        win.backgroundImage = ''
        win.backgroundFit = 'none'
        win.units = 'height'
    if expInfo is not None:
        # get/measure frame rate if not already in expInfo
        if win._monitorFrameRate is None:
            win._monitorFrameRate = win.getActualFrameRate(infoMsg='Attempting to measure frame rate of screen, please wait...')
        expInfo['frameRate'] = win._monitorFrameRate
    win.hideMessage()
    if PILOTING:
        # show a visual indicator if we're in piloting mode
        if prefs.piloting['showPilotingIndicator']:
            win.showPilotingIndicator()
        # always show the mouse in piloting mode
        if prefs.piloting['forceMouseVisible']:
            win.mouseVisible = True
    
    return win


def setupDevices(expInfo, thisExp, win):
    """
    Setup whatever devices are available (mouse, keyboard, speaker, eyetracker, etc.) and add them to 
    the device manager (deviceManager)
    
    Parameters
    ==========
    expInfo : dict
        Information about this experiment, created by the `setupExpInfo` function.
    thisExp : psychopy.data.ExperimentHandler
        Handler object for this experiment, contains the data to save and information about 
        where to save it to.
    win : psychopy.visual.Window
        Window in which to run this experiment.
    Returns
    ==========
    bool
        True if completed successfully.
    """
    # --- Setup input devices ---
    ioConfig = {}
    ioSession = ioServer = eyetracker = None
    
    # store ioServer object in the device manager
    deviceManager.ioServer = ioServer
    
    # create a default keyboard (e.g. to check for escape)
    if deviceManager.getDevice('defaultKeyboard') is None:
        deviceManager.addDevice(
            deviceClass='keyboard', deviceName='defaultKeyboard', backend='ptb'
        )
    # return True if completed successfully
    return True

def pauseExperiment(thisExp, win=None, timers=[], currentRoutine=None):
    """
    Pause this experiment, preventing the flow from advancing to the next routine until resumed.
    
    Parameters
    ==========
    thisExp : psychopy.data.ExperimentHandler
        Handler object for this experiment, contains the data to save and information about 
        where to save it to.
    win : psychopy.visual.Window
        Window for this experiment.
    timers : list, tuple
        List of timers to reset once pausing is finished.
    currentRoutine : psychopy.data.Routine
        Current Routine we are in at time of pausing, if any. This object tells PsychoPy what Components to pause/play/dispatch.
    """
    # if we are not paused, do nothing
    if thisExp.status != PAUSED:
        return
    
    # start a timer to figure out how long we're paused for
    pauseTimer = core.Clock()
    # pause any playback components
    if currentRoutine is not None:
        for comp in currentRoutine.getPlaybackComponents():
            comp.pause()
    # make sure we have a keyboard
    defaultKeyboard = deviceManager.getDevice('defaultKeyboard')
    if defaultKeyboard is None:
        defaultKeyboard = deviceManager.addKeyboard(
            deviceClass='keyboard',
            deviceName='defaultKeyboard',
            backend='PsychToolbox',
        )
    # run a while loop while we wait to unpause
    while thisExp.status == PAUSED:
        # check for quit (typically the Esc key)
        if defaultKeyboard.getKeys(keyList=['escape']):
            endExperiment(thisExp, win=win)
        # dispatch messages on response components
        if currentRoutine is not None:
            for comp in currentRoutine.getDispatchComponents():
                comp.device.dispatchMessages()
        # sleep 1ms so other threads can execute
        clock.time.sleep(0.001)
    # if stop was requested while paused, quit
    if thisExp.status == FINISHED:
        endExperiment(thisExp, win=win)
    # resume any playback components
    if currentRoutine is not None:
        for comp in currentRoutine.getPlaybackComponents():
            comp.play()
    # reset any timers
    for timer in timers:
        timer.addTime(-pauseTimer.getTime())


def run(expInfo, thisExp, win, globalClock=None, thisSession=None):
    """
    Run the experiment flow.
    
    Parameters
    ==========
    expInfo : dict
        Information about this experiment, created by the `setupExpInfo` function.
    thisExp : psychopy.data.ExperimentHandler
        Handler object for this experiment, contains the data to save and information about 
        where to save it to.
    psychopy.visual.Window
        Window in which to run this experiment.
    globalClock : psychopy.core.clock.Clock or None
        Clock to get global time from - supply None to make a new one.
    thisSession : psychopy.session.Session or None
        Handle of the Session object this experiment is being run from, if any.
    """
    # mark experiment as started
    thisExp.status = STARTED
    # update experiment info
    expInfo['date'] = data.getDateStr()
    expInfo['expName'] = expName
    expInfo['expVersion'] = expVersion
    expInfo['psychopyVersion'] = psychopyVersion
    # make sure window is set to foreground to prevent losing focus
    win.winHandle.activate()
    # make sure variables created by exec are available globally
    exec = environmenttools.setExecEnvironment(globals())
    # get device handles from dict of input devices
    ioServer = deviceManager.ioServer
    # get/create a default keyboard (e.g. to check for escape)
    defaultKeyboard = deviceManager.getDevice('defaultKeyboard')
    if defaultKeyboard is None:
        deviceManager.addDevice(
            deviceClass='keyboard', deviceName='defaultKeyboard', backend='PsychToolbox'
        )
    eyetracker = deviceManager.getDevice('eyetracker')
    # make sure we're running in the directory for this experiment
    os.chdir(_thisDir)
    # get filename from ExperimentHandler for convenience
    filename = thisExp.dataFileName
    frameTolerance = 0.001  # how close to onset before 'same' frame
    endExpNow = False  # flag for 'escape' or other condition => quit the exp
    # get frame duration from frame rate in expInfo
    if 'frameRate' in expInfo and expInfo['frameRate'] is not None:
        frameDur = 1.0 / round(expInfo['frameRate'])
    else:
        frameDur = 1.0 / 60.0  # could not measure, so guess
    
    # Start Code - component code to be run after the window creation
    
    # --- Initialize components for Routine "Welcome" ---
    text_hi = visual.TextStim(win=win, name='text_hi',
        text='Bem-vindo!\n\nObrigada por participar nesta experiência.\n\n\n\nPrime ESPAÇO para avançar',
        font='Arial',
        pos=(0, 0), draggable=False, height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=0.0);
    key_welcome = keyboard.Keyboard(deviceName='defaultKeyboard')
    
    # --- Initialize components for Routine "Explanation_PAL" ---
    text_Explain_PAL = visual.TextStim(win=win, name='text_Explain_PAL',
        text='Vais ver duas imagens :\n uma cena e um objeto. \n\nDECORA O PAR DE IMAGENS!\n\n Mais tarde vamos testar se te lembras destes pares de imagens.\n\nPrime ESPAÇO para avançar',
        font='Arial',
        pos=(0, 0), draggable=False, height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=0.0);
    key_start_example = keyboard.Keyboard(deviceName='defaultKeyboard')
    
    # --- Initialize components for Routine "Explain_Rating" ---
    text_explain_rate = visual.TextStim(win=win, name='text_explain_rate',
        text='Ao fim de 2,5 segundos, vai aparecer uma barra de avaliação de 1 a 5.\nPedimos que seleciones o nível de congruência/compatibilidade entre as duas imagens.\n\n1- Incongruente\n5- Congruente\n\n\nPrime ESPAÇO para um exemplo',
        font='Arial',
        pos=(0, 0), draggable=False, height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=0.0);
    key_explainPAL = keyboard.Keyboard(deviceName='defaultKeyboard')
    
    # --- Initialize components for Routine "Example_PAL" ---
    image_ex_scene = visual.ImageStim(
        win=win,
        name='image_ex_scene', units='pix', 
        image='default.png', mask=None, anchor='center',
        ori=0.0, pos=(-200,0), draggable=False, size=1.0,
        color=[1,1,1], colorSpace='rgb', opacity=None,
        flipHoriz=False, flipVert=False,
        texRes=128.0, interpolate=True, depth=0.0)
    image_ex_object = visual.ImageStim(
        win=win,
        name='image_ex_object', units='pix', 
        image='default.png', mask=None, anchor='center',
        ori=0.0, pos=(300, 0), draggable=False, size=1.0,
        color=[1,1,1], colorSpace='rgb', opacity=None,
        flipHoriz=False, flipVert=False,
        texRes=128.0, interpolate=True, depth=-1.0)
    slider_example = visual.Slider(win=win, name='slider_example',
        startValue=None, size=(0.8, 0.05), pos=(0, -0.35), units=win.units,
        labels=['1','2','3','4','5'], ticks=(1, 2, 3, 4, 5), granularity=1.0,
        style='rating', styleTweaks=(), opacity=None,
        labelColor='LightGray', markerColor='Red', lineColor='White', colorSpace='rgb',
        font='Open Sans', labelHeight=0.05,
        flip=False, ori=0.0, depth=-2, readOnly=False)
    text_example = visual.TextStim(win=win, name='text_example',
        text='Qual o nível de congruência/compatibilidade entre as duas imagens?\n1- Incongruente                 5 - Congruente',
        font='Arial',
        pos=(0, 0.35), draggable=False, height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-3.0);
    
    # --- Initialize components for Routine "blank" ---
    cross_25 = visual.ShapeStim(
        win=win, name='cross_25', vertices='cross',
        size=(0.25, 0.25),
        ori=0.0, pos=(0, 0), draggable=False, anchor='center',
        lineWidth=1.0,
        colorSpace='rgb', lineColor='white', fillColor='white',
        opacity=None, depth=0.0, interpolate=True)
    image_blank = visual.ImageStim(
        win=win,
        name='image_blank', 
        image=None, mask=None, anchor='center',
        ori=0.0, pos=(0, 0), draggable=False, size=(0.5, 0.5),
        color=[1,1,1], colorSpace='rgb', opacity=None,
        flipHoriz=False, flipVert=False,
        texRes=128.0, interpolate=True, depth=-1.0)
    
    # --- Initialize components for Routine "Start_PAL" ---
    text_end_ex = visual.TextStim(win=win, name='text_end_ex',
        text='Exemplo concluído.\n\n',
        font='Arial',
        pos=(0, 0), draggable=False, height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=0.0);
    text_start_PAL = visual.TextStim(win=win, name='text_start_PAL',
        text='Vamos começar?\n\nPrime a tecla ESPAÇO quando estiveres pronto\nSe tiveres alguma dúvida chama o experimentador.',
        font='Arial',
        pos=(0, 0), draggable=False, height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-1.0);
    key_start_PAL = keyboard.Keyboard(deviceName='defaultKeyboard')
    
    # --- Initialize components for Routine "Encode" ---
    image_scene_encode = visual.ImageStim(
        win=win,
        name='image_scene_encode', units='pix', 
        image='default.png', mask=None, anchor='center',
        ori=0.0, pos=(-200, 0), draggable=False, size=1.0,
        color=[1,1,1], colorSpace='rgb', opacity=None,
        flipHoriz=False, flipVert=False,
        texRes=128.0, interpolate=True, depth=0.0)
    image_object_encode = visual.ImageStim(
        win=win,
        name='image_object_encode', units='pix', 
        image='default.png', mask=None, anchor='center',
        ori=0.0, pos=(300, 0), draggable=False, size=1.0,
        color=[1,1,1], colorSpace='rgb', opacity=None,
        flipHoriz=False, flipVert=False,
        texRes=128.0, interpolate=True, depth=-1.0)
    text_rating = visual.TextStim(win=win, name='text_rating',
        text='Qual o nível de congruência entre o par?\n1 - Incongruente        5- Congruente',
        font='Arial',
        pos=(0, 0.35), draggable=False, height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-3.0);
    slider_cong = visual.Slider(win=win, name='slider_cong',
        startValue=None, size=(0.8, 0.05), pos=(0, -0.35), units=win.units,
        labels=['1','2','3','4','5'], ticks=(1, 2, 3, 4, 5), granularity=1.0,
        style='rating', styleTweaks=(), opacity=None,
        labelColor='LightGray', markerColor='Red', lineColor='White', colorSpace='rgb',
        font='Ariel', labelHeight=0.05,
        flip=False, ori=0.0, depth=-4, readOnly=False)
    
    # --- Initialize components for Routine "blank" ---
    cross_25 = visual.ShapeStim(
        win=win, name='cross_25', vertices='cross',
        size=(0.25, 0.25),
        ori=0.0, pos=(0, 0), draggable=False, anchor='center',
        lineWidth=1.0,
        colorSpace='rgb', lineColor='white', fillColor='white',
        opacity=None, depth=0.0, interpolate=True)
    image_blank = visual.ImageStim(
        win=win,
        name='image_blank', 
        image=None, mask=None, anchor='center',
        ori=0.0, pos=(0, 0), draggable=False, size=(0.5, 0.5),
        color=[1,1,1], colorSpace='rgb', opacity=None,
        flipHoriz=False, flipVert=False,
        texRes=128.0, interpolate=True, depth=-1.0)
    
    # --- Initialize components for Routine "Pause_1" ---
    text_pausa1 = visual.TextStim(win=win, name='text_pausa1',
        text='A primeira parte está concluída. Bom trabalho!\n\nPrime ESPAÇO quando estiveres pronto para a próxima tarefa.',
        font='Arial',
        pos=(0, 0), draggable=False, height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=0.0);
    key_Start_Cog = keyboard.Keyboard(deviceName='defaultKeyboard')
    
    # --- Initialize components for Routine "Explanation_GoNo" ---
    text_explanation_GoNo = visual.TextStim(win=win, name='text_explanation_GoNo',
        text='Vais agora fazer uma tarefa de atenção chamada Go/No-Go.\n\n' +
             'Vais ver dois tipos de imagens:\n\n' +
             '1. IMAGEM "GO" (sinal verde):\n   → DEVES premir ESPAÇO rapidamente!\n\n' +
             '2. IMAGEM "NO-GO" (sinal vermelho):\n   → NÃO deves premir nenhuma tecla!\n\n' +
             'Cada imagem aparece durante 2 segundos.\n' +
             'Se cometeres um erro, aparecerá um feedback durante 2 segundos.\n\n' +
             'Prime ESPAÇO para começar a tarefa.',
        font='Arial',
        pos=(0, 0), draggable=False, height=0.05, wrapWidth=1.8, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=0.0);
    key_gonogo_start = keyboard.Keyboard(deviceName='defaultKeyboard')
    
    # --- Initialize components for Routine "GoNoGo_Trial" ---
    image_gonogo_signal = visual.ImageStim(
        win=win,
        name='image_gonogo_signal',
        image=None, mask=None, anchor='center',
        ori=0.0, pos=(0, 0), draggable=False, size=(0.5, 0.5),
        color=[1,1,1], colorSpace='rgb', opacity=None,
        flipHoriz=False, flipVert=False,
        texRes=128.0, interpolate=True, depth=0.0)
    
    image_gonogo_feedback = visual.ImageStim(
        win=win,
        name='image_gonogo_feedback',
        image=None, mask=None, anchor='center',
        ori=0.0, pos=(0, 0), draggable=False, size=(0.5, 0.5),
        color=[1,1,1], colorSpace='rgb', opacity=None,
        flipHoriz=False, flipVert=False,
        texRes=128.0, interpolate=True, depth=-1.0)
    
    key_gonogo_response = keyboard.Keyboard(deviceName='defaultKeyboard')
    
    # --- Initialize components for Routine "Cog_Oral" ---
    text_endGo = visual.TextStim(win=win, name='text_endGo',
        text='Tarefa concluída.',
        font='Arial',
        pos=(0, 0), draggable=False, height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=0.0);
    text_call = visual.TextStim(win=win, name='text_call',
        text='O experimentador vem agora ter contigo para duas tarefas orais.',
        font='Arial',
        pos=(0, 0), draggable=False, height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-1.0);
    key_end_cog = keyboard.Keyboard(deviceName='defaultKeyboard')
    
    # --- Initialize components for Routine "Retomar" ---
    text_retomar = visual.TextStim(win=win, name='text_retomar',
        text='Pronto para os testes de memória?\nPrime ESPAÇO para a explicação das tarefas.',
        font='Arial',
        pos=(0, 0), draggable=False, height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=0.0);
    key_resp = keyboard.Keyboard(deviceName='defaultKeyboard')
    
    # --- Initialize components for Routine "Explanation_Recall" ---
    text_explain_recall = visual.TextStim(win=win, name='text_explain_recall',
        text='Vamos fazer agora duas tarefas para testar a tua memória. \nSerá que te lembras dos pares de imagens?\n\n\nPrime ESPAÇO para continuar',
        font='Arial',
        pos=(0, 0), draggable=False, height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=0.0);
    key_continue = keyboard.Keyboard(deviceName='defaultKeyboard')
    
    # --- Initialize components for Routine "Explain_Old_New" ---
    text_explain_old_new = visual.TextStim(win=win, name='text_explain_old_new',
        text="No primeiro teste de memória, vamos apresentar imagens de cenas.\nSe reconheceres a imagem como sendo uma das que aprendeste, prime a FLECHA ESQUERDA '<-' ou na TECLA 'V'\n\nSe a imagem for nova, que não faz parte das imagens que aprendeste, então prime a FLECHA DIREITA '->' ou na TECLA 'N'.\n\nTens 2,5 segundos. Se depois de primires um botão mudares de ideias, basta primir a outra flecha.\nPrime ESPAÇO para um exemplo\n",
        font='Arial',
        pos=(0, 0), draggable=False, height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=0.0);
    key_explain_old = keyboard.Keyboard(deviceName='defaultKeyboard')
    
    # --- Initialize components for Routine "Exemplo_old" ---
    image_exemplo_old_new = visual.ImageStim(
        win=win,
        name='image_exemplo_old_new', units='pix', 
        image='default.png', mask=None, anchor='center',
        ori=0.0, pos=(0, 0), draggable=False, size=1.0,
        color=[1,1,1], colorSpace='rgb', opacity=None,
        flipHoriz=True, flipVert=False,
        texRes=128.0, interpolate=True, depth=0.0)
    key_ex_old = keyboard.Keyboard(deviceName='defaultKeyboard')
    text_ex_old = visual.TextStim(win=win, name='text_ex_old',
        text='Prime <- ou V se a imagem for VELHA\n\nPrime -> ou N se a imagem for NOVA',
        font='Arial',
        pos=(0, 0.3), draggable=False, height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-2.0);
    
    # --- Initialize components for Routine "blank" ---
    cross_25 = visual.ShapeStim(
        win=win, name='cross_25', vertices='cross',
        size=(0.25, 0.25),
        ori=0.0, pos=(0, 0), draggable=False, anchor='center',
        lineWidth=1.0,
        colorSpace='rgb', lineColor='white', fillColor='white',
        opacity=None, depth=0.0, interpolate=True)
    image_blank = visual.ImageStim(
        win=win,
        name='image_blank', 
        image=None, mask=None, anchor='center',
        ori=0.0, pos=(0, 0), draggable=False, size=(0.5, 0.5),
        color=[1,1,1], colorSpace='rgb', opacity=None,
        flipHoriz=False, flipVert=False,
        texRes=128.0, interpolate=True, depth=-1.0)
    
    # --- Initialize components for Routine "Start_Recall" ---
    text_start_recall = visual.TextStim(win=win, name='text_start_recall',
        text='Exemplo concluído. Se tiveres dúvidas, chama o experimentador.\n\n\nPrime ESPAÇO para começar o teste',
        font='Arial',
        pos=(0, 0), draggable=False, height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=0.0);
    key_start_recall = keyboard.Keyboard(deviceName='defaultKeyboard')
    
    # --- Initialize components for Routine "Old_New" ---
    image_old_new = visual.ImageStim(
        win=win,
        name='image_old_new', units='pix', 
        image='default.png', mask=None, anchor='center',
        ori=0.0, pos=(0, -0.08), draggable=False, size=1.0,
        color=[1,1,1], colorSpace='rgb', opacity=None,
        flipHoriz=False, flipVert=False,
        texRes=128.0, interpolate=True, depth=0.0)
    key_item = keyboard.Keyboard(deviceName='defaultKeyboard')
    text_item = visual.TextStim(win=win, name='text_item',
        text="Prime a flecha esquerda '<-' ou 'v' para VELHAS imagens\n\nPrime a flecha direita '->' ou 'n' para NOVAS imagens",
        font='Arial',
        pos=(0, 0.35), draggable=False, height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-2.0);
    
    # --- Initialize components for Routine "blank" ---
    cross_25 = visual.ShapeStim(
        win=win, name='cross_25', vertices='cross',
        size=(0.25, 0.25),
        ori=0.0, pos=(0, 0), draggable=False, anchor='center',
        lineWidth=1.0,
        colorSpace='rgb', lineColor='white', fillColor='white',
        opacity=None, depth=0.0, interpolate=True)
    image_blank = visual.ImageStim(
        win=win,
        name='image_blank', 
        image=None, mask=None, anchor='center',
        ori=0.0, pos=(0, 0), draggable=False, size=(0.5, 0.5),
        color=[1,1,1], colorSpace='rgb', opacity=None,
        flipHoriz=False, flipVert=False,
        texRes=128.0, interpolate=True, depth=-1.0)
    
    # --- Initialize components for Routine "End_Old_New" ---
    text_end_item = visual.TextStim(win=win, name='text_end_item',
        text='Tarefa concluída. Só falta mais uma.\nPrime ESPAÇO quando estiveres pronto para a explicação do segundo teste.',
        font='Arial',
        pos=(0, 0), draggable=False, height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=0.0);
    key_resp_2 = keyboard.Keyboard(deviceName='defaultKeyboard')
    
    # --- Initialize components for Routine "Explain_2AFC" ---
    text_explain_2afc = visual.TextStim(win=win, name='text_explain_2afc',
        text='Vão aparecer três imagens: uma cena que viste anteriormente, e dois objetos.\nUm dos objetos viste antes associado à cena,  durante a aprendizagem. \nSe o objeto associado estiver em cima, prime a FLECHA de CIMA. Se o objeto associado for o de baixo, prime a FLECHA de BAIXO.\n\nTens 2,5 segundos. Se depois de primires um botão mudares de ideias, basta primir a outra flecha.\n\nPrime ESPAÇO para um exemplo. ',
        font='Arial',
        pos=(0, 0), draggable=False, height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=0.0);
    key_end_explain_2afc = keyboard.Keyboard(deviceName='defaultKeyboard')
    
    # --- Initialize components for Routine "Exemplo_2AFC" ---
    image_ex_2AFC = visual.ImageStim(
        win=win,
        name='image_ex_2AFC', units='pix', 
        image='default.png', mask=None, anchor='center',
        ori=0.0, pos=(-200, 0), draggable=False, size=1.0,
        color=[1,1,1], colorSpace='rgb', opacity=None,
        flipHoriz=False, flipVert=False,
        texRes=128.0, interpolate=True, depth=0.0)
    image_ex_target = visual.ImageStim(
        win=win,
        name='image_ex_target', units='pix', 
        image='default.png', mask=None, anchor='center',
        ori=0.0, pos=[0,0], draggable=False, size=1.0,
        color=[1,1,1], colorSpace='rgb', opacity=None,
        flipHoriz=False, flipVert=False,
        texRes=128.0, interpolate=True, depth=-1.0)
    image_ex_lure = visual.ImageStim(
        win=win,
        name='image_ex_lure', units='pix', 
        image='default.png', mask=None, anchor='center',
        ori=0.0, pos=[0,0], draggable=False, size=1.0,
        color=[1,1,1], colorSpace='rgb', opacity=None,
        flipHoriz=False, flipVert=False,
        texRes=128.0, interpolate=True, depth=-2.0)
    key_ex_2AFC = keyboard.Keyboard(deviceName='defaultKeyboard')
    
    # --- Initialize components for Routine "blank" ---
    cross_25 = visual.ShapeStim(
        win=win, name='cross_25', vertices='cross',
        size=(0.25, 0.25),
        ori=0.0, pos=(0, 0), draggable=False, anchor='center',
        lineWidth=1.0,
        colorSpace='rgb', lineColor='white', fillColor='white',
        opacity=None, depth=0.0, interpolate=True)
    image_blank = visual.ImageStim(
        win=win,
        name='image_blank', 
        image=None, mask=None, anchor='center',
        ori=0.0, pos=(0, 0), draggable=False, size=(0.5, 0.5),
        color=[1,1,1], colorSpace='rgb', opacity=None,
        flipHoriz=False, flipVert=False,
        texRes=128.0, interpolate=True, depth=-1.0)
    
    # --- Initialize components for Routine "Start_Recall" ---
    text_start_recall = visual.TextStim(win=win, name='text_start_recall',
        text='Exemplo concluído. Se tiveres dúvidas, chama o experimentador.\n\n\nPrime ESPAÇO para começar o teste',
        font='Arial',
        pos=(0, 0), draggable=False, height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=0.0);
    key_start_recall = keyboard.Keyboard(deviceName='defaultKeyboard')
    
    # --- Initialize components for Routine "trial_2AFC" ---
    image_scene_2AFC = visual.ImageStim(
        win=win,
        name='image_scene_2AFC', units='pix', 
        image='default.png', mask=None, anchor='center',
        ori=0.0, pos=(-250, 0), draggable=False, size=1.0,
        color=[1,1,1], colorSpace='rgb', opacity=None,
        flipHoriz=False, flipVert=False,
        texRes=128.0, interpolate=True, depth=0.0)
    key_2AFC = keyboard.Keyboard(deviceName='defaultKeyboard')
    image_target = visual.ImageStim(
        win=win,
        name='image_target', units='pix', 
        image='default.png', mask=None, anchor='center',
        ori=0.0, pos=[0,0], draggable=False, size=1.0,
        color=[1,1,1], colorSpace='rgb', opacity=None,
        flipHoriz=True, flipVert=False,
        texRes=128.0, interpolate=True, depth=-2.0)
    image_lure = visual.ImageStim(
        win=win,
        name='image_lure', units='pix', 
        image='default.png', mask=None, anchor='center',
        ori=0.0, pos=[0,0], draggable=False, size=1.0,
        color=[1,1,1], colorSpace='rgb', opacity=None,
        flipHoriz=False, flipVert=False,
        texRes=128.0, interpolate=True, depth=-3.0)
    
    # --- Initialize components for Routine "blank" ---
    cross_25 = visual.ShapeStim(
        win=win, name='cross_25', vertices='cross',
        size=(0.25, 0.25),
        ori=0.0, pos=(0, 0), draggable=False, anchor='center',
        lineWidth=1.0,
        colorSpace='rgb', lineColor='white', fillColor='white',
        opacity=None, depth=0.0, interpolate=True)
    image_blank = visual.ImageStim(
        win=win,
        name='image_blank', 
        image=None, mask=None, anchor='center',
        ori=0.0, pos=(0, 0), draggable=False, size=(0.5, 0.5),
        color=[1,1,1], colorSpace='rgb', opacity=None,
        flipHoriz=False, flipVert=False,
        texRes=128.0, interpolate=True, depth=-1.0)
    
    # --- Initialize components for Routine "end" ---
    text_end = visual.TextStim(win=win, name='text_end',
        text='Experiência concluída.\nObrigada por participares!',
        font='Arial',
        pos=(0, 0), draggable=False, height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=0.0);
    
    # create some handy timers
    
    # global clock to track the time since experiment started
    if globalClock is None:
        # create a clock if not given one
        globalClock = core.Clock()
    if isinstance(globalClock, str):
        # if given a string, make a clock accoridng to it
        if globalClock == 'float':
            # get timestamps as a simple value
            globalClock = core.Clock(format='float')
        elif globalClock == 'iso':
            # get timestamps in ISO format
            globalClock = core.Clock(format='%Y-%m-%d_%H:%M:%S.%f%z')
        else:
            # get timestamps in a custom format
            globalClock = core.Clock(format=globalClock)
    if ioServer is not None:
        ioServer.syncClock(globalClock)
    logging.setDefaultClock(globalClock)
    if eyetracker is not None:
        eyetracker.enableEventReporting()
    # routine timer to track time remaining of each (possibly non-slip) routine
    routineTimer = core.Clock()
    win.flip()  # flip window to reset last flip timer
    # store the exact time the global clock started
    expInfo['expStart'] = data.getDateStr(
        format='%Y-%m-%d %Hh%M.%S.%f %z', fractionalSecondDigits=6
    )
    
    # --- Prepare to start Routine "Welcome" ---
    # create an object to store info about Routine Welcome
    Welcome = data.Routine(
        name='Welcome',
        components=[text_hi, key_welcome],
    )
    Welcome.status = NOT_STARTED
    continueRoutine = True
    # update component parameters for each repeat
    # create starting attributes for key_welcome
    key_welcome.keys = []
    key_welcome.rt = []
    _key_welcome_allKeys = []
    # store start times for Welcome
    Welcome.tStartRefresh = win.getFutureFlipTime(clock=globalClock)
    Welcome.tStart = globalClock.getTime(format='float')
    Welcome.status = STARTED
    thisExp.addData('Welcome.started', Welcome.tStart)
    Welcome.maxDuration = None
    # keep track of which components have finished
    WelcomeComponents = Welcome.components
    for thisComponent in Welcome.components:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    frameN = -1
    
    # --- Run Routine "Welcome" ---
    thisExp.currentRoutine = Welcome
    Welcome.forceEnded = routineForceEnded = not continueRoutine
    while continueRoutine:
        # get current time
        t = routineTimer.getTime()
        tThisFlip = win.getFutureFlipTime(clock=routineTimer)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *text_hi* updates
        
        # if text_hi is starting this frame...
        if text_hi.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            text_hi.frameNStart = frameN  # exact frame index
            text_hi.tStart = t  # local t and not account for scr refresh
            text_hi.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(text_hi, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'text_hi.started')
            # update status
            text_hi.status = STARTED
            text_hi.setAutoDraw(True)
        
        # if text_hi is active this frame...
        if text_hi.status == STARTED:
            # update params
            pass
        
        # *key_welcome* updates
        waitOnFlip = False
        
        # if key_welcome is starting this frame...
        if key_welcome.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            key_welcome.frameNStart = frameN  # exact frame index
            key_welcome.tStart = t  # local t and not account for scr refresh
            key_welcome.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(key_welcome, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'key_welcome.started')
            # update status
            key_welcome.status = STARTED
            # keyboard checking is just starting
            waitOnFlip = True
            win.callOnFlip(key_welcome.clock.reset)  # t=0 on next screen flip
            win.callOnFlip(key_welcome.clearEvents, eventType='keyboard')  # clear events on next screen flip
        if key_welcome.status == STARTED and not waitOnFlip:
            theseKeys = key_welcome.getKeys(keyList=['y','n','left','right','space'], ignoreKeys=["escape"], waitRelease=False)
            _key_welcome_allKeys.extend(theseKeys)
            if len(_key_welcome_allKeys):
                key_welcome.keys = _key_welcome_allKeys[-1].name  # just the last key pressed
                key_welcome.rt = _key_welcome_allKeys[-1].rt
                key_welcome.duration = _key_welcome_allKeys[-1].duration
                # a response ends the routine
                continueRoutine = False
        
        # check for quit (typically the Esc key)
        if defaultKeyboard.getKeys(keyList=["escape"]):
            thisExp.status = FINISHED
        if thisExp.status == FINISHED or endExpNow:
            endExperiment(thisExp, win=win)
            return
        # pause experiment here if requested
        if thisExp.status == PAUSED:
            pauseExperiment(
                thisExp=thisExp, 
                win=win, 
                timers=[routineTimer, globalClock], 
                currentRoutine=Welcome,
            )
            # skip the frame we paused on
            continue
        
        # has a Component requested the Routine to end?
        if not continueRoutine:
            Welcome.forceEnded = routineForceEnded = True
        # has the Routine been forcibly ended?
        if Welcome.forceEnded or routineForceEnded:
            break
        # has every Component finished?
        continueRoutine = False
        for thisComponent in Welcome.components:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # --- Ending Routine "Welcome" ---
    for thisComponent in Welcome.components:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    # store stop times for Welcome
    Welcome.tStop = globalClock.getTime(format='float')
    Welcome.tStopRefresh = tThisFlipGlobal
    thisExp.addData('Welcome.stopped', Welcome.tStop)
    # check responses
    if key_welcome.keys in ['', [], None]:  # No response was made
        key_welcome.keys = None
    thisExp.addData('key_welcome.keys',key_welcome.keys)
    if key_welcome.keys != None:  # we had a response
        thisExp.addData('key_welcome.rt', key_welcome.rt)
        thisExp.addData('key_welcome.duration', key_welcome.duration)
    thisExp.nextEntry()
    # the Routine "Welcome" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # --- Prepare to start Routine "Explanation_PAL" ---
    # create an object to store info about Routine Explanation_PAL
    Explanation_PAL = data.Routine(
        name='Explanation_PAL',
        components=[text_Explain_PAL, key_start_example],
    )
    Explanation_PAL.status = NOT_STARTED
    continueRoutine = True
    # update component parameters for each repeat
    # create starting attributes for key_start_example
    key_start_example.keys = []
    key_start_example.rt = []
    _key_start_example_allKeys = []
    # store start times for Explanation_PAL
    Explanation_PAL.tStartRefresh = win.getFutureFlipTime(clock=globalClock)
    Explanation_PAL.tStart = globalClock.getTime(format='float')
    Explanation_PAL.status = STARTED
    thisExp.addData('Explanation_PAL.started', Explanation_PAL.tStart)
    Explanation_PAL.maxDuration = None
    # keep track of which components have finished
    Explanation_PALComponents = Explanation_PAL.components
    for thisComponent in Explanation_PAL.components:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    frameN = -1
    
    # --- Run Routine "Explanation_PAL" ---
    thisExp.currentRoutine = Explanation_PAL
    Explanation_PAL.forceEnded = routineForceEnded = not continueRoutine
    while continueRoutine:
        # get current time
        t = routineTimer.getTime()
        tThisFlip = win.getFutureFlipTime(clock=routineTimer)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *text_Explain_PAL* updates
        
        # if text_Explain_PAL is starting this frame...
        if text_Explain_PAL.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            text_Explain_PAL.frameNStart = frameN  # exact frame index
            text_Explain_PAL.tStart = t  # local t and not account for scr refresh
            text_Explain_PAL.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(text_Explain_PAL, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'text_Explain_PAL.started')
            # update status
            text_Explain_PAL.status = STARTED
            text_Explain_PAL.setAutoDraw(True)
        
        # if text_Explain_PAL is active this frame...
        if text_Explain_PAL.status == STARTED:
            # update params
            pass
        
        # *key_start_example* updates
        waitOnFlip = False
        
        # if key_start_example is starting this frame...
        if key_start_example.status == NOT_STARTED and tThisFlip >= 1.0-frameTolerance:
            # keep track of start time/frame for later
            key_start_example.frameNStart = frameN  # exact frame index
            key_start_example.tStart = t  # local t and not account for scr refresh
            key_start_example.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(key_start_example, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'key_start_example.started')
            # update status
            key_start_example.status = STARTED
            # keyboard checking is just starting
            waitOnFlip = True
            win.callOnFlip(key_start_example.clock.reset)  # t=0 on next screen flip
            win.callOnFlip(key_start_example.clearEvents, eventType='keyboard')  # clear events on next screen flip
        if key_start_example.status == STARTED and not waitOnFlip:
            theseKeys = key_start_example.getKeys(keyList=['y','n','left','right','space'], ignoreKeys=["escape"], waitRelease=False)
            _key_start_example_allKeys.extend(theseKeys)
            if len(_key_start_example_allKeys):
                key_start_example.keys = _key_start_example_allKeys[-1].name  # just the last key pressed
                key_start_example.rt = _key_start_example_allKeys[-1].rt
                key_start_example.duration = _key_start_example_allKeys[-1].duration
                # a response ends the routine
                continueRoutine = False
        
        # check for quit (typically the Esc key)
        if defaultKeyboard.getKeys(keyList=["escape"]):
            thisExp.status = FINISHED
        if thisExp.status == FINISHED or endExpNow:
            endExperiment(thisExp, win=win)
            return
        # pause experiment here if requested
        if thisExp.status == PAUSED:
            pauseExperiment(
                thisExp=thisExp, 
                win=win, 
                timers=[routineTimer, globalClock], 
                currentRoutine=Explanation_PAL,
            )
            # skip the frame we paused on
            continue
        
        # has a Component requested the Routine to end?
        if not continueRoutine:
            Explanation_PAL.forceEnded = routineForceEnded = True
        # has the Routine been forcibly ended?
        if Explanation_PAL.forceEnded or routineForceEnded:
            break
        # has every Component finished?
        continueRoutine = False
        for thisComponent in Explanation_PAL.components:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # --- Ending Routine "Explanation_PAL" ---
    for thisComponent in Explanation_PAL.components:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    # store stop times for Explanation_PAL
    Explanation_PAL.tStop = globalClock.getTime(format='float')
    Explanation_PAL.tStopRefresh = tThisFlipGlobal
    thisExp.addData('Explanation_PAL.stopped', Explanation_PAL.tStop)
    # check responses
    if key_start_example.keys in ['', [], None]:  # No response was made
        key_start_example.keys = None
    thisExp.addData('key_start_example.keys',key_start_example.keys)
    if key_start_example.keys != None:  # we had a response
        thisExp.addData('key_start_example.rt', key_start_example.rt)
        thisExp.addData('key_start_example.duration', key_start_example.duration)
    thisExp.nextEntry()
    # the Routine "Explanation_PAL" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # --- Prepare to start Routine "Explain_Rating" ---
    # create an object to store info about Routine Explain_Rating
    Explain_Rating = data.Routine(
        name='Explain_Rating',
        components=[text_explain_rate, key_explainPAL],
    )
    Explain_Rating.status = NOT_STARTED
    continueRoutine = True
    # update component parameters for each repeat
    # create starting attributes for key_explainPAL
    key_explainPAL.keys = []
    key_explainPAL.rt = []
    _key_explainPAL_allKeys = []
    # store start times for Explain_Rating
    Explain_Rating.tStartRefresh = win.getFutureFlipTime(clock=globalClock)
    Explain_Rating.tStart = globalClock.getTime(format='float')
    Explain_Rating.status = STARTED
    thisExp.addData('Explain_Rating.started', Explain_Rating.tStart)
    Explain_Rating.maxDuration = None
    # keep track of which components have finished
    Explain_RatingComponents = Explain_Rating.components
    for thisComponent in Explain_Rating.components:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    frameN = -1
    
    # --- Run Routine "Explain_Rating" ---
    thisExp.currentRoutine = Explain_Rating
    Explain_Rating.forceEnded = routineForceEnded = not continueRoutine
    while continueRoutine:
        # get current time
        t = routineTimer.getTime()
        tThisFlip = win.getFutureFlipTime(clock=routineTimer)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *text_explain_rate* updates
        
        # if text_explain_rate is starting this frame...
        if text_explain_rate.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            text_explain_rate.frameNStart = frameN  # exact frame index
            text_explain_rate.tStart = t  # local t and not account for scr refresh
            text_explain_rate.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(text_explain_rate, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'text_explain_rate.started')
            # update status
            text_explain_rate.status = STARTED
            text_explain_rate.setAutoDraw(True)
        
        # if text_explain_rate is active this frame...
        if text_explain_rate.status == STARTED:
            # update params
            pass
        
        # *key_explainPAL* updates
        waitOnFlip = False
        
        # if key_explainPAL is starting this frame...
        if key_explainPAL.status == NOT_STARTED and tThisFlip >= 1.0-frameTolerance:
            # keep track of start time/frame for later
            key_explainPAL.frameNStart = frameN  # exact frame index
            key_explainPAL.tStart = t  # local t and not account for scr refresh
            key_explainPAL.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(key_explainPAL, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'key_explainPAL.started')
            # update status
            key_explainPAL.status = STARTED
            # keyboard checking is just starting
            waitOnFlip = True
            win.callOnFlip(key_explainPAL.clock.reset)  # t=0 on next screen flip
            win.callOnFlip(key_explainPAL.clearEvents, eventType='keyboard')  # clear events on next screen flip
        if key_explainPAL.status == STARTED and not waitOnFlip:
            theseKeys = key_explainPAL.getKeys(keyList=['y','n','left','right','space'], ignoreKeys=["escape"], waitRelease=False)
            _key_explainPAL_allKeys.extend(theseKeys)
            if len(_key_explainPAL_allKeys):
                key_explainPAL.keys = _key_explainPAL_allKeys[-1].name  # just the last key pressed
                key_explainPAL.rt = _key_explainPAL_allKeys[-1].rt
                key_explainPAL.duration = _key_explainPAL_allKeys[-1].duration
                # a response ends the routine
                continueRoutine = False
        
        # check for quit (typically the Esc key)
        if defaultKeyboard.getKeys(keyList=["escape"]):
            thisExp.status = FINISHED
        if thisExp.status == FINISHED or endExpNow:
            endExperiment(thisExp, win=win)
            return
        # pause experiment here if requested
        if thisExp.status == PAUSED:
            pauseExperiment(
                thisExp=thisExp, 
                win=win, 
                timers=[routineTimer, globalClock], 
                currentRoutine=Explain_Rating,
            )
            # skip the frame we paused on
            continue
        
        # has a Component requested the Routine to end?
        if not continueRoutine:
            Explain_Rating.forceEnded = routineForceEnded = True
        # has the Routine been forcibly ended?
        if Explain_Rating.forceEnded or routineForceEnded:
            break
        # has every Component finished?
        continueRoutine = False
        for thisComponent in Explain_Rating.components:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # --- Ending Routine "Explain_Rating" ---
    for thisComponent in Explain_Rating.components:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    # store stop times for Explain_Rating
    Explain_Rating.tStop = globalClock.getTime(format='float')
    Explain_Rating.tStopRefresh = tThisFlipGlobal
    thisExp.addData('Explain_Rating.stopped', Explain_Rating.tStop)
    # check responses
    if key_explainPAL.keys in ['', [], None]:  # No response was made
        key_explainPAL.keys = None
    thisExp.addData('key_explainPAL.keys',key_explainPAL.keys)
    if key_explainPAL.keys != None:  # we had a response
        thisExp.addData('key_explainPAL.rt', key_explainPAL.rt)
        thisExp.addData('key_explainPAL.duration', key_explainPAL.duration)
    thisExp.nextEntry()
    # the Routine "Explain_Rating" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # set up handler to look after randomisation of conditions etc
    example = data.TrialHandler2(
        name='example',
        nReps=1.0, 
        method='random', 
        extraInfo=expInfo, 
        originPath=-1, 
        trialList=data.importConditions('Exemplo_encode.xlsx'), 
        seed=None, 
        isTrials=True, 
    )
    thisExp.addLoop(example)  # add the loop to the experiment
    thisExample = example.trialList[0]  # so we can initialise stimuli with some values
    # abbreviate parameter names if possible (e.g. rgb = thisExample.rgb)
    if thisExample != None:
        for paramName in thisExample:
            globals()[paramName] = thisExample[paramName]
    if thisSession is not None:
        # if running in a Session with a Liaison client, send data up to now
        thisSession.sendExperimentData()
    
    for thisExample in example:
        example.status = STARTED
        if hasattr(thisExample, 'status'):
            thisExample.status = STARTED
        currentLoop = example
        thisExp.timestampOnFlip(win, 'thisRow.t', format=globalClock.format)
        if thisSession is not None:
            # if running in a Session with a Liaison client, send data up to now
            thisSession.sendExperimentData()
        # abbreviate parameter names if possible (e.g. rgb = thisExample.rgb)
        if thisExample != None:
            for paramName in thisExample:
                globals()[paramName] = thisExample[paramName]
        
        # --- Prepare to start Routine "Example_PAL" ---
        # create an object to store info about Routine Example_PAL
        Example_PAL = data.Routine(
            name='Example_PAL',
            components=[image_ex_scene, image_ex_object, slider_example, text_example],
        )
        Example_PAL.status = NOT_STARTED
        continueRoutine = True
        # update component parameters for each repeat
        image_ex_scene.setSize(scene_size)
        image_ex_scene.setImage(scene_encode)
        image_ex_object.setSize(object_size)
        image_ex_object.setImage(object_encode)
        slider_example.reset()
        # store start times for Example_PAL
        Example_PAL.tStartRefresh = win.getFutureFlipTime(clock=globalClock)
        Example_PAL.tStart = globalClock.getTime(format='float')
        Example_PAL.status = STARTED
        thisExp.addData('Example_PAL.started', Example_PAL.tStart)
        Example_PAL.maxDuration = None
        # keep track of which components have finished
        Example_PALComponents = Example_PAL.components
        for thisComponent in Example_PAL.components:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        frameN = -1
        
        # --- Run Routine "Example_PAL" ---
        thisExp.currentRoutine = Example_PAL
        Example_PAL.forceEnded = routineForceEnded = not continueRoutine
        while continueRoutine:
            # if trial has changed, end Routine now
            if hasattr(thisExample, 'status') and thisExample.status == STOPPING:
                continueRoutine = False
            # get current time
            t = routineTimer.getTime()
            tThisFlip = win.getFutureFlipTime(clock=routineTimer)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *image_ex_scene* updates
            
            # if image_ex_scene is starting this frame...
            if image_ex_scene.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                image_ex_scene.frameNStart = frameN  # exact frame index
                image_ex_scene.tStart = t  # local t and not account for scr refresh
                image_ex_scene.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(image_ex_scene, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'image_ex_scene.started')
                # update status
                image_ex_scene.status = STARTED
                image_ex_scene.setAutoDraw(True)
            
            # if image_ex_scene is active this frame...
            if image_ex_scene.status == STARTED:
                # update params
                pass
            
            # *image_ex_object* updates
            
            # if image_ex_object is starting this frame...
            if image_ex_object.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                image_ex_object.frameNStart = frameN  # exact frame index
                image_ex_object.tStart = t  # local t and not account for scr refresh
                image_ex_object.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(image_ex_object, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'image_ex_object.started')
                # update status
                image_ex_object.status = STARTED
                image_ex_object.setAutoDraw(True)
            
            # if image_ex_object is active this frame...
            if image_ex_object.status == STARTED:
                # update params
                pass
            
            # *slider_example* updates
            
            # if slider_example is starting this frame...
            if slider_example.status == NOT_STARTED and tThisFlip >= 2.5-frameTolerance:
                # keep track of start time/frame for later
                slider_example.frameNStart = frameN  # exact frame index
                slider_example.tStart = t  # local t and not account for scr refresh
                slider_example.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(slider_example, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'slider_example.started')
                # update status
                slider_example.status = STARTED
                slider_example.setAutoDraw(True)
            
            # if slider_example is active this frame...
            if slider_example.status == STARTED:
                # update params
                pass
            
            # Check slider_example for response to end Routine
            if slider_example.getRating() is not None and slider_example.status == STARTED:
                continueRoutine = False
            
            # *text_example* updates
            
            # if text_example is starting this frame...
            if text_example.status == NOT_STARTED and tThisFlip >= 2.5-frameTolerance:
                # keep track of start time/frame for later
                text_example.frameNStart = frameN  # exact frame index
                text_example.tStart = t  # local t and not account for scr refresh
                text_example.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(text_example, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'text_example.started')
                # update status
                text_example.status = STARTED
                text_example.setAutoDraw(True)
            
            # if text_example is active this frame...
            if text_example.status == STARTED:
                # update params
                pass
            
            # check for quit (typically the Esc key)
            if defaultKeyboard.getKeys(keyList=["escape"]):
                thisExp.status = FINISHED
            if thisExp.status == FINISHED or endExpNow:
                endExperiment(thisExp, win=win)
                return
            # pause experiment here if requested
            if thisExp.status == PAUSED:
                pauseExperiment(
                    thisExp=thisExp, 
                    win=win, 
                    timers=[routineTimer, globalClock], 
                    currentRoutine=Example_PAL,
                )
                # skip the frame we paused on
                continue
            
            # has a Component requested the Routine to end?
            if not continueRoutine:
                Example_PAL.forceEnded = routineForceEnded = True
            # has the Routine been forcibly ended?
            if Example_PAL.forceEnded or routineForceEnded:
                break
            # has every Component finished?
            continueRoutine = False
            for thisComponent in Example_PAL.components:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # --- Ending Routine "Example_PAL" ---
        for thisComponent in Example_PAL.components:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        # store stop times for Example_PAL
        Example_PAL.tStop = globalClock.getTime(format='float')
        Example_PAL.tStopRefresh = tThisFlipGlobal
        thisExp.addData('Example_PAL.stopped', Example_PAL.tStop)
        example.addData('slider_example.response', slider_example.getRating())
        example.addData('slider_example.rt', slider_example.getRT())
        # the Routine "Example_PAL" was not non-slip safe, so reset the non-slip timer
        routineTimer.reset()
        
        # --- Prepare to start Routine "blank" ---
        # create an object to store info about Routine blank
        blank = data.Routine(
            name='blank',
            components=[cross_25, image_blank],
        )
        blank.status = NOT_STARTED
        continueRoutine = True
        # update component parameters for each repeat
        # store start times for blank
        blank.tStartRefresh = win.getFutureFlipTime(clock=globalClock)
        blank.tStart = globalClock.getTime(format='float')
        blank.status = STARTED
        thisExp.addData('blank.started', blank.tStart)
        blank.maxDuration = None
        # keep track of which components have finished
        blankComponents = blank.components
        for thisComponent in blank.components:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        frameN = -1
        
        # --- Run Routine "blank" ---
        thisExp.currentRoutine = blank
        blank.forceEnded = routineForceEnded = not continueRoutine
        while continueRoutine and routineTimer.getTime() < 2.5:
            # if trial has changed, end Routine now
            if hasattr(thisExample, 'status') and thisExample.status == STOPPING:
                continueRoutine = False
            # get current time
            t = routineTimer.getTime()
            tThisFlip = win.getFutureFlipTime(clock=routineTimer)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *cross_25* updates
            
            # if cross_25 is starting this frame...
            if cross_25.status == NOT_STARTED and tThisFlip >= 2.25-frameTolerance:
                # keep track of start time/frame for later
                cross_25.frameNStart = frameN  # exact frame index
                cross_25.tStart = t  # local t and not account for scr refresh
                cross_25.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(cross_25, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'cross_25.started')
                # update status
                cross_25.status = STARTED
                cross_25.setAutoDraw(True)
            
            # if cross_25 is active this frame...
            if cross_25.status == STARTED:
                # update params
                pass
            
            # if cross_25 is stopping this frame...
            if cross_25.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > cross_25.tStartRefresh + 0.25-frameTolerance:
                    # keep track of stop time/frame for later
                    cross_25.tStop = t  # not accounting for scr refresh
                    cross_25.tStopRefresh = tThisFlipGlobal  # on global time
                    cross_25.frameNStop = frameN  # exact frame index
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'cross_25.stopped')
                    # update status
                    cross_25.status = FINISHED
                    cross_25.setAutoDraw(False)
            
            # *image_blank* updates
            
            # if image_blank is starting this frame...
            if image_blank.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                image_blank.frameNStart = frameN  # exact frame index
                image_blank.tStart = t  # local t and not account for scr refresh
                image_blank.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(image_blank, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'image_blank.started')
                # update status
                image_blank.status = STARTED
                image_blank.setAutoDraw(True)
            
            # if image_blank is active this frame...
            if image_blank.status == STARTED:
                # update params
                pass
            
            # if image_blank is stopping this frame...
            if image_blank.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > image_blank.tStartRefresh + 2.25-frameTolerance:
                    # keep track of stop time/frame for later
                    image_blank.tStop = t  # not accounting for scr refresh
                    image_blank.tStopRefresh = tThisFlipGlobal  # on global time
                    image_blank.frameNStop = frameN  # exact frame index
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'image_blank.stopped')
                    # update status
                    image_blank.status = FINISHED
                    image_blank.setAutoDraw(False)
            
            # check for quit (typically the Esc key)
            if defaultKeyboard.getKeys(keyList=["escape"]):
                thisExp.status = FINISHED
            if thisExp.status == FINISHED or endExpNow:
                endExperiment(thisExp, win=win)
                return
            # pause experiment here if requested
            if thisExp.status == PAUSED:
                pauseExperiment(
                    thisExp=thisExp, 
                    win=win, 
                    timers=[routineTimer, globalClock], 
                    currentRoutine=blank,
                )
                # skip the frame we paused on
                continue
            
            # has a Component requested the Routine to end?
            if not continueRoutine:
                blank.forceEnded = routineForceEnded = True
            # has the Routine been forcibly ended?
            if blank.forceEnded or routineForceEnded:
                break
            # has every Component finished?
            continueRoutine = False
            for thisComponent in blank.components:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # --- Ending Routine "blank" ---
        for thisComponent in blank.components:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        # store stop times for blank
        blank.tStop = globalClock.getTime(format='float')
        blank.tStopRefresh = tThisFlipGlobal
        thisExp.addData('blank.stopped', blank.tStop)
        # using non-slip timing so subtract the expected duration of this Routine (unless ended on request)
        if blank.maxDurationReached:
            routineTimer.addTime(-blank.maxDuration)
        elif blank.forceEnded:
            routineTimer.reset()
        else:
            routineTimer.addTime(-2.500000)
        # mark thisExample as finished
        if hasattr(thisExample, 'status'):
            thisExample.status = FINISHED
        # if awaiting a pause, pause now
        if example.status == PAUSED:
            thisExp.status = PAUSED
            pauseExperiment(
                thisExp=thisExp, 
                win=win, 
                timers=[globalClock], 
            )
            # once done pausing, restore running status
            example.status = STARTED
        thisExp.nextEntry()
        
    # completed 1.0 repeats of 'example'
    example.status = FINISHED
    
    if thisSession is not None:
        # if running in a Session with a Liaison client, send data up to now
        thisSession.sendExperimentData()
    
    # --- Prepare to start Routine "Start_PAL" ---
    # create an object to store info about Routine Start_PAL
    Start_PAL = data.Routine(
        name='Start_PAL',
        components=[text_end_ex, text_start_PAL, key_start_PAL],
    )
    Start_PAL.status = NOT_STARTED
    continueRoutine = True
    # update component parameters for each repeat
    # create starting attributes for key_start_PAL
    key_start_PAL.keys = []
    key_start_PAL.rt = []
    _key_start_PAL_allKeys = []
    # store start times for Start_PAL
    Start_PAL.tStartRefresh = win.getFutureFlipTime(clock=globalClock)
    Start_PAL.tStart = globalClock.getTime(format='float')
    Start_PAL.status = STARTED
    thisExp.addData('Start_PAL.started', Start_PAL.tStart)
    Start_PAL.maxDuration = None
    # keep track of which components have finished
    Start_PALComponents = Start_PAL.components
    for thisComponent in Start_PAL.components:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    frameN = -1
    
    # --- Run Routine "Start_PAL" ---
    thisExp.currentRoutine = Start_PAL
    Start_PAL.forceEnded = routineForceEnded = not continueRoutine
    while continueRoutine:
        # get current time
        t = routineTimer.getTime()
        tThisFlip = win.getFutureFlipTime(clock=routineTimer)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *text_end_ex* updates
        
        # if text_end_ex is starting this frame...
        if text_end_ex.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            text_end_ex.frameNStart = frameN  # exact frame index
            text_end_ex.tStart = t  # local t and not account for scr refresh
            text_end_ex.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(text_end_ex, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'text_end_ex.started')
            # update status
            text_end_ex.status = STARTED
            text_end_ex.setAutoDraw(True)
        
        # if text_end_ex is active this frame...
        if text_end_ex.status == STARTED:
            # update params
            pass
        
        # if text_end_ex is stopping this frame...
        if text_end_ex.status == STARTED:
            # is it time to stop? (based on global clock, using actual start)
            if tThisFlipGlobal > text_end_ex.tStartRefresh + 1.5-frameTolerance:
                # keep track of stop time/frame for later
                text_end_ex.tStop = t  # not accounting for scr refresh
                text_end_ex.tStopRefresh = tThisFlipGlobal  # on global time
                text_end_ex.frameNStop = frameN  # exact frame index
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'text_end_ex.stopped')
                # update status
                text_end_ex.status = FINISHED
                text_end_ex.setAutoDraw(False)
        
        # *text_start_PAL* updates
        
        # if text_start_PAL is starting this frame...
        if text_start_PAL.status == NOT_STARTED and tThisFlip >= 1.5-frameTolerance:
            # keep track of start time/frame for later
            text_start_PAL.frameNStart = frameN  # exact frame index
            text_start_PAL.tStart = t  # local t and not account for scr refresh
            text_start_PAL.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(text_start_PAL, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'text_start_PAL.started')
            # update status
            text_start_PAL.status = STARTED
            text_start_PAL.setAutoDraw(True)
        
        # if text_start_PAL is active this frame...
        if text_start_PAL.status == STARTED:
            # update params
            pass
        
        # *key_start_PAL* updates
        waitOnFlip = False
        
        # if key_start_PAL is starting this frame...
        if key_start_PAL.status == NOT_STARTED and tThisFlip >= 1.5-frameTolerance:
            # keep track of start time/frame for later
            key_start_PAL.frameNStart = frameN  # exact frame index
            key_start_PAL.tStart = t  # local t and not account for scr refresh
            key_start_PAL.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(key_start_PAL, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'key_start_PAL.started')
            # update status
            key_start_PAL.status = STARTED
            # keyboard checking is just starting
            waitOnFlip = True
            win.callOnFlip(key_start_PAL.clock.reset)  # t=0 on next screen flip
            win.callOnFlip(key_start_PAL.clearEvents, eventType='keyboard')  # clear events on next screen flip
        if key_start_PAL.status == STARTED and not waitOnFlip:
            theseKeys = key_start_PAL.getKeys(keyList=['y','n','left','right','space'], ignoreKeys=["escape"], waitRelease=False)
            _key_start_PAL_allKeys.extend(theseKeys)
            if len(_key_start_PAL_allKeys):
                key_start_PAL.keys = _key_start_PAL_allKeys[-1].name  # just the last key pressed
                key_start_PAL.rt = _key_start_PAL_allKeys[-1].rt
                key_start_PAL.duration = _key_start_PAL_allKeys[-1].duration
                # a response ends the routine
                continueRoutine = False
        
        # check for quit (typically the Esc key)
        if defaultKeyboard.getKeys(keyList=["escape"]):
            thisExp.status = FINISHED
        if thisExp.status == FINISHED or endExpNow:
            endExperiment(thisExp, win=win)
            return
        # pause experiment here if requested
        if thisExp.status == PAUSED:
            pauseExperiment(
                thisExp=thisExp, 
                win=win, 
                timers=[routineTimer, globalClock], 
                currentRoutine=Start_PAL,
            )
            # skip the frame we paused on
            continue
        
        # has a Component requested the Routine to end?
        if not continueRoutine:
            Start_PAL.forceEnded = routineForceEnded = True
        # has the Routine been forcibly ended?
        if Start_PAL.forceEnded or routineForceEnded:
            break
        # has every Component finished?
        continueRoutine = False
        for thisComponent in Start_PAL.components:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # --- Ending Routine "Start_PAL" ---
    for thisComponent in Start_PAL.components:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    # store stop times for Start_PAL
    Start_PAL.tStop = globalClock.getTime(format='float')
    Start_PAL.tStopRefresh = tThisFlipGlobal
    thisExp.addData('Start_PAL.stopped', Start_PAL.tStop)
    # check responses
    if key_start_PAL.keys in ['', [], None]:  # No response was made
        key_start_PAL.keys = None
    thisExp.addData('key_start_PAL.keys',key_start_PAL.keys)
    if key_start_PAL.keys != None:  # we had a response
        thisExp.addData('key_start_PAL.rt', key_start_PAL.rt)
        thisExp.addData('key_start_PAL.duration', key_start_PAL.duration)
    thisExp.nextEntry()
    # the Routine "Start_PAL" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # set up handler to look after randomisation of conditions etc
    trial_encode = data.TrialHandler2(
        name='trial_encode',
        nReps=1.0, 
        method='random', 
        extraInfo=expInfo, 
        originPath=-1, 
        trialList=data.importConditions('encode_pairs.xlsx'), 
        seed=None, 
        isTrials=True, 
    )
    thisExp.addLoop(trial_encode)  # add the loop to the experiment
    thisTrial_encode = trial_encode.trialList[0]  # so we can initialise stimuli with some values
    # abbreviate parameter names if possible (e.g. rgb = thisTrial_encode.rgb)
    if thisTrial_encode != None:
        for paramName in thisTrial_encode:
            globals()[paramName] = thisTrial_encode[paramName]
    if thisSession is not None:
        # if running in a Session with a Liaison client, send data up to now
        thisSession.sendExperimentData()
    
    for thisTrial_encode in trial_encode:
        trial_encode.status = STARTED
        if hasattr(thisTrial_encode, 'status'):
            thisTrial_encode.status = STARTED
        currentLoop = trial_encode
        thisExp.timestampOnFlip(win, 'thisRow.t', format=globalClock.format)
        if thisSession is not None:
            # if running in a Session with a Liaison client, send data up to now
            thisSession.sendExperimentData()
        # abbreviate parameter names if possible (e.g. rgb = thisTrial_encode.rgb)
        if thisTrial_encode != None:
            for paramName in thisTrial_encode:
                globals()[paramName] = thisTrial_encode[paramName]
        
        # --- Prepare to start Routine "Encode" ---
        # create an object to store info about Routine Encode
        Encode = data.Routine(
            name='Encode',
            components=[image_scene_encode, image_object_encode, text_rating, slider_cong],
        )
        Encode.status = NOT_STARTED
        continueRoutine = True
        # update component parameters for each repeat
        image_scene_encode.setSize(scene_size)
        image_scene_encode.setImage(scene_encode)
        image_object_encode.setSize(object_size)
        image_object_encode.setImage(object_encode)
        # Run 'Begin Routine' code from code_debugPAL
        print(f"trial {trial_encode.thisN}, image = {scene_encode}")
        print(f"trial {trial_encode.thisN}, image = {object_encode}")
        
        slider_cong.reset()
        # store start times for Encode
        Encode.tStartRefresh = win.getFutureFlipTime(clock=globalClock)
        Encode.tStart = globalClock.getTime(format='float')
        Encode.status = STARTED
        thisExp.addData('Encode.started', Encode.tStart)
        Encode.maxDuration = None
        # keep track of which components have finished
        EncodeComponents = Encode.components
        for thisComponent in Encode.components:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        frameN = -1
        
        # --- Run Routine "Encode" ---
        thisExp.currentRoutine = Encode
        Encode.forceEnded = routineForceEnded = not continueRoutine
        while continueRoutine:
            # if trial has changed, end Routine now
            if hasattr(thisTrial_encode, 'status') and thisTrial_encode.status == STOPPING:
                continueRoutine = False
            # get current time
            t = routineTimer.getTime()
            tThisFlip = win.getFutureFlipTime(clock=routineTimer)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *image_scene_encode* updates
            
            # if image_scene_encode is starting this frame...
            if image_scene_encode.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                image_scene_encode.frameNStart = frameN  # exact frame index
                image_scene_encode.tStart = t  # local t and not account for scr refresh
                image_scene_encode.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(image_scene_encode, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'image_scene_encode.started')
                # update status
                image_scene_encode.status = STARTED
                image_scene_encode.setAutoDraw(True)
            
            # if image_scene_encode is active this frame...
            if image_scene_encode.status == STARTED:
                # update params
                pass
            
            # *image_object_encode* updates
            
            # if image_object_encode is starting this frame...
            if image_object_encode.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                image_object_encode.frameNStart = frameN  # exact frame index
                image_object_encode.tStart = t  # local t and not account for scr refresh
                image_object_encode.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(image_object_encode, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'image_object_encode.started')
                # update status
                image_object_encode.status = STARTED
                image_object_encode.setAutoDraw(True)
            
            # if image_object_encode is active this frame...
            if image_object_encode.status == STARTED:
                # update params
                pass
            
            # *text_rating* updates
            
            # if text_rating is starting this frame...
            if text_rating.status == NOT_STARTED and tThisFlip >= 2.5-frameTolerance:
                # keep track of start time/frame for later
                text_rating.frameNStart = frameN  # exact frame index
                text_rating.tStart = t  # local t and not account for scr refresh
                text_rating.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(text_rating, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'text_rating.started')
                # update status
                text_rating.status = STARTED
                text_rating.setAutoDraw(True)
            
            # if text_rating is active this frame...
            if text_rating.status == STARTED:
                # update params
                pass
            
            # *slider_cong* updates
            
            # if slider_cong is starting this frame...
            if slider_cong.status == NOT_STARTED and tThisFlip >= 2.5-frameTolerance:
                # keep track of start time/frame for later
                slider_cong.frameNStart = frameN  # exact frame index
                slider_cong.tStart = t  # local t and not account for scr refresh
                slider_cong.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(slider_cong, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'slider_cong.started')
                # update status
                slider_cong.status = STARTED
                slider_cong.setAutoDraw(True)
            
            # if slider_cong is active this frame...
            if slider_cong.status == STARTED:
                # update params
                pass
            
            # Check slider_cong for response to end Routine
            if slider_cong.getRating() is not None and slider_cong.status == STARTED:
                continueRoutine = False
            
            # check for quit (typically the Esc key)
            if defaultKeyboard.getKeys(keyList=["escape"]):
                thisExp.status = FINISHED
            if thisExp.status == FINISHED or endExpNow:
                endExperiment(thisExp, win=win)
                return
            # pause experiment here if requested
            if thisExp.status == PAUSED:
                pauseExperiment(
                    thisExp=thisExp, 
                    win=win, 
                    timers=[routineTimer, globalClock], 
                    currentRoutine=Encode,
                )
                # skip the frame we paused on
                continue
            
            # has a Component requested the Routine to end?
            if not continueRoutine:
                Encode.forceEnded = routineForceEnded = True
            # has the Routine been forcibly ended?
            if Encode.forceEnded or routineForceEnded:
                break
            # has every Component finished?
            continueRoutine = False
            for thisComponent in Encode.components:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # --- Ending Routine "Encode" ---
        for thisComponent in Encode.components:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        # store stop times for Encode
        Encode.tStop = globalClock.getTime(format='float')
        Encode.tStopRefresh = tThisFlipGlobal
        thisExp.addData('Encode.stopped', Encode.tStop)
        trial_encode.addData('slider_cong.response', slider_cong.getRating())
        trial_encode.addData('slider_cong.rt', slider_cong.getRT())
        # the Routine "Encode" was not non-slip safe, so reset the non-slip timer
        routineTimer.reset()
        
        # --- Prepare to start Routine "blank" ---
        # create an object to store info about Routine blank
        blank = data.Routine(
            name='blank',
            components=[cross_25, image_blank],
        )
        blank.status = NOT_STARTED
        continueRoutine = True
        # update component parameters for each repeat
        # store start times for blank
        blank.tStartRefresh = win.getFutureFlipTime(clock=globalClock)
        blank.tStart = globalClock.getTime(format='float')
        blank.status = STARTED
        thisExp.addData('blank.started', blank.tStart)
        blank.maxDuration = None
        # keep track of which components have finished
        blankComponents = blank.components
        for thisComponent in blank.components:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        frameN = -1
        
        # --- Run Routine "blank" ---
        thisExp.currentRoutine = blank
        blank.forceEnded = routineForceEnded = not continueRoutine
        while continueRoutine and routineTimer.getTime() < 2.5:
            # if trial has changed, end Routine now
            if hasattr(thisTrial_encode, 'status') and thisTrial_encode.status == STOPPING:
                continueRoutine = False
            # get current time
            t = routineTimer.getTime()
            tThisFlip = win.getFutureFlipTime(clock=routineTimer)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *cross_25* updates
            
            # if cross_25 is starting this frame...
            if cross_25.status == NOT_STARTED and tThisFlip >= 2.25-frameTolerance:
                # keep track of start time/frame for later
                cross_25.frameNStart = frameN  # exact frame index
                cross_25.tStart = t  # local t and not account for scr refresh
                cross_25.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(cross_25, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'cross_25.started')
                # update status
                cross_25.status = STARTED
                cross_25.setAutoDraw(True)
            
            # if cross_25 is active this frame...
            if cross_25.status == STARTED:
                # update params
                pass
            
            # if cross_25 is stopping this frame...
            if cross_25.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > cross_25.tStartRefresh + 0.25-frameTolerance:
                    # keep track of stop time/frame for later
                    cross_25.tStop = t  # not accounting for scr refresh
                    cross_25.tStopRefresh = tThisFlipGlobal  # on global time
                    cross_25.frameNStop = frameN  # exact frame index
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'cross_25.stopped')
                    # update status
                    cross_25.status = FINISHED
                    cross_25.setAutoDraw(False)
            
            # *image_blank* updates
            
            # if image_blank is starting this frame...
            if image_blank.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                image_blank.frameNStart = frameN  # exact frame index
                image_blank.tStart = t  # local t and not account for scr refresh
                image_blank.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(image_blank, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'image_blank.started')
                # update status
                image_blank.status = STARTED
                image_blank.setAutoDraw(True)
            
            # if image_blank is active this frame...
            if image_blank.status == STARTED:
                # update params
                pass
            
            # if image_blank is stopping this frame...
            if image_blank.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > image_blank.tStartRefresh + 2.25-frameTolerance:
                    # keep track of stop time/frame for later
                    image_blank.tStop = t  # not accounting for scr refresh
                    image_blank.tStopRefresh = tThisFlipGlobal  # on global time
                    image_blank.frameNStop = frameN  # exact frame index
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'image_blank.stopped')
                    # update status
                    image_blank.status = FINISHED
                    image_blank.setAutoDraw(False)
            
            # check for quit (typically the Esc key)
            if defaultKeyboard.getKeys(keyList=["escape"]):
                thisExp.status = FINISHED
            if thisExp.status == FINISHED or endExpNow:
                endExperiment(thisExp, win=win)
                return
            # pause experiment here if requested
            if thisExp.status == PAUSED:
                pauseExperiment(
                    thisExp=thisExp, 
                    win=win, 
                    timers=[routineTimer, globalClock], 
                    currentRoutine=blank,
                )
                # skip the frame we paused on
                continue
            
            # has a Component requested the Routine to end?
            if not continueRoutine:
                blank.forceEnded = routineForceEnded = True
            # has the Routine been forcibly ended?
            if blank.forceEnded or routineForceEnded:
                break
            # has every Component finished?
            continueRoutine = False
            for thisComponent in blank.components:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # --- Ending Routine "blank" ---
        for thisComponent in blank.components:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        # store stop times for blank
        blank.tStop = globalClock.getTime(format='float')
        blank.tStopRefresh = tThisFlipGlobal
        thisExp.addData('blank.stopped', blank.tStop)
        # using non-slip timing so subtract the expected duration of this Routine (unless ended on request)
        if blank.maxDurationReached:
            routineTimer.addTime(-blank.maxDuration)
        elif blank.forceEnded:
            routineTimer.reset()
        else:
            routineTimer.addTime(-2.500000)
        # mark thisTrial_encode as finished
        if hasattr(thisTrial_encode, 'status'):
            thisTrial_encode.status = FINISHED
        # if awaiting a pause, pause now
        if trial_encode.status == PAUSED:
            thisExp.status = PAUSED
            pauseExperiment(
                thisExp=thisExp, 
                win=win, 
                timers=[globalClock], 
            )
            # once done pausing, restore running status
            trial_encode.status = STARTED
        thisExp.nextEntry()
        
    # completed 1.0 repeats of 'trial_encode'
    trial_encode.status = FINISHED
    
    if thisSession is not None:
        # if running in a Session with a Liaison client, send data up to now
        thisSession.sendExperimentData()
    
    # --- Prepare to start Routine "Pause_1" ---
    # create an object to store info about Routine Pause_1
    Pause_1 = data.Routine(
        name='Pause_1',
        components=[text_pausa1, key_Start_Cog],
    )
    Pause_1.status = NOT_STARTED
    continueRoutine = True
    # update component parameters for each repeat
    # create starting attributes for key_Start_Cog
    key_Start_Cog.keys = []
    key_Start_Cog.rt = []
    _key_Start_Cog_allKeys = []
    # store start times for Pause_1
    Pause_1.tStartRefresh = win.getFutureFlipTime(clock=globalClock)
    Pause_1.tStart = globalClock.getTime(format='float')
    Pause_1.status = STARTED
    thisExp.addData('Pause_1.started', Pause_1.tStart)
    Pause_1.maxDuration = None
    # keep track of which components have finished
    Pause_1Components = Pause_1.components
    for thisComponent in Pause_1.components:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    frameN = -1
    
    # --- Run Routine "Pause_1" ---
    thisExp.currentRoutine = Pause_1
    Pause_1.forceEnded = routineForceEnded = not continueRoutine
    while continueRoutine:
        # get current time
        t = routineTimer.getTime()
        tThisFlip = win.getFutureFlipTime(clock=routineTimer)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *text_pausa1* updates
        
        # if text_pausa1 is starting this frame...
        if text_pausa1.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            text_pausa1.frameNStart = frameN  # exact frame index
            text_pausa1.tStart = t  # local t and not account for scr refresh
            text_pausa1.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(text_pausa1, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'text_pausa1.started')
            # update status
            text_pausa1.status = STARTED
            text_pausa1.setAutoDraw(True)
        
        # if text_pausa1 is active this frame...
        if text_pausa1.status == STARTED:
            # update params
            pass
        
        # *key_Start_Cog* updates
        waitOnFlip = False
        
        # if key_Start_Cog is starting this frame...
        if key_Start_Cog.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            key_Start_Cog.frameNStart = frameN  # exact frame index
            key_Start_Cog.tStart = t  # local t and not account for scr refresh
            key_Start_Cog.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(key_Start_Cog, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'key_Start_Cog.started')
            # update status
            key_Start_Cog.status = STARTED
            # keyboard checking is just starting
            waitOnFlip = True
            win.callOnFlip(key_Start_Cog.clock.reset)  # t=0 on next screen flip
            win.callOnFlip(key_Start_Cog.clearEvents, eventType='keyboard')  # clear events on next screen flip
        if key_Start_Cog.status == STARTED and not waitOnFlip:
            theseKeys = key_Start_Cog.getKeys(keyList=['space'], ignoreKeys=["escape"], waitRelease=False)
            _key_Start_Cog_allKeys.extend(theseKeys)
            if len(_key_Start_Cog_allKeys):
                key_Start_Cog.keys = _key_Start_Cog_allKeys[-1].name  # just the last key pressed
                key_Start_Cog.rt = _key_Start_Cog_allKeys[-1].rt
                key_Start_Cog.duration = _key_Start_Cog_allKeys[-1].duration
                # a response ends the routine
                continueRoutine = False
        
        # check for quit (typically the Esc key)
        if defaultKeyboard.getKeys(keyList=["escape"]):
            thisExp.status = FINISHED
        if thisExp.status == FINISHED or endExpNow:
            endExperiment(thisExp, win=win)
            return
        # pause experiment here if requested
        if thisExp.status == PAUSED:
            pauseExperiment(
                thisExp=thisExp, 
                win=win, 
                timers=[routineTimer, globalClock], 
                currentRoutine=Pause_1,
            )
            # skip the frame we paused on
            continue
        
        # has a Component requested the Routine to end?
        if not continueRoutine:
            Pause_1.forceEnded = routineForceEnded = True
        # has the Routine been forcibly ended?
        if Pause_1.forceEnded or routineForceEnded:
            break
        # has every Component finished?
        continueRoutine = False
        for thisComponent in Pause_1.components:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # --- Ending Routine "Pause_1" ---
    for thisComponent in Pause_1.components:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    # store stop times for Pause_1
    Pause_1.tStop = globalClock.getTime(format='float')
    Pause_1.tStopRefresh = tThisFlipGlobal
    thisExp.addData('Pause_1.stopped', Pause_1.tStop)
    # check responses
    if key_Start_Cog.keys in ['', [], None]:  # No response was made
        key_Start_Cog.keys = None
    thisExp.addData('key_Start_Cog.keys',key_Start_Cog.keys)
    if key_Start_Cog.keys != None:  # we had a response
        thisExp.addData('key_Start_Cog.rt', key_Start_Cog.rt)
        thisExp.addData('key_Start_Cog.duration', key_Start_Cog.duration)
    thisExp.nextEntry()
    # the Routine "Pause_1" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # --- Prepare to start Routine "Explanation_GoNo" ---
    # create an object to store info about Routine Explanation_GoNo
    Explanation_GoNo = data.Routine(
        name='Explanation_GoNo',
        components=[text_explanation_GoNo, key_gonogo_start],
    )
    Explanation_GoNo.status = NOT_STARTED
    continueRoutine = True
    # update component parameters for each repeat
    # create starting attributes for key_gonogo_start
    key_gonogo_start.keys = []
    key_gonogo_start.rt = []
    _key_gonogo_start_allKeys = []
    # store start times for Explanation_GoNo
    Explanation_GoNo.tStartRefresh = win.getFutureFlipTime(clock=globalClock)
    Explanation_GoNo.tStart = globalClock.getTime(format='float')
    Explanation_GoNo.status = STARTED
    thisExp.addData('Explanation_GoNo.started', Explanation_GoNo.tStart)
    Explanation_GoNo.maxDuration = None
    # keep track of which components have finished
    Explanation_GoNoComponents = Explanation_GoNo.components
    for thisComponent in Explanation_GoNo.components:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    frameN = -1
    
    # --- Run Routine "Explanation_GoNo" ---
    thisExp.currentRoutine = Explanation_GoNo
    Explanation_GoNo.forceEnded = routineForceEnded = not continueRoutine
    while continueRoutine:
        # get current time
        t = routineTimer.getTime()
        tThisFlip = win.getFutureFlipTime(clock=routineTimer)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *text_explanation_GoNo* updates
        
        # if text_explanation_GoNo is starting this frame...
        if text_explanation_GoNo.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            text_explanation_GoNo.frameNStart = frameN  # exact frame index
            text_explanation_GoNo.tStart = t  # local t and not account for scr refresh
            text_explanation_GoNo.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(text_explanation_GoNo, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'text_explanation_GoNo.started')
            # update status
            text_explanation_GoNo.status = STARTED
            text_explanation_GoNo.setAutoDraw(True)
        
        # if text_explanation_GoNo is active this frame...
        if text_explanation_GoNo.status == STARTED:
            # update params
            pass
        
        # *key_gonogo_start* updates
        waitOnFlip = False
        
        # if key_gonogo_start is starting this frame...
        if key_gonogo_start.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            key_gonogo_start.frameNStart = frameN  # exact frame index
            key_gonogo_start.tStart = t  # local t and not account for scr refresh
            key_gonogo_start.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(key_gonogo_start, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'key_gonogo_start.started')
            # update status
            key_gonogo_start.status = STARTED
            # keyboard checking is just starting
            waitOnFlip = True
            win.callOnFlip(key_gonogo_start.clock.reset)  # t=0 on next screen flip
            win.callOnFlip(key_gonogo_start.clearEvents, eventType='keyboard')  # clear events on next screen flip
        if key_gonogo_start.status == STARTED and not waitOnFlip:
            theseKeys = key_gonogo_start.getKeys(keyList=['space'], ignoreKeys=["escape"], waitRelease=False)
            _key_gonogo_start_allKeys.extend(theseKeys)
            if len(_key_gonogo_start_allKeys):
                key_gonogo_start.keys = _key_gonogo_start_allKeys[-1].name  # just the last key pressed
                key_gonogo_start.rt = _key_gonogo_start_allKeys[-1].rt
                key_gonogo_start.duration = _key_gonogo_start_allKeys[-1].duration
                # a response ends the routine
                continueRoutine = False
        
        # check for quit (typically the Esc key)
        if defaultKeyboard.getKeys(keyList=["escape"]):
            thisExp.status = FINISHED
        if thisExp.status == FINISHED or endExpNow:
            endExperiment(thisExp, win=win)
            return
        # pause experiment here if requested
        if thisExp.status == PAUSED:
            pauseExperiment(
                thisExp=thisExp, 
                win=win, 
                timers=[routineTimer, globalClock], 
                currentRoutine=Explanation_GoNo,
            )
            # skip the frame we paused on
            continue
        
        # has a Component requested the Routine to end?
        if not continueRoutine:
            Explanation_GoNo.forceEnded = routineForceEnded = True
        # has the Routine been forcibly ended?
        if Explanation_GoNo.forceEnded or routineForceEnded:
            break
        # has every Component finished?
        continueRoutine = False
        for thisComponent in Explanation_GoNo.components:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # --- Ending Routine "Explanation_GoNo" ---
    for thisComponent in Explanation_GoNo.components:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    # store stop times for Explanation_GoNo
    Explanation_GoNo.tStop = globalClock.getTime(format='float')
    Explanation_GoNo.tStopRefresh = tThisFlipGlobal
    thisExp.addData('Explanation_GoNo.stopped', Explanation_GoNo.tStop)
    # check responses
    if key_gonogo_start.keys in ['', [], None]:  # No response was made
        key_gonogo_start.keys = None
    thisExp.addData('key_gonogo_start.keys',key_gonogo_start.keys)
    if key_gonogo_start.keys != None:  # we had a response
        thisExp.addData('key_gonogo_start.rt', key_gonogo_start.rt)
        thisExp.addData('key_gonogo_start.duration', key_gonogo_start.duration)
    thisExp.nextEntry()
    # the Routine "Explanation_GoNo" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # --- Prepare to start Go/No-Go Task (com múltiplos trials) ---
    # Criar lista de trials Go/No-Go
    gonogo_trials = []
    
    # 20 trials GO (deve pressionar espaço)
    for i in range(20):
        gonogo_trials.append({
            'trial_type': 'go',
            'signal_image': 'gosignal.png',  # Substitua pelo caminho real da imagem
            'feedback_image': 'error_type2.png'  # Erro de omissão
        })
    
    # 5 trials NO-GO (não deve pressionar)
    for i in range(5):
        gonogo_trials.append({
            'trial_type': 'nogo',
            'signal_image': 'nogosignal.png',  # Substitua pelo caminho real da imagem
            'feedback_image': 'error_type1.png'  # Erro de comissão
        })
    
    # Aleatorizar a ordem dos trials
    shuffle(gonogo_trials)
    
    # Criar TrialHandler para gerenciar os trials
    gonogo_handler = data.TrialHandler2(
        name='gonogo_handler',
        nReps=1.0,
        method='sequential',  # Já aleatorizamos a lista
        extraInfo=expInfo,
        originPath=-1,
        trialList=gonogo_trials,
        seed=None,
        isTrials=True,
    )
    thisExp.addLoop(gonogo_handler)
    
    # Executar cada trial
    for thisGonogo in gonogo_handler:
        gonogo_handler.status = STARTED
        currentLoop = gonogo_handler
        thisExp.timestampOnFlip(win, 'thisRow.t', format=globalClock.format)
        
        # --- Prepare to start Routine "GoNoGo_Trial" ---
        GoNoGo_Trial = data.Routine(
            name='GoNoGo_Trial',
            components=[image_gonogo_signal, image_gonogo_feedback, key_gonogo_response],
        )
        GoNoGo_Trial.status = NOT_STARTED
        continueRoutine = True
        
        # Configurar componentes para este trial
        image_gonogo_signal.setImage(thisGonogo['signal_image'])
        image_gonogo_feedback.setImage(None)  # Sem feedback inicial
        
        # Reset do teclado
        key_gonogo_response.keys = []
        key_gonogo_response.rt = []
        _key_gonogo_response_allKeys = []
        
        # Variáveis para este trial
        responded = False
        response_rt = None
        
        # Tempo de início
        GoNoGo_Trial.tStart = globalClock.getTime()
        GoNoGo_Trial.status = STARTED
        thisExp.addData('GoNoGo_Trial.started', GoNoGo_Trial.tStart)
        
        # Timer para o trial (2 segundos)
        trial_timer = core.Clock()
        
        # --- Mostrar sinal e aguardar resposta (2 segundos) ---
        while trial_timer.getTime() < 2.0 and not responded:
            image_gonogo_signal.draw()
            win.flip()
            
            # Verificar se o espaço foi pressionado
            theseKeys = key_gonogo_response.getKeys(keyList=['space'], ignoreKeys=["escape"], waitRelease=False)
            if len(theseKeys) > 0:
                responded = True
                response_rt = trial_timer.getTime()
                key_gonogo_response.keys = theseKeys[-1].name
                key_gonogo_response.rt = response_rt
        
        # Se o tempo acabou sem resposta
        if not responded and trial_timer.getTime() >= 2.0:
            response_rt = None
        
        # Verificar se houve erro
        error_occurred = False
        if thisGonogo['trial_type'] == 'go':
            if not responded:  # Não respondeu quando devia (erro de omissão)
                error_occurred = True
        else:  # trial_type == 'nogo'
            if responded:  # Respondeu quando não devia (erro de comissão)
                error_occurred = True
        
        # Mostrar feedback se houver erro
        if error_occurred:
            image_gonogo_feedback.setImage(thisGonogo['feedback_image'])
            feedback_timer = core.Clock()
            while feedback_timer.getTime() < 2.0:
                image_gonogo_feedback.draw()
                win.flip()
        
        # Intervalo entre trials (0.5 segundos)
        iti_timer = core.Clock()
        while iti_timer.getTime() < 0.5:
            win.flip()
        
        # Guardar dados
        gonogo_handler.addData('trial_type', thisGonogo['trial_type'])
        gonogo_handler.addData('responded', responded)
        gonogo_handler.addData('response_rt', response_rt)
        gonogo_handler.addData('error_occurred', error_occurred)
        
        # Marcar fim da rot

    ##Raquel
    
    # --- Initialize components for Routine "Cog_Oral" ---
    text_endGo = visual.TextStim(win=win, name='text_endGo',
        text='Tarefa concluída.',
        font='Arial',
        pos=(0, 0), draggable=False, height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=0.0);
    text_call = visual.TextStim(win=win, name='text_call',
        text='O experimentador vem agora ter contigo para duas tarefas orais.',
        font='Arial',
        pos=(0, 0), draggable=False, height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-1.0);
    key_end_cog = keyboard.Keyboard(deviceName='defaultKeyboard')
    
    # --- Initialize components for Routine "Retomar" ---
    text_retomar = visual.TextStim(win=win, name='text_retomar',
        text='Pronto para os testes de memória?\nPrime ESPAÇO para a explicação das tarefas.',
        font='Arial',
        pos=(0, 0), draggable=False, height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=0.0);
    key_resp = keyboard.Keyboard(deviceName='defaultKeyboard')
    
    # --- Initialize components for Routine "Explanation_Recall" ---
    text_explain_recall = visual.TextStim(win=win, name='text_explain_recall',
        text='Vamos fazer agora duas tarefas para testar a tua memória. \nSerá que te lembras dos pares de imagens?\n\n\nPrime ESPAÇO para continuar',
        font='Arial',
        pos=(0, 0), draggable=False, height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=0.0);
    key_continue = keyboard.Keyboard(deviceName='defaultKeyboard')
    
    # --- Initialize components for Routine "Explain_Old_New" ---
    text_explain_old_new = visual.TextStim(win=win, name='text_explain_old_new',
        text="No primeiro teste de memória, vamos apresentar imagens de cenas.\nSe reconheceres a imagem como sendo uma das que aprendeste, prime a FLECHA ESQUERDA '<-' ou na TECLA 'V'\n\nSe a imagem for nova, que não faz parte das imagens que aprendeste, então prime a FLECHA DIREITA '->' ou na TECLA 'N'.\n\nTens 2,5 segundos. Se depois de primires um botão mudares de ideias, basta primir a outra flecha.\nPrime ESPAÇO para um exemplo\n",
        font='Arial',
        pos=(0, 0), draggable=False, height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=0.0);
    key_explain_old = keyboard.Keyboard(deviceName='defaultKeyboard')
    
    # --- Initialize components for Routine "Exemplo_old" ---
    image_exemplo_old_new = visual.ImageStim(
        win=win,
        name='image_exemplo_old_new', units='pix', 
        image='default.png', mask=None, anchor='center',
        ori=0.0, pos=(0, 0), draggable=False, size=1.0,
        color=[1,1,1], colorSpace='rgb', opacity=None,
        flipHoriz=True, flipVert=False,
        texRes=128.0, interpolate=True, depth=0.0)
    key_ex_old = keyboard.Keyboard(deviceName='defaultKeyboard')
    text_ex_old = visual.TextStim(win=win, name='text_ex_old',
        text='Prime <- ou V se a imagem for VELHA\n\nPrime -> ou N se a imagem for NOVA',
        font='Arial',
        pos=(0, 0.3), draggable=False, height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-2.0);
    
    # --- Initialize components for Routine "blank" ---
    cross_25 = visual.ShapeStim(
        win=win, name='cross_25', vertices='cross',
        size=(0.25, 0.25),
        ori=0.0, pos=(0, 0), draggable=False, anchor='center',
        lineWidth=1.0,
        colorSpace='rgb', lineColor='white', fillColor='white',
        opacity=None, depth=0.0, interpolate=True)
    image_blank = visual.ImageStim(
        win=win,
        name='image_blank', 
        image=None, mask=None, anchor='center',
        ori=0.0, pos=(0, 0), draggable=False, size=(0.5, 0.5),
        color=[1,1,1], colorSpace='rgb', opacity=None,
        flipHoriz=False, flipVert=False,
        texRes=128.0, interpolate=True, depth=-1.0)
    
    # --- Initialize components for Routine "Start_Recall" ---
    text_start_recall = visual.TextStim(win=win, name='text_start_recall',
        text='Exemplo concluído. Se tiveres dúvidas, chama o experimentador.\n\n\nPrime ESPAÇO para começar o teste',
        font='Arial',
        pos=(0, 0), draggable=False, height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=0.0);
    key_start_recall = keyboard.Keyboard(deviceName='defaultKeyboard')
    
    # --- Initialize components for Routine "Old_New" ---
    image_old_new = visual.ImageStim(
        win=win,
        name='image_old_new', units='pix', 
        image='default.png', mask=None, anchor='center',
        ori=0.0, pos=(0, -0.08), draggable=False, size=1.0,
        color=[1,1,1], colorSpace='rgb', opacity=None,
        flipHoriz=False, flipVert=False,
        texRes=128.0, interpolate=True, depth=0.0)
    key_item = keyboard.Keyboard(deviceName='defaultKeyboard')
    text_item = visual.TextStim(win=win, name='text_item',
        text="Prime a flecha esquerda '<-' ou 'v' para VELHAS imagens\n\nPrime a flecha direita '->' ou 'n' para NOVAS imagens",
        font='Arial',
        pos=(0, 0.35), draggable=False, height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-2.0);
    
    # --- Initialize components for Routine "blank" ---
    cross_25 = visual.ShapeStim(
        win=win, name='cross_25', vertices='cross',
        size=(0.25, 0.25),
        ori=0.0, pos=(0, 0), draggable=False, anchor='center',
        lineWidth=1.0,
        colorSpace='rgb', lineColor='white', fillColor='white',
        opacity=None, depth=0.0, interpolate=True)
    image_blank = visual.ImageStim(
        win=win,
        name='image_blank', 
        image=None, mask=None, anchor='center',
        ori=0.0, pos=(0, 0), draggable=False, size=(0.5, 0.5),
        color=[1,1,1], colorSpace='rgb', opacity=None,
        flipHoriz=False, flipVert=False,
        texRes=128.0, interpolate=True, depth=-1.0)
    
    # --- Initialize components for Routine "End_Old_New" ---
    text_end_item = visual.TextStim(win=win, name='text_end_item',
        text='Tarefa concluída. Só falta mais uma.\nPrime ESPAÇO quando estiveres pronto para a explicação do segundo teste.',
        font='Arial',
        pos=(0, 0), draggable=False, height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=0.0);
    key_resp_2 = keyboard.Keyboard(deviceName='defaultKeyboard')
    
    # --- Initialize components for Routine "Explain_2AFC" ---
    text_explain_2afc = visual.TextStim(win=win, name='text_explain_2afc',
        text='Vão aparecer três imagens: uma cena que viste anteriormente, e dois objetos.\nUm dos objetos viste antes associado à cena,  durante a aprendizagem. \nSe o objeto associado estiver em cima, prime a FLECHA de CIMA. Se o objeto associado for o de baixo, prime a FLECHA de BAIXO.\n\nTens 2,5 segundos. Se depois de primires um botão mudares de ideias, basta primir a outra flecha.\n\nPrime ESPAÇO para um exemplo. ',
        font='Arial',
        pos=(0, 0), draggable=False, height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=0.0);
    key_end_explain_2afc = keyboard.Keyboard(deviceName='defaultKeyboard')
    
    # --- Initialize components for Routine "Exemplo_2AFC" ---
    image_ex_2AFC = visual.ImageStim(
        win=win,
        name='image_ex_2AFC', units='pix', 
        image='default.png', mask=None, anchor='center',
        ori=0.0, pos=(-200, 0), draggable=False, size=1.0,
        color=[1,1,1], colorSpace='rgb', opacity=None,
        flipHoriz=False, flipVert=False,
        texRes=128.0, interpolate=True, depth=0.0)
    image_ex_target = visual.ImageStim(
        win=win,
        name='image_ex_target', units='pix', 
        image='default.png', mask=None, anchor='center',
        ori=0.0, pos=[0,0], draggable=False, size=1.0,
        color=[1,1,1], colorSpace='rgb', opacity=None,
        flipHoriz=False, flipVert=False,
        texRes=128.0, interpolate=True, depth=-1.0)
    image_ex_lure = visual.ImageStim(
        win=win,
        name='image_ex_lure', units='pix', 
        image='default.png', mask=None, anchor='center',
        ori=0.0, pos=[0,0], draggable=False, size=1.0,
        color=[1,1,1], colorSpace='rgb', opacity=None,
        flipHoriz=False, flipVert=False,
        texRes=128.0, interpolate=True, depth=-2.0)
    key_ex_2AFC = keyboard.Keyboard(deviceName='defaultKeyboard')
    
    # --- Initialize components for Routine "blank" ---
    cross_25 = visual.ShapeStim(
        win=win, name='cross_25', vertices='cross',
        size=(0.25, 0.25),
        ori=0.0, pos=(0, 0), draggable=False, anchor='center',
        lineWidth=1.0,
        colorSpace='rgb', lineColor='white', fillColor='white',
        opacity=None, depth=0.0, interpolate=True)
    image_blank = visual.ImageStim(
        win=win,
        name='image_blank', 
        image=None, mask=None, anchor='center',
        ori=0.0, pos=(0, 0), draggable=False, size=(0.5, 0.5),
        color=[1,1,1], colorSpace='rgb', opacity=None,
        flipHoriz=False, flipVert=False,
        texRes=128.0, interpolate=True, depth=-1.0)
    
    # --- Initialize components for Routine "Start_Recall" ---
    text_start_recall = visual.TextStim(win=win, name='text_start_recall',
        text='Exemplo concluído. Se tiveres dúvidas, chama o experimentador.\n\n\nPrime ESPAÇO para começar o teste',
        font='Arial',
        pos=(0, 0), draggable=False, height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=0.0);
    key_start_recall = keyboard.Keyboard(deviceName='defaultKeyboard')
    
    # --- Initialize components for Routine "trial_2AFC" ---
    image_scene_2AFC = visual.ImageStim(
        win=win,
        name='image_scene_2AFC', units='pix', 
        image='default.png', mask=None, anchor='center',
        ori=0.0, pos=(-250, 0), draggable=False, size=1.0,
        color=[1,1,1], colorSpace='rgb', opacity=None,
        flipHoriz=False, flipVert=False,
        texRes=128.0, interpolate=True, depth=0.0)
    key_2AFC = keyboard.Keyboard(deviceName='defaultKeyboard')
    image_target = visual.ImageStim(
        win=win,
        name='image_target', units='pix', 
        image='default.png', mask=None, anchor='center',
        ori=0.0, pos=[0,0], draggable=False, size=1.0,
        color=[1,1,1], colorSpace='rgb', opacity=None,
        flipHoriz=True, flipVert=False,
        texRes=128.0, interpolate=True, depth=-2.0)
    image_lure = visual.ImageStim(
        win=win,
        name='image_lure', units='pix', 
        image='default.png', mask=None, anchor='center',
        ori=0.0, pos=[0,0], draggable=False, size=1.0,
        color=[1,1,1], colorSpace='rgb', opacity=None,
        flipHoriz=False, flipVert=False,
        texRes=128.0, interpolate=True, depth=-3.0)
    
    # --- Initialize components for Routine "blank" ---
    cross_25 = visual.ShapeStim(
        win=win, name='cross_25', vertices='cross',
        size=(0.25, 0.25),
        ori=0.0, pos=(0, 0), draggable=False, anchor='center',
        lineWidth=1.0,
        colorSpace='rgb', lineColor='white', fillColor='white',
        opacity=None, depth=0.0, interpolate=True)
    image_blank = visual.ImageStim(
        win=win,
        name='image_blank', 
        image=None, mask=None, anchor='center',
        ori=0.0, pos=(0, 0), draggable=False, size=(0.5, 0.5),
        color=[1,1,1], colorSpace='rgb', opacity=None,
        flipHoriz=False, flipVert=False,
        texRes=128.0, interpolate=True, depth=-1.0)
    
    # --- Initialize components for Routine "end" ---
    text_end = visual.TextStim(win=win, name='text_end',
        text='Experiência concluída.\nObrigada por participares!',
        font='Arial',
        pos=(0, 0), draggable=False, height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=0.0);
    
    # create some handy timers
    
    # global clock to track the time since experiment started
    if globalClock is None:
        # create a clock if not given one
        globalClock = core.Clock()
    if isinstance(globalClock, str):
        # if given a string, make a clock accoridng to it
        if globalClock == 'float':
            # get timestamps as a simple value
            globalClock = core.Clock(format='float')
        elif globalClock == 'iso':
            # get timestamps in ISO format
            globalClock = core.Clock(format='%Y-%m-%d_%H:%M:%S.%f%z')
        else:
            # get timestamps in a custom format
            globalClock = core.Clock(format=globalClock)
    if ioServer is not None:
        ioServer.syncClock(globalClock)
    logging.setDefaultClock(globalClock)
    if eyetracker is not None:
        eyetracker.enableEventReporting()
    # routine timer to track time remaining of each (possibly non-slip) routine
    routineTimer = core.Clock()
    win.flip()  # flip window to reset last flip timer
    # store the exact time the global clock started
    expInfo['expStart'] = data.getDateStr(
        format='%Y-%m-%d %Hh%M.%S.%f %z', fractionalSecondDigits=6
    )
    
    # --- Prepare to start Routine "Welcome" ---
    # create an object to store info about Routine Welcome
    Welcome = data.Routine(
        name='Welcome',
        components=[text_hi, key_welcome],
    )
    Welcome.status = NOT_STARTED
    continueRoutine = True
    # update component parameters for each repeat
    # create starting attributes for key_welcome
    key_welcome.keys = []
    key_welcome.rt = []
    _key_welcome_allKeys = []
    # store start times for Welcome
    Welcome.tStartRefresh = win.getFutureFlipTime(clock=globalClock)
    Welcome.tStart = globalClock.getTime(format='float')
    Welcome.status = STARTED
    thisExp.addData('Welcome.started', Welcome.tStart)
    Welcome.maxDuration = None
    # keep track of which components have finished
    WelcomeComponents = Welcome.components
    for thisComponent in Welcome.components:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    frameN = -1
    
    # --- Run Routine "Welcome" ---
    thisExp.currentRoutine = Welcome
    Welcome.forceEnded = routineForceEnded = not continueRoutine
    while continueRoutine:
        # get current time
        t = routineTimer.getTime()
        tThisFlip = win.getFutureFlipTime(clock=routineTimer)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *text_hi* updates
        
        # if text_hi is starting this frame...
        if text_hi.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            text_hi.frameNStart = frameN  # exact frame index
            text_hi.tStart = t  # local t and not account for scr refresh
            text_hi.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(text_hi, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'text_hi.started')
            # update status
            text_hi.status = STARTED
            text_hi.setAutoDraw(True)
        
        # if text_hi is active this frame...
        if text_hi.status == STARTED:
            # update params
            pass
        
        # *key_welcome* updates
        waitOnFlip = False
        
        # if key_welcome is starting this frame...
        if key_welcome.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            key_welcome.frameNStart = frameN  # exact frame index
            key_welcome.tStart = t  # local t and not account for scr refresh
            key_welcome.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(key_welcome, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'key_welcome.started')
            # update status
            key_welcome.status = STARTED
            # keyboard checking is just starting
            waitOnFlip = True
            win.callOnFlip(key_welcome.clock.reset)  # t=0 on next screen flip
            win.callOnFlip(key_welcome.clearEvents, eventType='keyboard')  # clear events on next screen flip
        if key_welcome.status == STARTED and not waitOnFlip:
            theseKeys = key_welcome.getKeys(keyList=['y','n','left','right','space'], ignoreKeys=["escape"], waitRelease=False)
            _key_welcome_allKeys.extend(theseKeys)
            if len(_key_welcome_allKeys):
                key_welcome.keys = _key_welcome_allKeys[-1].name  # just the last key pressed
                key_welcome.rt = _key_welcome_allKeys[-1].rt
                key_welcome.duration = _key_welcome_allKeys[-1].duration
                # a response ends the routine
                continueRoutine = False
        
        # check for quit (typically the Esc key)
        if defaultKeyboard.getKeys(keyList=["escape"]):
            thisExp.status = FINISHED
        if thisExp.status == FINISHED or endExpNow:
            endExperiment(thisExp, win=win)
            return
        # pause experiment here if requested
        if thisExp.status == PAUSED:
            pauseExperiment(
                thisExp=thisExp, 
                win=win, 
                timers=[routineTimer, globalClock], 
                currentRoutine=Welcome,
            )
            # skip the frame we paused on
            continue
        
        # has a Component requested the Routine to end?
        if not continueRoutine:
            Welcome.forceEnded = routineForceEnded = True
        # has the Routine been forcibly ended?
        if Welcome.forceEnded or routineForceEnded:
            break
        # has every Component finished?
        continueRoutine = False
        for thisComponent in Welcome.components:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # --- Ending Routine "Welcome" ---
    for thisComponent in Welcome.components:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    # store stop times for Welcome
    Welcome.tStop = globalClock.getTime(format='float')
    Welcome.tStopRefresh = tThisFlipGlobal
    thisExp.addData('Welcome.stopped', Welcome.tStop)
    # check responses
    if key_welcome.keys in ['', [], None]:  # No response was made
        key_welcome.keys = None
    thisExp.addData('key_welcome.keys',key_welcome.keys)
    if key_welcome.keys != None:  # we had a response
        thisExp.addData('key_welcome.rt', key_welcome.rt)
        thisExp.addData('key_welcome.duration', key_welcome.duration)
    thisExp.nextEntry()
    # the Routine "Welcome" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # --- Prepare to start Routine "Explanation_PAL" ---
    # create an object to store info about Routine Explanation_PAL
    Explanation_PAL = data.Routine(
        name='Explanation_PAL',
        components=[text_Explain_PAL, key_start_example],
    )
    Explanation_PAL.status = NOT_STARTED
    continueRoutine = True
    # update component parameters for each repeat
    # create starting attributes for key_start_example
    key_start_example.keys = []
    key_start_example.rt = []
    _key_start_example_allKeys = []
    # store start times for Explanation_PAL
    Explanation_PAL.tStartRefresh = win.getFutureFlipTime(clock=globalClock)
    Explanation_PAL.tStart = globalClock.getTime(format='float')
    Explanation_PAL.status = STARTED
    thisExp.addData('Explanation_PAL.started', Explanation_PAL.tStart)
    Explanation_PAL.maxDuration = None
    # keep track of which components have finished
    Explanation_PALComponents = Explanation_PAL.components
    for thisComponent in Explanation_PAL.components:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    frameN = -1
    
    # --- Run Routine "Explanation_PAL" ---
    thisExp.currentRoutine = Explanation_PAL
    Explanation_PAL.forceEnded = routineForceEnded = not continueRoutine
    while continueRoutine:
        # get current time
        t = routineTimer.getTime()
        tThisFlip = win.getFutureFlipTime(clock=routineTimer)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *text_Explain_PAL* updates
        
        # if text_Explain_PAL is starting this frame...
        if text_Explain_PAL.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            text_Explain_PAL.frameNStart = frameN  # exact frame index
            text_Explain_PAL.tStart = t  # local t and not account for scr refresh
            text_Explain_PAL.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(text_Explain_PAL, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'text_Explain_PAL.started')
            # update status
            text_Explain_PAL.status = STARTED
            text_Explain_PAL.setAutoDraw(True)
        
        # if text_Explain_PAL is active this frame...
        if text_Explain_PAL.status == STARTED:
            # update params
            pass
        
        # *key_start_example* updates
        waitOnFlip = False
        
        # if key_start_example is starting this frame...
        if key_start_example.status == NOT_STARTED and tThisFlip >= 1.0-frameTolerance:
            # keep track of start time/frame for later
            key_start_example.frameNStart = frameN  # exact frame index
            key_start_example.tStart = t  # local t and not account for scr refresh
            key_start_example.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(key_start_example, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'key_start_example.started')
            # update status
            key_start_example.status = STARTED
            # keyboard checking is just starting
            waitOnFlip = True
            win.callOnFlip(key_start_example.clock.reset)  # t=0 on next screen flip
            win.callOnFlip(key_start_example.clearEvents, eventType='keyboard')  # clear events on next screen flip
        if key_start_example.status == STARTED and not waitOnFlip:
            theseKeys = key_start_example.getKeys(keyList=['y','n','left','right','space'], ignoreKeys=["escape"], waitRelease=False)
            _key_start_example_allKeys.extend(theseKeys)
            if len(_key_start_example_allKeys):
                key_start_example.keys = _key_start_example_allKeys[-1].name  # just the last key pressed
                key_start_example.rt = _key_start_example_allKeys[-1].rt
                key_start_example.duration = _key_start_example_allKeys[-1].duration
                # a response ends the routine
                continueRoutine = False
        
        # check for quit (typically the Esc key)
        if defaultKeyboard.getKeys(keyList=["escape"]):
            thisExp.status = FINISHED
        if thisExp.status == FINISHED or endExpNow:
            endExperiment(thisExp, win=win)
            return
        # pause experiment here if requested
        if thisExp.status == PAUSED:
            pauseExperiment(
                thisExp=thisExp, 
                win=win, 
                timers=[routineTimer, globalClock], 
                currentRoutine=Explanation_PAL,
            )
            # skip the frame we paused on
            continue
        
        # has a Component requested the Routine to end?
        if not continueRoutine:
            Explanation_PAL.forceEnded = routineForceEnded = True
        # has the Routine been forcibly ended?
        if Explanation_PAL.forceEnded or routineForceEnded:
            break
        # has every Component finished?
        continueRoutine = False
        for thisComponent in Explanation_PAL.components:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # --- Ending Routine "Explanation_PAL" ---
    for thisComponent in Explanation_PAL.components:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    # store stop times for Explanation_PAL
    Explanation_PAL.tStop = globalClock.getTime(format='float')
    Explanation_PAL.tStopRefresh = tThisFlipGlobal
    thisExp.addData('Explanation_PAL.stopped', Explanation_PAL.tStop)
    # check responses
    if key_start_example.keys in ['', [], None]:  # No response was made
        key_start_example.keys = None
    thisExp.addData('key_start_example.keys',key_start_example.keys)
    if key_start_example.keys != None:  # we had a response
        thisExp.addData('key_start_example.rt', key_start_example.rt)
        thisExp.addData('key_start_example.duration', key_start_example.duration)
    thisExp.nextEntry()
    # the Routine "Explanation_PAL" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # --- Prepare to start Routine "Explain_Rating" ---
    # create an object to store info about Routine Explain_Rating
    Explain_Rating = data.Routine(
        name='Explain_Rating',
        components=[text_explain_rate, key_explainPAL],
    )
    Explain_Rating.status = NOT_STARTED
    continueRoutine = True
    # update component parameters for each repeat
    # create starting attributes for key_explainPAL
    key_explainPAL.keys = []
    key_explainPAL.rt = []
    _key_explainPAL_allKeys = []
    # store start times for Explain_Rating
    Explain_Rating.tStartRefresh = win.getFutureFlipTime(clock=globalClock)
    Explain_Rating.tStart = globalClock.getTime(format='float')
    Explain_Rating.status = STARTED
    thisExp.addData('Explain_Rating.started', Explain_Rating.tStart)
    Explain_Rating.maxDuration = None
    # keep track of which components have finished
    Explain_RatingComponents = Explain_Rating.components
    for thisComponent in Explain_Rating.components:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    frameN = -1
    
    # --- Run Routine "Explain_Rating" ---
    thisExp.currentRoutine = Explain_Rating
    Explain_Rating.forceEnded = routineForceEnded = not continueRoutine
    while continueRoutine:
        # get current time
        t = routineTimer.getTime()
        tThisFlip = win.getFutureFlipTime(clock=routineTimer)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *text_explain_rate* updates
        
        # if text_explain_rate is starting this frame...
        if text_explain_rate.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            text_explain_rate.frameNStart = frameN  # exact frame index
            text_explain_rate.tStart = t  # local t and not account for scr refresh
            text_explain_rate.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(text_explain_rate, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'text_explain_rate.started')
            # update status
            text_explain_rate.status = STARTED
            text_explain_rate.setAutoDraw(True)
        
        # if text_explain_rate is active this frame...
        if text_explain_rate.status == STARTED:
            # update params
            pass
        
        # *key_explainPAL* updates
        waitOnFlip = False
        
        # if key_explainPAL is starting this frame...
        if key_explainPAL.status == NOT_STARTED and tThisFlip >= 1.0-frameTolerance:
            # keep track of start time/frame for later
            key_explainPAL.frameNStart = frameN  # exact frame index
            key_explainPAL.tStart = t  # local t and not account for scr refresh
            key_explainPAL.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(key_explainPAL, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'key_explainPAL.started')
            # update status
            key_explainPAL.status = STARTED
            # keyboard checking is just starting
            waitOnFlip = True
            win.callOnFlip(key_explainPAL.clock.reset)  # t=0 on next screen flip
            win.callOnFlip(key_explainPAL.clearEvents, eventType='keyboard')  # clear events on next screen flip
        if key_explainPAL.status == STARTED and not waitOnFlip:
            theseKeys = key_explainPAL.getKeys(keyList=['y','n','left','right','space'], ignoreKeys=["escape"], waitRelease=False)
            _key_explainPAL_allKeys.extend(theseKeys)
            if len(_key_explainPAL_allKeys):
                key_explainPAL.keys = _key_explainPAL_allKeys[-1].name  # just the last key pressed
                key_explainPAL.rt = _key_explainPAL_allKeys[-1].rt
                key_explainPAL.duration = _key_explainPAL_allKeys[-1].duration
                # a response ends the routine
                continueRoutine = False
        
        # check for quit (typically the Esc key)
        if defaultKeyboard.getKeys(keyList=["escape"]):
            thisExp.status = FINISHED
        if thisExp.status == FINISHED or endExpNow:
            endExperiment(thisExp, win=win)
            return
        # pause experiment here if requested
        if thisExp.status == PAUSED:
            pauseExperiment(
                thisExp=thisExp, 
                win=win, 
                timers=[routineTimer, globalClock], 
                currentRoutine=Explain_Rating,
            )
            # skip the frame we paused on
            continue
        
        # has a Component requested the Routine to end?
        if not continueRoutine:
            Explain_Rating.forceEnded = routineForceEnded = True
        # has the Routine been forcibly ended?
        if Explain_Rating.forceEnded or routineForceEnded:
            break
        # has every Component finished?
        continueRoutine = False
        for thisComponent in Explain_Rating.components:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # --- Ending Routine "Explain_Rating" ---
    for thisComponent in Explain_Rating.components:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    # store stop times for Explain_Rating
    Explain_Rating.tStop = globalClock.getTime(format='float')
    Explain_Rating.tStopRefresh = tThisFlipGlobal
    thisExp.addData('Explain_Rating.stopped', Explain_Rating.tStop)
    # check responses
    if key_explainPAL.keys in ['', [], None]:  # No response was made
        key_explainPAL.keys = None
    thisExp.addData('key_explainPAL.keys',key_explainPAL.keys)
    if key_explainPAL.keys != None:  # we had a response
        thisExp.addData('key_explainPAL.rt', key_explainPAL.rt)
        thisExp.addData('key_explainPAL.duration', key_explainPAL.duration)
    thisExp.nextEntry()
    # the Routine "Explain_Rating" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # set up handler to look after randomisation of conditions etc
    example = data.TrialHandler2(
        name='example',
        nReps=1.0, 
        method='random', 
        extraInfo=expInfo, 
        originPath=-1, 
        trialList=data.importConditions('Exemplo_encode.xlsx'), 
        seed=None, 
        isTrials=True, 
    )
    thisExp.addLoop(example)  # add the loop to the experiment
    thisExample = example.trialList[0]  # so we can initialise stimuli with some values
    # abbreviate parameter names if possible (e.g. rgb = thisExample.rgb)
    if thisExample != None:
        for paramName in thisExample:
            globals()[paramName] = thisExample[paramName]
    if thisSession is not None:
        # if running in a Session with a Liaison client, send data up to now
        thisSession.sendExperimentData()
    
    for thisExample in example:
        example.status = STARTED
        if hasattr(thisExample, 'status'):
            thisExample.status = STARTED
        currentLoop = example
        thisExp.timestampOnFlip(win, 'thisRow.t', format=globalClock.format)
        if thisSession is not None:
            # if running in a Session with a Liaison client, send data up to now
            thisSession.sendExperimentData()
        # abbreviate parameter names if possible (e.g. rgb = thisExample.rgb)
        if thisExample != None:
            for paramName in thisExample:
                globals()[paramName] = thisExample[paramName]
        
        # --- Prepare to start Routine "Example_PAL" ---
        # create an object to store info about Routine Example_PAL
        Example_PAL = data.Routine(
            name='Example_PAL',
            components=[image_ex_scene, image_ex_object, slider_example, text_example],
        )
        Example_PAL.status = NOT_STARTED
        continueRoutine = True
        # update component parameters for each repeat
        image_ex_scene.setSize(scene_size)
        image_ex_scene.setImage(scene_encode)
        image_ex_object.setSize(object_size)
        image_ex_object.setImage(object_encode)
        slider_example.reset()
        # store start times for Example_PAL
        Example_PAL.tStartRefresh = win.getFutureFlipTime(clock=globalClock)
        Example_PAL.tStart = globalClock.getTime(format='float')
        Example_PAL.status = STARTED
        thisExp.addData('Example_PAL.started', Example_PAL.tStart)
        Example_PAL.maxDuration = None
        # keep track of which components have finished
        Example_PALComponents = Example_PAL.components
        for thisComponent in Example_PAL.components:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        frameN = -1
        
        # --- Run Routine "Example_PAL" ---
        thisExp.currentRoutine = Example_PAL
        Example_PAL.forceEnded = routineForceEnded = not continueRoutine
        while continueRoutine:
            # if trial has changed, end Routine now
            if hasattr(thisExample, 'status') and thisExample.status == STOPPING:
                continueRoutine = False
            # get current time
            t = routineTimer.getTime()
            tThisFlip = win.getFutureFlipTime(clock=routineTimer)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *image_ex_scene* updates
            
            # if image_ex_scene is starting this frame...
            if image_ex_scene.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                image_ex_scene.frameNStart = frameN  # exact frame index
                image_ex_scene.tStart = t  # local t and not account for scr refresh
                image_ex_scene.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(image_ex_scene, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'image_ex_scene.started')
                # update status
                image_ex_scene.status = STARTED
                image_ex_scene.setAutoDraw(True)
            
            # if image_ex_scene is active this frame...
            if image_ex_scene.status == STARTED:
                # update params
                pass
            
            # *image_ex_object* updates
            
            # if image_ex_object is starting this frame...
            if image_ex_object.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                image_ex_object.frameNStart = frameN  # exact frame index
                image_ex_object.tStart = t  # local t and not account for scr refresh
                image_ex_object.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(image_ex_object, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'image_ex_object.started')
                # update status
                image_ex_object.status = STARTED
                image_ex_object.setAutoDraw(True)
            
            # if image_ex_object is active this frame...
            if image_ex_object.status == STARTED:
                # update params
                pass
            
            # *slider_example* updates
            
            # if slider_example is starting this frame...
            if slider_example.status == NOT_STARTED and tThisFlip >= 2.5-frameTolerance:
                # keep track of start time/frame for later
                slider_example.frameNStart = frameN  # exact frame index
                slider_example.tStart = t  # local t and not account for scr refresh
                slider_example.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(slider_example, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'slider_example.started')
                # update status
                slider_example.status = STARTED
                slider_example.setAutoDraw(True)
            
            # if slider_example is active this frame...
            if slider_example.status == STARTED:
                # update params
                pass
            
            # Check slider_example for response to end Routine
            if slider_example.getRating() is not None and slider_example.status == STARTED:
                continueRoutine = False
            
            # *text_example* updates
            
            # if text_example is starting this frame...
            if text_example.status == NOT_STARTED and tThisFlip >= 2.5-frameTolerance:
                # keep track of start time/frame for later
                text_example.frameNStart = frameN  # exact frame index
                text_example.tStart = t  # local t and not account for scr refresh
                text_example.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(text_example, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'text_example.started')
                # update status
                text_example.status = STARTED
                text_example.setAutoDraw(True)
            
            # if text_example is active this frame...
            if text_example.status == STARTED:
                # update params
                pass
            
            # check for quit (typically the Esc key)
            if defaultKeyboard.getKeys(keyList=["escape"]):
                thisExp.status = FINISHED
            if thisExp.status == FINISHED or endExpNow:
                endExperiment(thisExp, win=win)
                return
            # pause experiment here if requested
            if thisExp.status == PAUSED:
                pauseExperiment(
                    thisExp=thisExp, 
                    win=win, 
                    timers=[routineTimer, globalClock], 
                    currentRoutine=Example_PAL,
                )
                # skip the frame we paused on
                continue
            
            # has a Component requested the Routine to end?
            if not continueRoutine:
                Example_PAL.forceEnded = routineForceEnded = True
            # has the Routine been forcibly ended?
            if Example_PAL.forceEnded or routineForceEnded:
                break
            # has every Component finished?
            continueRoutine = False
            for thisComponent in Example_PAL.components:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # --- Ending Routine "Example_PAL" ---
        for thisComponent in Example_PAL.components:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        # store stop times for Example_PAL
        Example_PAL.tStop = globalClock.getTime(format='float')
        Example_PAL.tStopRefresh = tThisFlipGlobal
        thisExp.addData('Example_PAL.stopped', Example_PAL.tStop)
        example.addData('slider_example.response', slider_example.getRating())
        example.addData('slider_example.rt', slider_example.getRT())
        # the Routine "Example_PAL" was not non-slip safe, so reset the non-slip timer
        routineTimer.reset()
        
        # --- Prepare to start Routine "blank" ---
        # create an object to store info about Routine blank
        blank = data.Routine(
            name='blank',
            components=[cross_25, image_blank],
        )
        blank.status = NOT_STARTED
        continueRoutine = True
        # update component parameters for each repeat
        # store start times for blank
        blank.tStartRefresh = win.getFutureFlipTime(clock=globalClock)
        blank.tStart = globalClock.getTime(format='float')
        blank.status = STARTED
        thisExp.addData('blank.started', blank.tStart)
        blank.maxDuration = None
        # keep track of which components have finished
        blankComponents = blank.components
        for thisComponent in blank.components:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        frameN = -1
        
        # --- Run Routine "blank" ---
        thisExp.currentRoutine = blank
        blank.forceEnded = routineForceEnded = not continueRoutine
        while continueRoutine and routineTimer.getTime() < 2.5:
            # if trial has changed, end Routine now
            if hasattr(thisExample, 'status') and thisExample.status == STOPPING:
                continueRoutine = False
            # get current time
            t = routineTimer.getTime()
            tThisFlip = win.getFutureFlipTime(clock=routineTimer)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *cross_25* updates
            
            # if cross_25 is starting this frame...
            if cross_25.status == NOT_STARTED and tThisFlip >= 2.25-frameTolerance:
                # keep track of start time/frame for later
                cross_25.frameNStart = frameN  # exact frame index
                cross_25.tStart = t  # local t and not account for scr refresh
                cross_25.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(cross_25, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'cross_25.started')
                # update status
                cross_25.status = STARTED
                cross_25.setAutoDraw(True)
            
            # if cross_25 is active this frame...
            if cross_25.status == STARTED:
                # update params
                pass
            
            # if cross_25 is stopping this frame...
            if cross_25.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > cross_25.tStartRefresh + 0.25-frameTolerance:
                    # keep track of stop time/frame for later
                    cross_25.tStop = t  # not accounting for scr refresh
                    cross_25.tStopRefresh = tThisFlipGlobal  # on global time
                    cross_25.frameNStop = frameN  # exact frame index
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'cross_25.stopped')
                    # update status
                    cross_25.status = FINISHED
                    cross_25.setAutoDraw(False)
            
            # *image_blank* updates
            
            # if image_blank is starting this frame...
            if image_blank.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                image_blank.frameNStart = frameN  # exact frame index
                image_blank.tStart = t  # local t and not account for scr refresh
                image_blank.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(image_blank, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'image_blank.started')
                # update status
                image_blank.status = STARTED
                image_blank.setAutoDraw(True)
            
            # if image_blank is active this frame...
            if image_blank.status == STARTED:
                # update params
                pass
            
            # if image_blank is stopping this frame...
            if image_blank.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > image_blank.tStartRefresh + 2.25-frameTolerance:
                    # keep track of stop time/frame for later
                    image_blank.tStop = t  # not accounting for scr refresh
                    image_blank.tStopRefresh = tThisFlipGlobal  # on global time
                    image_blank.frameNStop = frameN  # exact frame index
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'image_blank.stopped')
                    # update status
                    image_blank.status = FINISHED
                    image_blank.setAutoDraw(False)
            
            # check for quit (typically the Esc key)
            if defaultKeyboard.getKeys(keyList=["escape"]):
                thisExp.status = FINISHED
            if thisExp.status == FINISHED or endExpNow:
                endExperiment(thisExp, win=win)
                return
            # pause experiment here if requested
            if thisExp.status == PAUSED:
                pauseExperiment(
                    thisExp=thisExp, 
                    win=win, 
                    timers=[routineTimer, globalClock], 
                    currentRoutine=blank,
                )
                # skip the frame we paused on
                continue
            
            # has a Component requested the Routine to end?
            if not continueRoutine:
                blank.forceEnded = routineForceEnded = True
            # has the Routine been forcibly ended?
            if blank.forceEnded or routineForceEnded:
                break
            # has every Component finished?
            continueRoutine = False
            for thisComponent in blank.components:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # --- Ending Routine "blank" ---
        for thisComponent in blank.components:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        # store stop times for blank
        blank.tStop = globalClock.getTime(format='float')
        blank.tStopRefresh = tThisFlipGlobal
        thisExp.addData('blank.stopped', blank.tStop)
        # using non-slip timing so subtract the expected duration of this Routine (unless ended on request)
        if blank.maxDurationReached:
            routineTimer.addTime(-blank.maxDuration)
        elif blank.forceEnded:
            routineTimer.reset()
        else:
            routineTimer.addTime(-2.500000)
        # mark thisExample as finished
        if hasattr(thisExample, 'status'):
            thisExample.status = FINISHED
        # if awaiting a pause, pause now
        if example.status == PAUSED:
            thisExp.status = PAUSED
            pauseExperiment(
                thisExp=thisExp, 
                win=win, 
                timers=[globalClock], 
            )
            # once done pausing, restore running status
            example.status = STARTED
        thisExp.nextEntry()
        
    # completed 1.0 repeats of 'example'
    example.status = FINISHED
    
    if thisSession is not None:
        # if running in a Session with a Liaison client, send data up to now
        thisSession.sendExperimentData()
    
    # --- Prepare to start Routine "Start_PAL" ---
    # create an object to store info about Routine Start_PAL
    Start_PAL = data.Routine(
        name='Start_PAL',
        components=[text_end_ex, text_start_PAL, key_start_PAL],
    )
    Start_PAL.status = NOT_STARTED
    continueRoutine = True
    # update component parameters for each repeat
    # create starting attributes for key_start_PAL
    key_start_PAL.keys = []
    key_start_PAL.rt = []
    _key_start_PAL_allKeys = []
    # store start times for Start_PAL
    Start_PAL.tStartRefresh = win.getFutureFlipTime(clock=globalClock)
    Start_PAL.tStart = globalClock.getTime(format='float')
    Start_PAL.status = STARTED
    thisExp.addData('Start_PAL.started', Start_PAL.tStart)
    Start_PAL.maxDuration = None
    # keep track of which components have finished
    Start_PALComponents = Start_PAL.components
    for thisComponent in Start_PAL.components:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    frameN = -1
    
    # --- Run Routine "Start_PAL" ---
    thisExp.currentRoutine = Start_PAL
    Start_PAL.forceEnded = routineForceEnded = not continueRoutine
    while continueRoutine:
        # get current time
        t = routineTimer.getTime()
        tThisFlip = win.getFutureFlipTime(clock=routineTimer)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *text_end_ex* updates
        
        # if text_end_ex is starting this frame...
        if text_end_ex.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            text_end_ex.frameNStart = frameN  # exact frame index
            text_end_ex.tStart = t  # local t and not account for scr refresh
            text_end_ex.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(text_end_ex, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'text_end_ex.started')
            # update status
            text_end_ex.status = STARTED
            text_end_ex.setAutoDraw(True)
        
        # if text_end_ex is active this frame...
        if text_end_ex.status == STARTED:
            # update params
            pass
        
        # if text_end_ex is stopping this frame...
        if text_end_ex.status == STARTED:
            # is it time to stop? (based on global clock, using actual start)
            if tThisFlipGlobal > text_end_ex.tStartRefresh + 1.5-frameTolerance:
                # keep track of stop time/frame for later
                text_end_ex.tStop = t  # not accounting for scr refresh
                text_end_ex.tStopRefresh = tThisFlipGlobal  # on global time
                text_end_ex.frameNStop = frameN  # exact frame index
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'text_end_ex.stopped')
                # update status
                text_end_ex.status = FINISHED
                text_end_ex.setAutoDraw(False)
        
        # *text_start_PAL* updates
        
        # if text_start_PAL is starting this frame...
        if text_start_PAL.status == NOT_STARTED and tThisFlip >= 1.5-frameTolerance:
            # keep track of start time/frame for later
            text_start_PAL.frameNStart = frameN  # exact frame index
            text_start_PAL.tStart = t  # local t and not account for scr refresh
            text_start_PAL.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(text_start_PAL, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'text_start_PAL.started')
            # update status
            text_start_PAL.status = STARTED
            text_start_PAL.setAutoDraw(True)
        
        # if text_start_PAL is active this frame...
        if text_start_PAL.status == STARTED:
            # update params
            pass
        
        # *key_start_PAL* updates
        waitOnFlip = False
        
        # if key_start_PAL is starting this frame...
        if key_start_PAL.status == NOT_STARTED and tThisFlip >= 1.5-frameTolerance:
            # keep track of start time/frame for later
            key_start_PAL.frameNStart = frameN  # exact frame index
            key_start_PAL.tStart = t  # local t and not account for scr refresh
            key_start_PAL.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(key_start_PAL, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'key_start_PAL.started')
            # update status
            key_start_PAL.status = STARTED
            # keyboard checking is just starting
            waitOnFlip = True
            win.callOnFlip(key_start_PAL.clock.reset)  # t=0 on next screen flip
            win.callOnFlip(key_start_PAL.clearEvents, eventType='keyboard')  # clear events on next screen flip
        if key_start_PAL.status == STARTED and not waitOnFlip:
            theseKeys = key_start_PAL.getKeys(keyList=['y','n','left','right','space'], ignoreKeys=["escape"], waitRelease=False)
            _key_start_PAL_allKeys.extend(theseKeys)
            if len(_key_start_PAL_allKeys):
                key_start_PAL.keys = _key_start_PAL_allKeys[-1].name  # just the last key pressed
                key_start_PAL.rt = _key_start_PAL_allKeys[-1].rt
                key_start_PAL.duration = _key_start_PAL_allKeys[-1].duration
                # a response ends the routine
                continueRoutine = False
        
        # check for quit (typically the Esc key)
        if defaultKeyboard.getKeys(keyList=["escape"]):
            thisExp.status = FINISHED
        if thisExp.status == FINISHED or endExpNow:
            endExperiment(thisExp, win=win)
            return
        # pause experiment here if requested
        if thisExp.status == PAUSED:
            pauseExperiment(
                thisExp=thisExp, 
                win=win, 
                timers=[routineTimer, globalClock], 
                currentRoutine=Start_PAL,
            )
            # skip the frame we paused on
            continue
        
        # has a Component requested the Routine to end?
        if not continueRoutine:
            Start_PAL.forceEnded = routineForceEnded = True
        # has the Routine been forcibly ended?
        if Start_PAL.forceEnded or routineForceEnded:
            break
        # has every Component finished?
        continueRoutine = False
        for thisComponent in Start_PAL.components:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # --- Ending Routine "Start_PAL" ---
    for thisComponent in Start_PAL.components:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    # store stop times for Start_PAL
    Start_PAL.tStop = globalClock.getTime(format='float')
    Start_PAL.tStopRefresh = tThisFlipGlobal
    thisExp.addData('Start_PAL.stopped', Start_PAL.tStop)
    # check responses
    if key_start_PAL.keys in ['', [], None]:  # No response was made
        key_start_PAL.keys = None
    thisExp.addData('key_start_PAL.keys',key_start_PAL.keys)
    if key_start_PAL.keys != None:  # we had a response
        thisExp.addData('key_start_PAL.rt', key_start_PAL.rt)
        thisExp.addData('key_start_PAL.duration', key_start_PAL.duration)
    thisExp.nextEntry()
    # the Routine "Start_PAL" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # set up handler to look after randomisation of conditions etc
    trial_encode = data.TrialHandler2(
        name='trial_encode',
        nReps=1.0, 
        method='random', 
        extraInfo=expInfo, 
        originPath=-1, 
        trialList=data.importConditions('encode_pairs.xlsx'), 
        seed=None, 
        isTrials=True, 
    )
    thisExp.addLoop(trial_encode)  # add the loop to the experiment
    thisTrial_encode = trial_encode.trialList[0]  # so we can initialise stimuli with some values
    # abbreviate parameter names if possible (e.g. rgb = thisTrial_encode.rgb)
    if thisTrial_encode != None:
        for paramName in thisTrial_encode:
            globals()[paramName] = thisTrial_encode[paramName]
    if thisSession is not None:
        # if running in a Session with a Liaison client, send data up to now
        thisSession.sendExperimentData()
    
    for thisTrial_encode in trial_encode:
        trial_encode.status = STARTED
        if hasattr(thisTrial_encode, 'status'):
            thisTrial_encode.status = STARTED
        currentLoop = trial_encode
        thisExp.timestampOnFlip(win, 'thisRow.t', format=globalClock.format)
        if thisSession is not None:
            # if running in a Session with a Liaison client, send data up to now
            thisSession.sendExperimentData()
        # abbreviate parameter names if possible (e.g. rgb = thisTrial_encode.rgb)
        if thisTrial_encode != None:
            for paramName in thisTrial_encode:
                globals()[paramName] = thisTrial_encode[paramName]
        
        # --- Prepare to start Routine "Encode" ---
        # create an object to store info about Routine Encode
        Encode = data.Routine(
            name='Encode',
            components=[image_scene_encode, image_object_encode, text_rating, slider_cong],
        )
        Encode.status = NOT_STARTED
        continueRoutine = True
        # update component parameters for each repeat
        image_scene_encode.setSize(scene_size)
        image_scene_encode.setImage(scene_encode)
        image_object_encode.setSize(object_size)
        image_object_encode.setImage(object_encode)
        # Run 'Begin Routine' code from code_debugPAL
        print(f"trial {trial_encode.thisN}, image = {scene_encode}")
        print(f"trial {trial_encode.thisN}, image = {object_encode}")
        
        slider_cong.reset()
        # store start times for Encode
        Encode.tStartRefresh = win.getFutureFlipTime(clock=globalClock)
        Encode.tStart = globalClock.getTime(format='float')
        Encode.status = STARTED
        thisExp.addData('Encode.started', Encode.tStart)
        Encode.maxDuration = None
        # keep track of which components have finished
        EncodeComponents = Encode.components
        for thisComponent in Encode.components:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        frameN = -1
        
        # --- Run Routine "Encode" ---
        thisExp.currentRoutine = Encode
        Encode.forceEnded = routineForceEnded = not continueRoutine
        while continueRoutine:
            # if trial has changed, end Routine now
            if hasattr(thisTrial_encode, 'status') and thisTrial_encode.status == STOPPING:
                continueRoutine = False
            # get current time
            t = routineTimer.getTime()
            tThisFlip = win.getFutureFlipTime(clock=routineTimer)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *image_scene_encode* updates
            
            # if image_scene_encode is starting this frame...
            if image_scene_encode.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                image_scene_encode.frameNStart = frameN  # exact frame index
                image_scene_encode.tStart = t  # local t and not account for scr refresh
                image_scene_encode.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(image_scene_encode, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'image_scene_encode.started')
                # update status
                image_scene_encode.status = STARTED
                image_scene_encode.setAutoDraw(True)
            
            # if image_scene_encode is active this frame...
            if image_scene_encode.status == STARTED:
                # update params
                pass
            
            # *image_object_encode* updates
            
            # if image_object_encode is starting this frame...
            if image_object_encode.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                image_object_encode.frameNStart = frameN  # exact frame index
                image_object_encode.tStart = t  # local t and not account for scr refresh
                image_object_encode.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(image_object_encode, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'image_object_encode.started')
                # update status
                image_object_encode.status = STARTED
                image_object_encode.setAutoDraw(True)
            
            # if image_object_encode is active this frame...
            if image_object_encode.status == STARTED:
                # update params
                pass
            
            # *text_rating* updates
            
            # if text_rating is starting this frame...
            if text_rating.status == NOT_STARTED and tThisFlip >= 2.5-frameTolerance:
                # keep track of start time/frame for later
                text_rating.frameNStart = frameN  # exact frame index
                text_rating.tStart = t  # local t and not account for scr refresh
                text_rating.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(text_rating, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'text_rating.started')
                # update status
                text_rating.status = STARTED
                text_rating.setAutoDraw(True)
            
            # if text_rating is active this frame...
            if text_rating.status == STARTED:
                # update params
                pass
            
            # *slider_cong* updates
            
            # if slider_cong is starting this frame...
            if slider_cong.status == NOT_STARTED and tThisFlip >= 2.5-frameTolerance:
                # keep track of start time/frame for later
                slider_cong.frameNStart = frameN  # exact frame index
                slider_cong.tStart = t  # local t and not account for scr refresh
                slider_cong.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(slider_cong, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'slider_cong.started')
                # update status
                slider_cong.status = STARTED
                slider_cong.setAutoDraw(True)
            
            # if slider_cong is active this frame...
            if slider_cong.status == STARTED:
                # update params
                pass
            
            # Check slider_cong for response to end Routine
            if slider_cong.getRating() is not None and slider_cong.status == STARTED:
                continueRoutine = False
            
            # check for quit (typically the Esc key)
            if defaultKeyboard.getKeys(keyList=["escape"]):
                thisExp.status = FINISHED
            if thisExp.status == FINISHED or endExpNow:
                endExperiment(thisExp, win=win)
                return
            # pause experiment here if requested
            if thisExp.status == PAUSED:
                pauseExperiment(
                    thisExp=thisExp, 
                    win=win, 
                    timers=[routineTimer, globalClock], 
                    currentRoutine=Encode,
                )
                # skip the frame we paused on
                continue
            
            # has a Component requested the Routine to end?
            if not continueRoutine:
                Encode.forceEnded = routineForceEnded = True
            # has the Routine been forcibly ended?
            if Encode.forceEnded or routineForceEnded:
                break
            # has every Component finished?
            continueRoutine = False
            for thisComponent in Encode.components:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # --- Ending Routine "Encode" ---
        for thisComponent in Encode.components:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        # store stop times for Encode
        Encode.tStop = globalClock.getTime(format='float')
        Encode.tStopRefresh = tThisFlipGlobal
        thisExp.addData('Encode.stopped', Encode.tStop)
        trial_encode.addData('slider_cong.response', slider_cong.getRating())
        trial_encode.addData('slider_cong.rt', slider_cong.getRT())
        # the Routine "Encode" was not non-slip safe, so reset the non-slip timer
        routineTimer.reset()
        
        # --- Prepare to start Routine "blank" ---
        # create an object to store info about Routine blank
        blank = data.Routine(
            name='blank',
            components=[cross_25, image_blank],
        )
        blank.status = NOT_STARTED
        continueRoutine = True
        # update component parameters for each repeat
        # store start times for blank
        blank.tStartRefresh = win.getFutureFlipTime(clock=globalClock)
        blank.tStart = globalClock.getTime(format='float')
        blank.status = STARTED
        thisExp.addData('blank.started', blank.tStart)
        blank.maxDuration = None
        # keep track of which components have finished
        blankComponents = blank.components
        for thisComponent in blank.components:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        frameN = -1
        
        # --- Run Routine "blank" ---
        thisExp.currentRoutine = blank
        blank.forceEnded = routineForceEnded = not continueRoutine
        while continueRoutine and routineTimer.getTime() < 2.5:
            # if trial has changed, end Routine now
            if hasattr(thisTrial_encode, 'status') and thisTrial_encode.status == STOPPING:
                continueRoutine = False
            # get current time
            t = routineTimer.getTime()
            tThisFlip = win.getFutureFlipTime(clock=routineTimer)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *cross_25* updates
            
            # if cross_25 is starting this frame...
            if cross_25.status == NOT_STARTED and tThisFlip >= 2.25-frameTolerance:
                # keep track of start time/frame for later
                cross_25.frameNStart = frameN  # exact frame index
                cross_25.tStart = t  # local t and not account for scr refresh
                cross_25.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(cross_25, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'cross_25.started')
                # update status
                cross_25.status = STARTED
                cross_25.setAutoDraw(True)
            
            # if cross_25 is active this frame...
            if cross_25.status == STARTED:
                # update params
                pass
            
            # if cross_25 is stopping this frame...
            if cross_25.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > cross_25.tStartRefresh + 0.25-frameTolerance:
                    # keep track of stop time/frame for later
                    cross_25.tStop = t  # not accounting for scr refresh
                    cross_25.tStopRefresh = tThisFlipGlobal  # on global time
                    cross_25.frameNStop = frameN  # exact frame index
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'cross_25.stopped')
                    # update status
                    cross_25.status = FINISHED
                    cross_25.setAutoDraw(False)
            
            # *image_blank* updates
            
            # if image_blank is starting this frame...
            if image_blank.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                image_blank.frameNStart = frameN  # exact frame index
                image_blank.tStart = t  # local t and not account for scr refresh
                image_blank.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(image_blank, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'image_blank.started')
                # update status
                image_blank.status = STARTED
                image_blank.setAutoDraw(True)
            
            # if image_blank is active this frame...
            if image_blank.status == STARTED:
                # update params
                pass
            
            # if image_blank is stopping this frame...
            if image_blank.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > image_blank.tStartRefresh + 2.25-frameTolerance:
                    # keep track of stop time/frame for later
                    image_blank.tStop = t  # not accounting for scr refresh
                    image_blank.tStopRefresh = tThisFlipGlobal  # on global time
                    image_blank.frameNStop = frameN  # exact frame index
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'image_blank.stopped')
                    # update status
                    image_blank.status = FINISHED
                    image_blank.setAutoDraw(False)
            
            # check for quit (typically the Esc key)
            if defaultKeyboard.getKeys(keyList=["escape"]):
                thisExp.status = FINISHED
            if thisExp.status == FINISHED or endExpNow:
                endExperiment(thisExp, win=win)
                return
            # pause experiment here if requested
            if thisExp.status == PAUSED:
                pauseExperiment(
                    thisExp=thisExp, 
                    win=win, 
                    timers=[routineTimer, globalClock], 
                    currentRoutine=blank,
                )
                # skip the frame we paused on
                continue
            
            # has a Component requested the Routine to end?
            if not continueRoutine:
                blank.forceEnded = routineForceEnded = True
            # has the Routine been forcibly ended?
            if blank.forceEnded or routineForceEnded:
                break
            # has every Component finished?
            continueRoutine = False
            for thisComponent in blank.components:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # --- Ending Routine "blank" ---
        for thisComponent in blank.components:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        # store stop times for blank
        blank.tStop = globalClock.getTime(format='float')
        blank.tStopRefresh = tThisFlipGlobal
        thisExp.addData('blank.stopped', blank.tStop)
        # using non-slip timing so subtract the expected duration of this Routine (unless ended on request)
        if blank.maxDurationReached:
            routineTimer.addTime(-blank.maxDuration)
        elif blank.forceEnded:
            routineTimer.reset()
        else:
            routineTimer.addTime(-2.500000)
        # mark thisTrial_encode as finished
        if hasattr(thisTrial_encode, 'status'):
            thisTrial_encode.status = FINISHED
        # if awaiting a pause, pause now
        if trial_encode.status == PAUSED:
            thisExp.status = PAUSED
            pauseExperiment(
                thisExp=thisExp, 
                win=win, 
                timers=[globalClock], 
            )
            # once done pausing, restore running status
            trial_encode.status = STARTED
        thisExp.nextEntry()
        
    # completed 1.0 repeats of 'trial_encode'
    trial_encode.status = FINISHED
    
    if thisSession is not None:
        # if running in a Session with a Liaison client, send data up to now
        thisSession.sendExperimentData()
    
    # --- Prepare to start Routine "Pause_1" ---
    # create an object to store info about Routine Pause_1
    Pause_1 = data.Routine(
        name='Pause_1',
        components=[text_pausa1, key_Start_Cog],
    )
    Pause_1.status = NOT_STARTED
    continueRoutine = True
    # update component parameters for each repeat
    # create starting attributes for key_Start_Cog
    key_Start_Cog.keys = []
    key_Start_Cog.rt = []
    _key_Start_Cog_allKeys = []
    # store start times for Pause_1
    Pause_1.tStartRefresh = win.getFutureFlipTime(clock=globalClock)
    Pause_1.tStart = globalClock.getTime(format='float')
    Pause_1.status = STARTED
    thisExp.addData('Pause_1.started', Pause_1.tStart)
    Pause_1.maxDuration = None
    # keep track of which components have finished
    Pause_1Components = Pause_1.components
    for thisComponent in Pause_1.components:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    frameN = -1
    
    # --- Run Routine "Pause_1" ---
    thisExp.currentRoutine = Pause_1
    Pause_1.forceEnded = routineForceEnded = not continueRoutine
    while continueRoutine:
        # get current time
        t = routineTimer.getTime()
        tThisFlip = win.getFutureFlipTime(clock=routineTimer)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *text_pausa1* updates
        
        # if text_pausa1 is starting this frame...
        if text_pausa1.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            text_pausa1.frameNStart = frameN  # exact frame index
            text_pausa1.tStart = t  # local t and not account for scr refresh
            text_pausa1.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(text_pausa1, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'text_pausa1.started')
            # update status
            text_pausa1.status = STARTED
            text_pausa1.setAutoDraw(True)
        
        # if text_pausa1 is active this frame...
        if text_pausa1.status == STARTED:
            # update params
            pass
        
        # *key_Start_Cog* updates
        waitOnFlip = False
        
        # if key_Start_Cog is starting this frame...
        if key_Start_Cog.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            key_Start_Cog.frameNStart = frameN  # exact frame index
            key_Start_Cog.tStart = t  # local t and not account for scr refresh
            key_Start_Cog.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(key_Start_Cog, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'key_Start_Cog.started')
            # update status
            key_Start_Cog.status = STARTED
            # keyboard checking is just starting
            waitOnFlip = True
            win.callOnFlip(key_Start_Cog.clock.reset)  # t=0 on next screen flip
            win.callOnFlip(key_Start_Cog.clearEvents, eventType='keyboard')  # clear events on next screen flip
        if key_Start_Cog.status == STARTED and not waitOnFlip:
            theseKeys = key_Start_Cog.getKeys(keyList=['space'], ignoreKeys=["escape"], waitRelease=False)
            _key_Start_Cog_allKeys.extend(theseKeys)
            if len(_key_Start_Cog_allKeys):
                key_Start_Cog.keys = _key_Start_Cog_allKeys[-1].name  # just the last key pressed
                key_Start_Cog.rt = _key_Start_Cog_allKeys[-1].rt
                key_Start_Cog.duration = _key_Start_Cog_allKeys[-1].duration
                # a response ends the routine
                continueRoutine = False
        
        # check for quit (typically the Esc key)
        if defaultKeyboard.getKeys(keyList=["escape"]):
            thisExp.status = FINISHED
        if thisExp.status == FINISHED or endExpNow:
            endExperiment(thisExp, win=win)
            return
        # pause experiment here if requested
        if thisExp.status == PAUSED:
            pauseExperiment(
                thisExp=thisExp, 
                win=win, 
                timers=[routineTimer, globalClock], 
                currentRoutine=Pause_1,
            )
            # skip the frame we paused on
            continue
        
        # has a Component requested the Routine to end?
        if not continueRoutine:
            Pause_1.forceEnded = routineForceEnded = True
        # has the Routine been forcibly ended?
        if Pause_1.forceEnded or routineForceEnded:
            break
        # has every Component finished?
        continueRoutine = False
        for thisComponent in Pause_1.components:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # --- Ending Routine "Pause_1" ---
    for thisComponent in Pause_1.components:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    # store stop times for Pause_1
    Pause_1.tStop = globalClock.getTime(format='float')
    Pause_1.tStopRefresh = tThisFlipGlobal
    thisExp.addData('Pause_1.stopped', Pause_1.tStop)
    # check responses
    if key_Start_Cog.keys in ['', [], None]:  # No response was made
        key_Start_Cog.keys = None
    thisExp.addData('key_Start_Cog.keys',key_Start_Cog.keys)
    if key_Start_Cog.keys != None:  # we had a response
        thisExp.addData('key_Start_Cog.rt', key_Start_Cog.rt)
        thisExp.addData('key_Start_Cog.duration', key_Start_Cog.duration)
    thisExp.nextEntry()
    # the Routine "Pause_1" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # --- Prepare to start Routine "Explanation_GoNo" ---
    # create an object to store info about Routine Explanation_GoNo
    Explanation_GoNo = data.Routine(
        name='Explanation_GoNo',
        components=[text_explanation_GoNo],
    )
    Explanation_GoNo.status = NOT_STARTED
    continueRoutine = True
    # update component parameters for each repeat
    # store start times for Explanation_GoNo
    Explanation_GoNo.tStartRefresh = win.getFutureFlipTime(clock=globalClock)
    Explanation_GoNo.tStart = globalClock.getTime(format='float')
    Explanation_GoNo.status = STARTED
    thisExp.addData('Explanation_GoNo.started', Explanation_GoNo.tStart)
    Explanation_GoNo.maxDuration = None
    # keep track of which components have finished
    Explanation_GoNoComponents = Explanation_GoNo.components
    for thisComponent in Explanation_GoNo.components:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    frameN = -1
    
    # --- Run Routine "Explanation_GoNo" ---
    thisExp.currentRoutine = Explanation_GoNo
    Explanation_GoNo.forceEnded = routineForceEnded = not continueRoutine
    while continueRoutine and routineTimer.getTime() < 1.0:
        # get current time
        t = routineTimer.getTime()
        tThisFlip = win.getFutureFlipTime(clock=routineTimer)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *text_explanation_GoNo* updates
        
        # if text_explanation_GoNo is starting this frame...
        if text_explanation_GoNo.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            text_explanation_GoNo.frameNStart = frameN  # exact frame index
            text_explanation_GoNo.tStart = t  # local t and not account for scr refresh
            text_explanation_GoNo.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(text_explanation_GoNo, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'text_explanation_GoNo.started')
            # update status
            text_explanation_GoNo.status = STARTED
            text_explanation_GoNo.setAutoDraw(True)
        
        # if text_explanation_GoNo is active this frame...
        if text_explanation_GoNo.status == STARTED:
            # update params
            pass
        
        # if text_explanation_GoNo is stopping this frame...
        if text_explanation_GoNo.status == STARTED:
            # is it time to stop? (based on global clock, using actual start)
            if tThisFlipGlobal > text_explanation_GoNo.tStartRefresh + 1.0-frameTolerance:
                # keep track of stop time/frame for later
                text_explanation_GoNo.tStop = t  # not accounting for scr refresh
                text_explanation_GoNo.tStopRefresh = tThisFlipGlobal  # on global time
                text_explanation_GoNo.frameNStop = frameN  # exact frame index
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'text_explanation_GoNo.stopped')
                # update status
                text_explanation_GoNo.status = FINISHED
                text_explanation_GoNo.setAutoDraw(False)
        
        # check for quit (typically the Esc key)
        if defaultKeyboard.getKeys(keyList=["escape"]):
            thisExp.status = FINISHED
        if thisExp.status == FINISHED or endExpNow:
            endExperiment(thisExp, win=win)
            return
        # pause experiment here if requested
        if thisExp.status == PAUSED:
            pauseExperiment(
                thisExp=thisExp, 
                win=win, 
                timers=[routineTimer, globalClock], 
                currentRoutine=Explanation_GoNo,
            )
            # skip the frame we paused on
            continue
        
        # has a Component requested the Routine to end?
        if not continueRoutine:
            Explanation_GoNo.forceEnded = routineForceEnded = True
        # has the Routine been forcibly ended?
        if Explanation_GoNo.forceEnded or routineForceEnded:
            break
        # has every Component finished?
        continueRoutine = False
        for thisComponent in Explanation_GoNo.components:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # --- Ending Routine "Explanation_GoNo" ---
    for thisComponent in Explanation_GoNo.components:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    # store stop times for Explanation_GoNo
    Explanation_GoNo.tStop = globalClock.getTime(format='float')
    Explanation_GoNo.tStopRefresh = tThisFlipGlobal
    thisExp.addData('Explanation_GoNo.stopped', Explanation_GoNo.tStop)
    # using non-slip timing so subtract the expected duration of this Routine (unless ended on request)
    if Explanation_GoNo.maxDurationReached:
        routineTimer.addTime(-Explanation_GoNo.maxDuration)
    elif Explanation_GoNo.forceEnded:
        routineTimer.reset()
    else:
        routineTimer.addTime(-1.000000)
    thisExp.nextEntry()
    
    # --- Prepare to start Routine "Cog_Oral" ---
    # create an object to store info about Routine Cog_Oral
    Cog_Oral = data.Routine(
        name='Cog_Oral',
        components=[text_endGo, text_call, key_end_cog],
    )
    Cog_Oral.status = NOT_STARTED
    continueRoutine = True
    # update component parameters for each repeat
    # create starting attributes for key_end_cog
    key_end_cog.keys = []
    key_end_cog.rt = []
    _key_end_cog_allKeys = []
    # store start times for Cog_Oral
    Cog_Oral.tStartRefresh = win.getFutureFlipTime(clock=globalClock)
    Cog_Oral.tStart = globalClock.getTime(format='float')
    Cog_Oral.status = STARTED
    thisExp.addData('Cog_Oral.started', Cog_Oral.tStart)
    Cog_Oral.maxDuration = None
    # keep track of which components have finished
    Cog_OralComponents = Cog_Oral.components
    for thisComponent in Cog_Oral.components:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    frameN = -1
    
    # --- Run Routine "Cog_Oral" ---
    thisExp.currentRoutine = Cog_Oral
    Cog_Oral.forceEnded = routineForceEnded = not continueRoutine
    while continueRoutine:
        # get current time
        t = routineTimer.getTime()
        tThisFlip = win.getFutureFlipTime(clock=routineTimer)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *text_endGo* updates
        
        # if text_endGo is starting this frame...
        if text_endGo.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            text_endGo.frameNStart = frameN  # exact frame index
            text_endGo.tStart = t  # local t and not account for scr refresh
            text_endGo.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(text_endGo, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'text_endGo.started')
            # update status
            text_endGo.status = STARTED
            text_endGo.setAutoDraw(True)
        
        # if text_endGo is active this frame...
        if text_endGo.status == STARTED:
            # update params
            pass
        
        # if text_endGo is stopping this frame...
        if text_endGo.status == STARTED:
            # is it time to stop? (based on global clock, using actual start)
            if tThisFlipGlobal > text_endGo.tStartRefresh + 2-frameTolerance:
                # keep track of stop time/frame for later
                text_endGo.tStop = t  # not accounting for scr refresh
                text_endGo.tStopRefresh = tThisFlipGlobal  # on global time
                text_endGo.frameNStop = frameN  # exact frame index
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'text_endGo.stopped')
                # update status
                text_endGo.status = FINISHED
                text_endGo.setAutoDraw(False)
        
        # *text_call* updates
        
        # if text_call is starting this frame...
        if text_call.status == NOT_STARTED and tThisFlip >= 2-frameTolerance:
            # keep track of start time/frame for later
            text_call.frameNStart = frameN  # exact frame index
            text_call.tStart = t  # local t and not account for scr refresh
            text_call.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(text_call, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'text_call.started')
            # update status
            text_call.status = STARTED
            text_call.setAutoDraw(True)
        
        # if text_call is active this frame...
        if text_call.status == STARTED:
            # update params
            pass
        
        # if text_call is stopping this frame...
        if text_call.status == STARTED:
            # is it time to stop? (based on global clock, using actual start)
            if tThisFlipGlobal > text_call.tStartRefresh + 10-frameTolerance:
                # keep track of stop time/frame for later
                text_call.tStop = t  # not accounting for scr refresh
                text_call.tStopRefresh = tThisFlipGlobal  # on global time
                text_call.frameNStop = frameN  # exact frame index
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'text_call.stopped')
                # update status
                text_call.status = FINISHED
                text_call.setAutoDraw(False)
        
        # *key_end_cog* updates
        waitOnFlip = False
        
        # if key_end_cog is starting this frame...
        if key_end_cog.status == NOT_STARTED and tThisFlip >= 0-frameTolerance:
            # keep track of start time/frame for later
            key_end_cog.frameNStart = frameN  # exact frame index
            key_end_cog.tStart = t  # local t and not account for scr refresh
            key_end_cog.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(key_end_cog, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'key_end_cog.started')
            # update status
            key_end_cog.status = STARTED
            # keyboard checking is just starting
            waitOnFlip = True
            win.callOnFlip(key_end_cog.clock.reset)  # t=0 on next screen flip
            win.callOnFlip(key_end_cog.clearEvents, eventType='keyboard')  # clear events on next screen flip
        if key_end_cog.status == STARTED and not waitOnFlip:
            theseKeys = key_end_cog.getKeys(keyList=['y','n','left','right','space'], ignoreKeys=["escape"], waitRelease=False)
            _key_end_cog_allKeys.extend(theseKeys)
            if len(_key_end_cog_allKeys):
                key_end_cog.keys = _key_end_cog_allKeys[-1].name  # just the last key pressed
                key_end_cog.rt = _key_end_cog_allKeys[-1].rt
                key_end_cog.duration = _key_end_cog_allKeys[-1].duration
                # a response ends the routine
                continueRoutine = False
        
        # check for quit (typically the Esc key)
        if defaultKeyboard.getKeys(keyList=["escape"]):
            thisExp.status = FINISHED
        if thisExp.status == FINISHED or endExpNow:
            endExperiment(thisExp, win=win)
            return
        # pause experiment here if requested
        if thisExp.status == PAUSED:
            pauseExperiment(
                thisExp=thisExp, 
                win=win, 
                timers=[routineTimer, globalClock], 
                currentRoutine=Cog_Oral,
            )
            # skip the frame we paused on
            continue
        
        # has a Component requested the Routine to end?
        if not continueRoutine:
            Cog_Oral.forceEnded = routineForceEnded = True
        # has the Routine been forcibly ended?
        if Cog_Oral.forceEnded or routineForceEnded:
            break
        # has every Component finished?
        continueRoutine = False
        for thisComponent in Cog_Oral.components:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # --- Ending Routine "Cog_Oral" ---
    for thisComponent in Cog_Oral.components:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    # store stop times for Cog_Oral
    Cog_Oral.tStop = globalClock.getTime(format='float')
    Cog_Oral.tStopRefresh = tThisFlipGlobal
    thisExp.addData('Cog_Oral.stopped', Cog_Oral.tStop)
    # check responses
    if key_end_cog.keys in ['', [], None]:  # No response was made
        key_end_cog.keys = None
    thisExp.addData('key_end_cog.keys',key_end_cog.keys)
    if key_end_cog.keys != None:  # we had a response
        thisExp.addData('key_end_cog.rt', key_end_cog.rt)
        thisExp.addData('key_end_cog.duration', key_end_cog.duration)
    thisExp.nextEntry()
    # the Routine "Cog_Oral" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # --- Prepare to start Routine "Retomar" ---
    # create an object to store info about Routine Retomar
    Retomar = data.Routine(
        name='Retomar',
        components=[text_retomar, key_resp],
    )
    Retomar.status = NOT_STARTED
    continueRoutine = True
    # update component parameters for each repeat
    # create starting attributes for key_resp
    key_resp.keys = []
    key_resp.rt = []
    _key_resp_allKeys = []
    # store start times for Retomar
    Retomar.tStartRefresh = win.getFutureFlipTime(clock=globalClock)
    Retomar.tStart = globalClock.getTime(format='float')
    Retomar.status = STARTED
    thisExp.addData('Retomar.started', Retomar.tStart)
    Retomar.maxDuration = None
    # keep track of which components have finished
    RetomarComponents = Retomar.components
    for thisComponent in Retomar.components:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    frameN = -1
    
    # --- Run Routine "Retomar" ---
    thisExp.currentRoutine = Retomar
    Retomar.forceEnded = routineForceEnded = not continueRoutine
    while continueRoutine:
        # get current time
        t = routineTimer.getTime()
        tThisFlip = win.getFutureFlipTime(clock=routineTimer)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *text_retomar* updates
        
        # if text_retomar is starting this frame...
        if text_retomar.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            text_retomar.frameNStart = frameN  # exact frame index
            text_retomar.tStart = t  # local t and not account for scr refresh
            text_retomar.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(text_retomar, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'text_retomar.started')
            # update status
            text_retomar.status = STARTED
            text_retomar.setAutoDraw(True)
        
        # if text_retomar is active this frame...
        if text_retomar.status == STARTED:
            # update params
            pass
        
        # *key_resp* updates
        waitOnFlip = False
        
        # if key_resp is starting this frame...
        if key_resp.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            key_resp.frameNStart = frameN  # exact frame index
            key_resp.tStart = t  # local t and not account for scr refresh
            key_resp.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(key_resp, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'key_resp.started')
            # update status
            key_resp.status = STARTED
            # keyboard checking is just starting
            waitOnFlip = True
            win.callOnFlip(key_resp.clock.reset)  # t=0 on next screen flip
            win.callOnFlip(key_resp.clearEvents, eventType='keyboard')  # clear events on next screen flip
        if key_resp.status == STARTED and not waitOnFlip:
            theseKeys = key_resp.getKeys(keyList=['y','n','left','right','space'], ignoreKeys=["escape"], waitRelease=False)
            _key_resp_allKeys.extend(theseKeys)
            if len(_key_resp_allKeys):
                key_resp.keys = _key_resp_allKeys[-1].name  # just the last key pressed
                key_resp.rt = _key_resp_allKeys[-1].rt
                key_resp.duration = _key_resp_allKeys[-1].duration
                # a response ends the routine
                continueRoutine = False
        
        # check for quit (typically the Esc key)
        if defaultKeyboard.getKeys(keyList=["escape"]):
            thisExp.status = FINISHED
        if thisExp.status == FINISHED or endExpNow:
            endExperiment(thisExp, win=win)
            return
        # pause experiment here if requested
        if thisExp.status == PAUSED:
            pauseExperiment(
                thisExp=thisExp, 
                win=win, 
                timers=[routineTimer, globalClock], 
                currentRoutine=Retomar,
            )
            # skip the frame we paused on
            continue
        
        # has a Component requested the Routine to end?
        if not continueRoutine:
            Retomar.forceEnded = routineForceEnded = True
        # has the Routine been forcibly ended?
        if Retomar.forceEnded or routineForceEnded:
            break
        # has every Component finished?
        continueRoutine = False
        for thisComponent in Retomar.components:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # --- Ending Routine "Retomar" ---
    for thisComponent in Retomar.components:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    # store stop times for Retomar
    Retomar.tStop = globalClock.getTime(format='float')
    Retomar.tStopRefresh = tThisFlipGlobal
    thisExp.addData('Retomar.stopped', Retomar.tStop)
    # check responses
    if key_resp.keys in ['', [], None]:  # No response was made
        key_resp.keys = None
    thisExp.addData('key_resp.keys',key_resp.keys)
    if key_resp.keys != None:  # we had a response
        thisExp.addData('key_resp.rt', key_resp.rt)
        thisExp.addData('key_resp.duration', key_resp.duration)
    thisExp.nextEntry()
    # the Routine "Retomar" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # --- Prepare to start Routine "Explanation_Recall" ---
    # create an object to store info about Routine Explanation_Recall
    Explanation_Recall = data.Routine(
        name='Explanation_Recall',
        components=[text_explain_recall, key_continue],
    )
    Explanation_Recall.status = NOT_STARTED
    continueRoutine = True
    # update component parameters for each repeat
    # create starting attributes for key_continue
    key_continue.keys = []
    key_continue.rt = []
    _key_continue_allKeys = []
    # store start times for Explanation_Recall
    Explanation_Recall.tStartRefresh = win.getFutureFlipTime(clock=globalClock)
    Explanation_Recall.tStart = globalClock.getTime(format='float')
    Explanation_Recall.status = STARTED
    thisExp.addData('Explanation_Recall.started', Explanation_Recall.tStart)
    Explanation_Recall.maxDuration = None
    # keep track of which components have finished
    Explanation_RecallComponents = Explanation_Recall.components
    for thisComponent in Explanation_Recall.components:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    frameN = -1
    
    # --- Run Routine "Explanation_Recall" ---
    thisExp.currentRoutine = Explanation_Recall
    Explanation_Recall.forceEnded = routineForceEnded = not continueRoutine
    while continueRoutine:
        # get current time
        t = routineTimer.getTime()
        tThisFlip = win.getFutureFlipTime(clock=routineTimer)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *text_explain_recall* updates
        
        # if text_explain_recall is starting this frame...
        if text_explain_recall.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            text_explain_recall.frameNStart = frameN  # exact frame index
            text_explain_recall.tStart = t  # local t and not account for scr refresh
            text_explain_recall.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(text_explain_recall, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'text_explain_recall.started')
            # update status
            text_explain_recall.status = STARTED
            text_explain_recall.setAutoDraw(True)
        
        # if text_explain_recall is active this frame...
        if text_explain_recall.status == STARTED:
            # update params
            pass
        
        # *key_continue* updates
        waitOnFlip = False
        
        # if key_continue is starting this frame...
        if key_continue.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            key_continue.frameNStart = frameN  # exact frame index
            key_continue.tStart = t  # local t and not account for scr refresh
            key_continue.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(key_continue, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'key_continue.started')
            # update status
            key_continue.status = STARTED
            # keyboard checking is just starting
            waitOnFlip = True
            win.callOnFlip(key_continue.clock.reset)  # t=0 on next screen flip
            win.callOnFlip(key_continue.clearEvents, eventType='keyboard')  # clear events on next screen flip
        if key_continue.status == STARTED and not waitOnFlip:
            theseKeys = key_continue.getKeys(keyList=['y','n','left','right','space'], ignoreKeys=["escape"], waitRelease=False)
            _key_continue_allKeys.extend(theseKeys)
            if len(_key_continue_allKeys):
                key_continue.keys = _key_continue_allKeys[-1].name  # just the last key pressed
                key_continue.rt = _key_continue_allKeys[-1].rt
                key_continue.duration = _key_continue_allKeys[-1].duration
                # a response ends the routine
                continueRoutine = False
        
        # check for quit (typically the Esc key)
        if defaultKeyboard.getKeys(keyList=["escape"]):
            thisExp.status = FINISHED
        if thisExp.status == FINISHED or endExpNow:
            endExperiment(thisExp, win=win)
            return
        # pause experiment here if requested
        if thisExp.status == PAUSED:
            pauseExperiment(
                thisExp=thisExp, 
                win=win, 
                timers=[routineTimer, globalClock], 
                currentRoutine=Explanation_Recall,
            )
            # skip the frame we paused on
            continue
        
        # has a Component requested the Routine to end?
        if not continueRoutine:
            Explanation_Recall.forceEnded = routineForceEnded = True
        # has the Routine been forcibly ended?
        if Explanation_Recall.forceEnded or routineForceEnded:
            break
        # has every Component finished?
        continueRoutine = False
        for thisComponent in Explanation_Recall.components:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # --- Ending Routine "Explanation_Recall" ---
    for thisComponent in Explanation_Recall.components:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    # store stop times for Explanation_Recall
    Explanation_Recall.tStop = globalClock.getTime(format='float')
    Explanation_Recall.tStopRefresh = tThisFlipGlobal
    thisExp.addData('Explanation_Recall.stopped', Explanation_Recall.tStop)
    # check responses
    if key_continue.keys in ['', [], None]:  # No response was made
        key_continue.keys = None
    thisExp.addData('key_continue.keys',key_continue.keys)
    if key_continue.keys != None:  # we had a response
        thisExp.addData('key_continue.rt', key_continue.rt)
        thisExp.addData('key_continue.duration', key_continue.duration)
    thisExp.nextEntry()
    # the Routine "Explanation_Recall" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # --- Prepare to start Routine "Explain_Old_New" ---
    # create an object to store info about Routine Explain_Old_New
    Explain_Old_New = data.Routine(
        name='Explain_Old_New',
        components=[text_explain_old_new, key_explain_old],
    )
    Explain_Old_New.status = NOT_STARTED
    continueRoutine = True
    # update component parameters for each repeat
    # create starting attributes for key_explain_old
    key_explain_old.keys = []
    key_explain_old.rt = []
    _key_explain_old_allKeys = []
    # store start times for Explain_Old_New
    Explain_Old_New.tStartRefresh = win.getFutureFlipTime(clock=globalClock)
    Explain_Old_New.tStart = globalClock.getTime(format='float')
    Explain_Old_New.status = STARTED
    thisExp.addData('Explain_Old_New.started', Explain_Old_New.tStart)
    Explain_Old_New.maxDuration = None
    # keep track of which components have finished
    Explain_Old_NewComponents = Explain_Old_New.components
    for thisComponent in Explain_Old_New.components:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    frameN = -1
    
    # --- Run Routine "Explain_Old_New" ---
    thisExp.currentRoutine = Explain_Old_New
    Explain_Old_New.forceEnded = routineForceEnded = not continueRoutine
    while continueRoutine:
        # get current time
        t = routineTimer.getTime()
        tThisFlip = win.getFutureFlipTime(clock=routineTimer)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *text_explain_old_new* updates
        
        # if text_explain_old_new is starting this frame...
        if text_explain_old_new.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            text_explain_old_new.frameNStart = frameN  # exact frame index
            text_explain_old_new.tStart = t  # local t and not account for scr refresh
            text_explain_old_new.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(text_explain_old_new, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'text_explain_old_new.started')
            # update status
            text_explain_old_new.status = STARTED
            text_explain_old_new.setAutoDraw(True)
        
        # if text_explain_old_new is active this frame...
        if text_explain_old_new.status == STARTED:
            # update params
            pass
        
        # *key_explain_old* updates
        waitOnFlip = False
        
        # if key_explain_old is starting this frame...
        if key_explain_old.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            key_explain_old.frameNStart = frameN  # exact frame index
            key_explain_old.tStart = t  # local t and not account for scr refresh
            key_explain_old.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(key_explain_old, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'key_explain_old.started')
            # update status
            key_explain_old.status = STARTED
            # keyboard checking is just starting
            waitOnFlip = True
            win.callOnFlip(key_explain_old.clock.reset)  # t=0 on next screen flip
            win.callOnFlip(key_explain_old.clearEvents, eventType='keyboard')  # clear events on next screen flip
        if key_explain_old.status == STARTED and not waitOnFlip:
            theseKeys = key_explain_old.getKeys(keyList=['y','n','left','right','space'], ignoreKeys=["escape"], waitRelease=False)
            _key_explain_old_allKeys.extend(theseKeys)
            if len(_key_explain_old_allKeys):
                key_explain_old.keys = _key_explain_old_allKeys[-1].name  # just the last key pressed
                key_explain_old.rt = _key_explain_old_allKeys[-1].rt
                key_explain_old.duration = _key_explain_old_allKeys[-1].duration
                # a response ends the routine
                continueRoutine = False
        
        # check for quit (typically the Esc key)
        if defaultKeyboard.getKeys(keyList=["escape"]):
            thisExp.status = FINISHED
        if thisExp.status == FINISHED or endExpNow:
            endExperiment(thisExp, win=win)
            return
        # pause experiment here if requested
        if thisExp.status == PAUSED:
            pauseExperiment(
                thisExp=thisExp, 
                win=win, 
                timers=[routineTimer, globalClock], 
                currentRoutine=Explain_Old_New,
            )
            # skip the frame we paused on
            continue
        
        # has a Component requested the Routine to end?
        if not continueRoutine:
            Explain_Old_New.forceEnded = routineForceEnded = True
        # has the Routine been forcibly ended?
        if Explain_Old_New.forceEnded or routineForceEnded:
            break
        # has every Component finished?
        continueRoutine = False
        for thisComponent in Explain_Old_New.components:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # --- Ending Routine "Explain_Old_New" ---
    for thisComponent in Explain_Old_New.components:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    # store stop times for Explain_Old_New
    Explain_Old_New.tStop = globalClock.getTime(format='float')
    Explain_Old_New.tStopRefresh = tThisFlipGlobal
    thisExp.addData('Explain_Old_New.stopped', Explain_Old_New.tStop)
    # check responses
    if key_explain_old.keys in ['', [], None]:  # No response was made
        key_explain_old.keys = None
    thisExp.addData('key_explain_old.keys',key_explain_old.keys)
    if key_explain_old.keys != None:  # we had a response
        thisExp.addData('key_explain_old.rt', key_explain_old.rt)
        thisExp.addData('key_explain_old.duration', key_explain_old.duration)
    thisExp.nextEntry()
    # the Routine "Explain_Old_New" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # set up handler to look after randomisation of conditions etc
    trial_ex_old = data.TrialHandler2(
        name='trial_ex_old',
        nReps=1.0, 
        method='random', 
        extraInfo=expInfo, 
        originPath=-1, 
        trialList=data.importConditions('Exemplo_old.xlsx'), 
        seed=None, 
        isTrials=True, 
    )
    thisExp.addLoop(trial_ex_old)  # add the loop to the experiment
    thisTrial_ex_old = trial_ex_old.trialList[0]  # so we can initialise stimuli with some values
    # abbreviate parameter names if possible (e.g. rgb = thisTrial_ex_old.rgb)
    if thisTrial_ex_old != None:
        for paramName in thisTrial_ex_old:
            globals()[paramName] = thisTrial_ex_old[paramName]
    if thisSession is not None:
        # if running in a Session with a Liaison client, send data up to now
        thisSession.sendExperimentData()
    
    for thisTrial_ex_old in trial_ex_old:
        trial_ex_old.status = STARTED
        if hasattr(thisTrial_ex_old, 'status'):
            thisTrial_ex_old.status = STARTED
        currentLoop = trial_ex_old
        thisExp.timestampOnFlip(win, 'thisRow.t', format=globalClock.format)
        if thisSession is not None:
            # if running in a Session with a Liaison client, send data up to now
            thisSession.sendExperimentData()
        # abbreviate parameter names if possible (e.g. rgb = thisTrial_ex_old.rgb)
        if thisTrial_ex_old != None:
            for paramName in thisTrial_ex_old:
                globals()[paramName] = thisTrial_ex_old[paramName]
        
        # --- Prepare to start Routine "Exemplo_old" ---
        # create an object to store info about Routine Exemplo_old
        Exemplo_old = data.Routine(
            name='Exemplo_old',
            components=[image_exemplo_old_new, key_ex_old, text_ex_old],
        )
        Exemplo_old.status = NOT_STARTED
        continueRoutine = True
        # update component parameters for each repeat
        image_exemplo_old_new.setSize(scene_size)
        image_exemplo_old_new.setImage(ex_scene_old_new)
        # create starting attributes for key_ex_old
        key_ex_old.keys = []
        key_ex_old.rt = []
        _key_ex_old_allKeys = []
        # store start times for Exemplo_old
        Exemplo_old.tStartRefresh = win.getFutureFlipTime(clock=globalClock)
        Exemplo_old.tStart = globalClock.getTime(format='float')
        Exemplo_old.status = STARTED
        thisExp.addData('Exemplo_old.started', Exemplo_old.tStart)
        Exemplo_old.maxDuration = None
        # keep track of which components have finished
        Exemplo_oldComponents = Exemplo_old.components
        for thisComponent in Exemplo_old.components:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        frameN = -1
        
        # --- Run Routine "Exemplo_old" ---
        thisExp.currentRoutine = Exemplo_old
        Exemplo_old.forceEnded = routineForceEnded = not continueRoutine
        while continueRoutine and routineTimer.getTime() < 2.5:
            # if trial has changed, end Routine now
            if hasattr(thisTrial_ex_old, 'status') and thisTrial_ex_old.status == STOPPING:
                continueRoutine = False
            # get current time
            t = routineTimer.getTime()
            tThisFlip = win.getFutureFlipTime(clock=routineTimer)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *image_exemplo_old_new* updates
            
            # if image_exemplo_old_new is starting this frame...
            if image_exemplo_old_new.status == NOT_STARTED and tThisFlip >= 0-frameTolerance:
                # keep track of start time/frame for later
                image_exemplo_old_new.frameNStart = frameN  # exact frame index
                image_exemplo_old_new.tStart = t  # local t and not account for scr refresh
                image_exemplo_old_new.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(image_exemplo_old_new, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'image_exemplo_old_new.started')
                # update status
                image_exemplo_old_new.status = STARTED
                image_exemplo_old_new.setAutoDraw(True)
            
            # if image_exemplo_old_new is active this frame...
            if image_exemplo_old_new.status == STARTED:
                # update params
                pass
            
            # if image_exemplo_old_new is stopping this frame...
            if image_exemplo_old_new.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > image_exemplo_old_new.tStartRefresh + 2.5-frameTolerance:
                    # keep track of stop time/frame for later
                    image_exemplo_old_new.tStop = t  # not accounting for scr refresh
                    image_exemplo_old_new.tStopRefresh = tThisFlipGlobal  # on global time
                    image_exemplo_old_new.frameNStop = frameN  # exact frame index
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'image_exemplo_old_new.stopped')
                    # update status
                    image_exemplo_old_new.status = FINISHED
                    image_exemplo_old_new.setAutoDraw(False)
            
            # *key_ex_old* updates
            waitOnFlip = False
            
            # if key_ex_old is starting this frame...
            if key_ex_old.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                key_ex_old.frameNStart = frameN  # exact frame index
                key_ex_old.tStart = t  # local t and not account for scr refresh
                key_ex_old.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(key_ex_old, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'key_ex_old.started')
                # update status
                key_ex_old.status = STARTED
                # keyboard checking is just starting
                waitOnFlip = True
                win.callOnFlip(key_ex_old.clock.reset)  # t=0 on next screen flip
                win.callOnFlip(key_ex_old.clearEvents, eventType='keyboard')  # clear events on next screen flip
            
            # if key_ex_old is stopping this frame...
            if key_ex_old.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > key_ex_old.tStartRefresh + 2.5-frameTolerance:
                    # keep track of stop time/frame for later
                    key_ex_old.tStop = t  # not accounting for scr refresh
                    key_ex_old.tStopRefresh = tThisFlipGlobal  # on global time
                    key_ex_old.frameNStop = frameN  # exact frame index
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'key_ex_old.stopped')
                    # update status
                    key_ex_old.status = FINISHED
                    key_ex_old.status = FINISHED
            if key_ex_old.status == STARTED and not waitOnFlip:
                theseKeys = key_ex_old.getKeys(keyList=['v','n','left','right'], ignoreKeys=["escape"], waitRelease=False)
                _key_ex_old_allKeys.extend(theseKeys)
                if len(_key_ex_old_allKeys):
                    key_ex_old.keys = [key.name for key in _key_ex_old_allKeys]  # storing all keys
                    key_ex_old.rt = [key.rt for key in _key_ex_old_allKeys]
                    key_ex_old.duration = [key.duration for key in _key_ex_old_allKeys]
            
            # *text_ex_old* updates
            
            # if text_ex_old is starting this frame...
            if text_ex_old.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                text_ex_old.frameNStart = frameN  # exact frame index
                text_ex_old.tStart = t  # local t and not account for scr refresh
                text_ex_old.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(text_ex_old, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'text_ex_old.started')
                # update status
                text_ex_old.status = STARTED
                text_ex_old.setAutoDraw(True)
            
            # if text_ex_old is active this frame...
            if text_ex_old.status == STARTED:
                # update params
                pass
            
            # if text_ex_old is stopping this frame...
            if text_ex_old.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > text_ex_old.tStartRefresh + 2.5-frameTolerance:
                    # keep track of stop time/frame for later
                    text_ex_old.tStop = t  # not accounting for scr refresh
                    text_ex_old.tStopRefresh = tThisFlipGlobal  # on global time
                    text_ex_old.frameNStop = frameN  # exact frame index
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'text_ex_old.stopped')
                    # update status
                    text_ex_old.status = FINISHED
                    text_ex_old.setAutoDraw(False)
            
            # check for quit (typically the Esc key)
            if defaultKeyboard.getKeys(keyList=["escape"]):
                thisExp.status = FINISHED
            if thisExp.status == FINISHED or endExpNow:
                endExperiment(thisExp, win=win)
                return
            # pause experiment here if requested
            if thisExp.status == PAUSED:
                pauseExperiment(
                    thisExp=thisExp, 
                    win=win, 
                    timers=[routineTimer, globalClock], 
                    currentRoutine=Exemplo_old,
                )
                # skip the frame we paused on
                continue
            
            # has a Component requested the Routine to end?
            if not continueRoutine:
                Exemplo_old.forceEnded = routineForceEnded = True
            # has the Routine been forcibly ended?
            if Exemplo_old.forceEnded or routineForceEnded:
                break
            # has every Component finished?
            continueRoutine = False
            for thisComponent in Exemplo_old.components:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # --- Ending Routine "Exemplo_old" ---
        for thisComponent in Exemplo_old.components:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        # store stop times for Exemplo_old
        Exemplo_old.tStop = globalClock.getTime(format='float')
        Exemplo_old.tStopRefresh = tThisFlipGlobal
        thisExp.addData('Exemplo_old.stopped', Exemplo_old.tStop)
        # check responses
        if key_ex_old.keys in ['', [], None]:  # No response was made
            key_ex_old.keys = None
        trial_ex_old.addData('key_ex_old.keys',key_ex_old.keys)
        if key_ex_old.keys != None:  # we had a response
            trial_ex_old.addData('key_ex_old.rt', key_ex_old.rt)
            trial_ex_old.addData('key_ex_old.duration', key_ex_old.duration)
        # using non-slip timing so subtract the expected duration of this Routine (unless ended on request)
        if Exemplo_old.maxDurationReached:
            routineTimer.addTime(-Exemplo_old.maxDuration)
        elif Exemplo_old.forceEnded:
            routineTimer.reset()
        else:
            routineTimer.addTime(-2.500000)
        
        # --- Prepare to start Routine "blank" ---
        # create an object to store info about Routine blank
        blank = data.Routine(
            name='blank',
            components=[cross_25, image_blank],
        )
        blank.status = NOT_STARTED
        continueRoutine = True
        # update component parameters for each repeat
        # store start times for blank
        blank.tStartRefresh = win.getFutureFlipTime(clock=globalClock)
        blank.tStart = globalClock.getTime(format='float')
        blank.status = STARTED
        thisExp.addData('blank.started', blank.tStart)
        blank.maxDuration = None
        # keep track of which components have finished
        blankComponents = blank.components
        for thisComponent in blank.components:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        frameN = -1
        
        # --- Run Routine "blank" ---
        thisExp.currentRoutine = blank
        blank.forceEnded = routineForceEnded = not continueRoutine
        while continueRoutine and routineTimer.getTime() < 2.5:
            # if trial has changed, end Routine now
            if hasattr(thisTrial_ex_old, 'status') and thisTrial_ex_old.status == STOPPING:
                continueRoutine = False
            # get current time
            t = routineTimer.getTime()
            tThisFlip = win.getFutureFlipTime(clock=routineTimer)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *cross_25* updates
            
            # if cross_25 is starting this frame...
            if cross_25.status == NOT_STARTED and tThisFlip >= 2.25-frameTolerance:
                # keep track of start time/frame for later
                cross_25.frameNStart = frameN  # exact frame index
                cross_25.tStart = t  # local t and not account for scr refresh
                cross_25.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(cross_25, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'cross_25.started')
                # update status
                cross_25.status = STARTED
                cross_25.setAutoDraw(True)
            
            # if cross_25 is active this frame...
            if cross_25.status == STARTED:
                # update params
                pass
            
            # if cross_25 is stopping this frame...
            if cross_25.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > cross_25.tStartRefresh + 0.25-frameTolerance:
                    # keep track of stop time/frame for later
                    cross_25.tStop = t  # not accounting for scr refresh
                    cross_25.tStopRefresh = tThisFlipGlobal  # on global time
                    cross_25.frameNStop = frameN  # exact frame index
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'cross_25.stopped')
                    # update status
                    cross_25.status = FINISHED
                    cross_25.setAutoDraw(False)
            
            # *image_blank* updates
            
            # if image_blank is starting this frame...
            if image_blank.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                image_blank.frameNStart = frameN  # exact frame index
                image_blank.tStart = t  # local t and not account for scr refresh
                image_blank.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(image_blank, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'image_blank.started')
                # update status
                image_blank.status = STARTED
                image_blank.setAutoDraw(True)
            
            # if image_blank is active this frame...
            if image_blank.status == STARTED:
                # update params
                pass
            
            # if image_blank is stopping this frame...
            if image_blank.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > image_blank.tStartRefresh + 2.25-frameTolerance:
                    # keep track of stop time/frame for later
                    image_blank.tStop = t  # not accounting for scr refresh
                    image_blank.tStopRefresh = tThisFlipGlobal  # on global time
                    image_blank.frameNStop = frameN  # exact frame index
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'image_blank.stopped')
                    # update status
                    image_blank.status = FINISHED
                    image_blank.setAutoDraw(False)
            
            # check for quit (typically the Esc key)
            if defaultKeyboard.getKeys(keyList=["escape"]):
                thisExp.status = FINISHED
            if thisExp.status == FINISHED or endExpNow:
                endExperiment(thisExp, win=win)
                return
            # pause experiment here if requested
            if thisExp.status == PAUSED:
                pauseExperiment(
                    thisExp=thisExp, 
                    win=win, 
                    timers=[routineTimer, globalClock], 
                    currentRoutine=blank,
                )
                # skip the frame we paused on
                continue
            
            # has a Component requested the Routine to end?
            if not continueRoutine:
                blank.forceEnded = routineForceEnded = True
            # has the Routine been forcibly ended?
            if blank.forceEnded or routineForceEnded:
                break
            # has every Component finished?
            continueRoutine = False
            for thisComponent in blank.components:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # --- Ending Routine "blank" ---
        for thisComponent in blank.components:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        # store stop times for blank
        blank.tStop = globalClock.getTime(format='float')
        blank.tStopRefresh = tThisFlipGlobal
        thisExp.addData('blank.stopped', blank.tStop)
        # using non-slip timing so subtract the expected duration of this Routine (unless ended on request)
        if blank.maxDurationReached:
            routineTimer.addTime(-blank.maxDuration)
        elif blank.forceEnded:
            routineTimer.reset()
        else:
            routineTimer.addTime(-2.500000)
        # mark thisTrial_ex_old as finished
        if hasattr(thisTrial_ex_old, 'status'):
            thisTrial_ex_old.status = FINISHED
        # if awaiting a pause, pause now
        if trial_ex_old.status == PAUSED:
            thisExp.status = PAUSED
            pauseExperiment(
                thisExp=thisExp, 
                win=win, 
                timers=[globalClock], 
            )
            # once done pausing, restore running status
            trial_ex_old.status = STARTED
        thisExp.nextEntry()
        
    # completed 1.0 repeats of 'trial_ex_old'
    trial_ex_old.status = FINISHED
    
    if thisSession is not None:
        # if running in a Session with a Liaison client, send data up to now
        thisSession.sendExperimentData()
    
    # --- Prepare to start Routine "Start_Recall" ---
    # create an object to store info about Routine Start_Recall
    Start_Recall = data.Routine(
        name='Start_Recall',
        components=[text_start_recall, key_start_recall],
    )
    Start_Recall.status = NOT_STARTED
    continueRoutine = True
    # update component parameters for each repeat
    # create starting attributes for key_start_recall
    key_start_recall.keys = []
    key_start_recall.rt = []
    _key_start_recall_allKeys = []
    # store start times for Start_Recall
    Start_Recall.tStartRefresh = win.getFutureFlipTime(clock=globalClock)
    Start_Recall.tStart = globalClock.getTime(format='float')
    Start_Recall.status = STARTED
    thisExp.addData('Start_Recall.started', Start_Recall.tStart)
    Start_Recall.maxDuration = None
    # keep track of which components have finished
    Start_RecallComponents = Start_Recall.components
    for thisComponent in Start_Recall.components:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    frameN = -1
    
    # --- Run Routine "Start_Recall" ---
    thisExp.currentRoutine = Start_Recall
    Start_Recall.forceEnded = routineForceEnded = not continueRoutine
    while continueRoutine:
        # get current time
        t = routineTimer.getTime()
        tThisFlip = win.getFutureFlipTime(clock=routineTimer)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *text_start_recall* updates
        
        # if text_start_recall is starting this frame...
        if text_start_recall.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            text_start_recall.frameNStart = frameN  # exact frame index
            text_start_recall.tStart = t  # local t and not account for scr refresh
            text_start_recall.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(text_start_recall, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'text_start_recall.started')
            # update status
            text_start_recall.status = STARTED
            text_start_recall.setAutoDraw(True)
        
        # if text_start_recall is active this frame...
        if text_start_recall.status == STARTED:
            # update params
            pass
        
        # *key_start_recall* updates
        waitOnFlip = False
        
        # if key_start_recall is starting this frame...
        if key_start_recall.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            key_start_recall.frameNStart = frameN  # exact frame index
            key_start_recall.tStart = t  # local t and not account for scr refresh
            key_start_recall.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(key_start_recall, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'key_start_recall.started')
            # update status
            key_start_recall.status = STARTED
            # keyboard checking is just starting
            waitOnFlip = True
            win.callOnFlip(key_start_recall.clock.reset)  # t=0 on next screen flip
            win.callOnFlip(key_start_recall.clearEvents, eventType='keyboard')  # clear events on next screen flip
        if key_start_recall.status == STARTED and not waitOnFlip:
            theseKeys = key_start_recall.getKeys(keyList=['y','n','left','right','space'], ignoreKeys=["escape"], waitRelease=False)
            _key_start_recall_allKeys.extend(theseKeys)
            if len(_key_start_recall_allKeys):
                key_start_recall.keys = _key_start_recall_allKeys[-1].name  # just the last key pressed
                key_start_recall.rt = _key_start_recall_allKeys[-1].rt
                key_start_recall.duration = _key_start_recall_allKeys[-1].duration
                # a response ends the routine
                continueRoutine = False
        
        # check for quit (typically the Esc key)
        if defaultKeyboard.getKeys(keyList=["escape"]):
            thisExp.status = FINISHED
        if thisExp.status == FINISHED or endExpNow:
            endExperiment(thisExp, win=win)
            return
        # pause experiment here if requested
        if thisExp.status == PAUSED:
            pauseExperiment(
                thisExp=thisExp, 
                win=win, 
                timers=[routineTimer, globalClock], 
                currentRoutine=Start_Recall,
            )
            # skip the frame we paused on
            continue
        
        # has a Component requested the Routine to end?
        if not continueRoutine:
            Start_Recall.forceEnded = routineForceEnded = True
        # has the Routine been forcibly ended?
        if Start_Recall.forceEnded or routineForceEnded:
            break
        # has every Component finished?
        continueRoutine = False
        for thisComponent in Start_Recall.components:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # --- Ending Routine "Start_Recall" ---
    for thisComponent in Start_Recall.components:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    # store stop times for Start_Recall
    Start_Recall.tStop = globalClock.getTime(format='float')
    Start_Recall.tStopRefresh = tThisFlipGlobal
    thisExp.addData('Start_Recall.stopped', Start_Recall.tStop)
    # check responses
    if key_start_recall.keys in ['', [], None]:  # No response was made
        key_start_recall.keys = None
    thisExp.addData('key_start_recall.keys',key_start_recall.keys)
    if key_start_recall.keys != None:  # we had a response
        thisExp.addData('key_start_recall.rt', key_start_recall.rt)
        thisExp.addData('key_start_recall.duration', key_start_recall.duration)
    thisExp.nextEntry()
    # the Routine "Start_Recall" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # set up handler to look after randomisation of conditions etc
    trial_item = data.TrialHandler2(
        name='trial_item',
        nReps=1.0, 
        method='random', 
        extraInfo=expInfo, 
        originPath=-1, 
        trialList=data.importConditions('old_new.xlsx'), 
        seed=None, 
        isTrials=True, 
    )
    thisExp.addLoop(trial_item)  # add the loop to the experiment
    thisTrial_item = trial_item.trialList[0]  # so we can initialise stimuli with some values
    # abbreviate parameter names if possible (e.g. rgb = thisTrial_item.rgb)
    if thisTrial_item != None:
        for paramName in thisTrial_item:
            globals()[paramName] = thisTrial_item[paramName]
    if thisSession is not None:
        # if running in a Session with a Liaison client, send data up to now
        thisSession.sendExperimentData()
    
    for thisTrial_item in trial_item:
        trial_item.status = STARTED
        if hasattr(thisTrial_item, 'status'):
            thisTrial_item.status = STARTED
        currentLoop = trial_item
        thisExp.timestampOnFlip(win, 'thisRow.t', format=globalClock.format)
        if thisSession is not None:
            # if running in a Session with a Liaison client, send data up to now
            thisSession.sendExperimentData()
        # abbreviate parameter names if possible (e.g. rgb = thisTrial_item.rgb)
        if thisTrial_item != None:
            for paramName in thisTrial_item:
                globals()[paramName] = thisTrial_item[paramName]
        
        # --- Prepare to start Routine "Old_New" ---
        # create an object to store info about Routine Old_New
        Old_New = data.Routine(
            name='Old_New',
            components=[image_old_new, key_item, text_item],
        )
        Old_New.status = NOT_STARTED
        continueRoutine = True
        # update component parameters for each repeat
        image_old_new.setSize(size_scene)
        image_old_new.setImage(old_new_scene)
        # create starting attributes for key_item
        key_item.keys = []
        key_item.rt = []
        _key_item_allKeys = []
        # store start times for Old_New
        Old_New.tStartRefresh = win.getFutureFlipTime(clock=globalClock)
        Old_New.tStart = globalClock.getTime(format='float')
        Old_New.status = STARTED
        thisExp.addData('Old_New.started', Old_New.tStart)
        Old_New.maxDuration = None
        # keep track of which components have finished
        Old_NewComponents = Old_New.components
        for thisComponent in Old_New.components:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        frameN = -1
        
        # --- Run Routine "Old_New" ---
        thisExp.currentRoutine = Old_New
        Old_New.forceEnded = routineForceEnded = not continueRoutine
        while continueRoutine and routineTimer.getTime() < 2.5:
            # if trial has changed, end Routine now
            if hasattr(thisTrial_item, 'status') and thisTrial_item.status == STOPPING:
                continueRoutine = False
            # get current time
            t = routineTimer.getTime()
            tThisFlip = win.getFutureFlipTime(clock=routineTimer)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *image_old_new* updates
            
            # if image_old_new is starting this frame...
            if image_old_new.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                image_old_new.frameNStart = frameN  # exact frame index
                image_old_new.tStart = t  # local t and not account for scr refresh
                image_old_new.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(image_old_new, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'image_old_new.started')
                # update status
                image_old_new.status = STARTED
                image_old_new.setAutoDraw(True)
            
            # if image_old_new is active this frame...
            if image_old_new.status == STARTED:
                # update params
                pass
            
            # if image_old_new is stopping this frame...
            if image_old_new.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > image_old_new.tStartRefresh + 2.5-frameTolerance:
                    # keep track of stop time/frame for later
                    image_old_new.tStop = t  # not accounting for scr refresh
                    image_old_new.tStopRefresh = tThisFlipGlobal  # on global time
                    image_old_new.frameNStop = frameN  # exact frame index
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'image_old_new.stopped')
                    # update status
                    image_old_new.status = FINISHED
                    image_old_new.setAutoDraw(False)
            
            # *key_item* updates
            waitOnFlip = False
            
            # if key_item is starting this frame...
            if key_item.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                key_item.frameNStart = frameN  # exact frame index
                key_item.tStart = t  # local t and not account for scr refresh
                key_item.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(key_item, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'key_item.started')
                # update status
                key_item.status = STARTED
                # keyboard checking is just starting
                waitOnFlip = True
                win.callOnFlip(key_item.clock.reset)  # t=0 on next screen flip
                win.callOnFlip(key_item.clearEvents, eventType='keyboard')  # clear events on next screen flip
            
            # if key_item is stopping this frame...
            if key_item.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > key_item.tStartRefresh + 2.5-frameTolerance:
                    # keep track of stop time/frame for later
                    key_item.tStop = t  # not accounting for scr refresh
                    key_item.tStopRefresh = tThisFlipGlobal  # on global time
                    key_item.frameNStop = frameN  # exact frame index
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'key_item.stopped')
                    # update status
                    key_item.status = FINISHED
                    key_item.status = FINISHED
            if key_item.status == STARTED and not waitOnFlip:
                theseKeys = key_item.getKeys(keyList=['v','n','left','right'], ignoreKeys=["escape"], waitRelease=False)
                _key_item_allKeys.extend(theseKeys)
                if len(_key_item_allKeys):
                    key_item.keys = [key.name for key in _key_item_allKeys]  # storing all keys
                    key_item.rt = [key.rt for key in _key_item_allKeys]
                    key_item.duration = [key.duration for key in _key_item_allKeys]
            
            # *text_item* updates
            
            # if text_item is starting this frame...
            if text_item.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                text_item.frameNStart = frameN  # exact frame index
                text_item.tStart = t  # local t and not account for scr refresh
                text_item.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(text_item, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'text_item.started')
                # update status
                text_item.status = STARTED
                text_item.setAutoDraw(True)
            
            # if text_item is active this frame...
            if text_item.status == STARTED:
                # update params
                pass
            
            # if text_item is stopping this frame...
            if text_item.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > text_item.tStartRefresh + 2.5-frameTolerance:
                    # keep track of stop time/frame for later
                    text_item.tStop = t  # not accounting for scr refresh
                    text_item.tStopRefresh = tThisFlipGlobal  # on global time
                    text_item.frameNStop = frameN  # exact frame index
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'text_item.stopped')
                    # update status
                    text_item.status = FINISHED
                    text_item.setAutoDraw(False)
            
            # check for quit (typically the Esc key)
            if defaultKeyboard.getKeys(keyList=["escape"]):
                thisExp.status = FINISHED
            if thisExp.status == FINISHED or endExpNow:
                endExperiment(thisExp, win=win)
                return
            # pause experiment here if requested
            if thisExp.status == PAUSED:
                pauseExperiment(
                    thisExp=thisExp, 
                    win=win, 
                    timers=[routineTimer, globalClock], 
                    currentRoutine=Old_New,
                )
                # skip the frame we paused on
                continue
            
            # has a Component requested the Routine to end?
            if not continueRoutine:
                Old_New.forceEnded = routineForceEnded = True
            # has the Routine been forcibly ended?
            if Old_New.forceEnded or routineForceEnded:
                break
            # has every Component finished?
            continueRoutine = False
            for thisComponent in Old_New.components:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # --- Ending Routine "Old_New" ---
        for thisComponent in Old_New.components:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        # store stop times for Old_New
        Old_New.tStop = globalClock.getTime(format='float')
        Old_New.tStopRefresh = tThisFlipGlobal
        thisExp.addData('Old_New.stopped', Old_New.tStop)
        # check responses
        if key_item.keys in ['', [], None]:  # No response was made
            key_item.keys = None
        trial_item.addData('key_item.keys',key_item.keys)
        if key_item.keys != None:  # we had a response
            trial_item.addData('key_item.rt', key_item.rt)
            trial_item.addData('key_item.duration', key_item.duration)
        # using non-slip timing so subtract the expected duration of this Routine (unless ended on request)
        if Old_New.maxDurationReached:
            routineTimer.addTime(-Old_New.maxDuration)
        elif Old_New.forceEnded:
            routineTimer.reset()
        else:
            routineTimer.addTime(-2.500000)
        
        # --- Prepare to start Routine "blank" ---
        # create an object to store info about Routine blank
        blank = data.Routine(
            name='blank',
            components=[cross_25, image_blank],
        )
        blank.status = NOT_STARTED
        continueRoutine = True
        # update component parameters for each repeat
        # store start times for blank
        blank.tStartRefresh = win.getFutureFlipTime(clock=globalClock)
        blank.tStart = globalClock.getTime(format='float')
        blank.status = STARTED
        thisExp.addData('blank.started', blank.tStart)
        blank.maxDuration = None
        # keep track of which components have finished
        blankComponents = blank.components
        for thisComponent in blank.components:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        frameN = -1
        
        # --- Run Routine "blank" ---
        thisExp.currentRoutine = blank
        blank.forceEnded = routineForceEnded = not continueRoutine
        while continueRoutine and routineTimer.getTime() < 2.5:
            # if trial has changed, end Routine now
            if hasattr(thisTrial_item, 'status') and thisTrial_item.status == STOPPING:
                continueRoutine = False
            # get current time
            t = routineTimer.getTime()
            tThisFlip = win.getFutureFlipTime(clock=routineTimer)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *cross_25* updates
            
            # if cross_25 is starting this frame...
            if cross_25.status == NOT_STARTED and tThisFlip >= 2.25-frameTolerance:
                # keep track of start time/frame for later
                cross_25.frameNStart = frameN  # exact frame index
                cross_25.tStart = t  # local t and not account for scr refresh
                cross_25.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(cross_25, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'cross_25.started')
                # update status
                cross_25.status = STARTED
                cross_25.setAutoDraw(True)
            
            # if cross_25 is active this frame...
            if cross_25.status == STARTED:
                # update params
                pass
            
            # if cross_25 is stopping this frame...
            if cross_25.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > cross_25.tStartRefresh + 0.25-frameTolerance:
                    # keep track of stop time/frame for later
                    cross_25.tStop = t  # not accounting for scr refresh
                    cross_25.tStopRefresh = tThisFlipGlobal  # on global time
                    cross_25.frameNStop = frameN  # exact frame index
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'cross_25.stopped')
                    # update status
                    cross_25.status = FINISHED
                    cross_25.setAutoDraw(False)
            
            # *image_blank* updates
            
            # if image_blank is starting this frame...
            if image_blank.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                image_blank.frameNStart = frameN  # exact frame index
                image_blank.tStart = t  # local t and not account for scr refresh
                image_blank.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(image_blank, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'image_blank.started')
                # update status
                image_blank.status = STARTED
                image_blank.setAutoDraw(True)
            
            # if image_blank is active this frame...
            if image_blank.status == STARTED:
                # update params
                pass
            
            # if image_blank is stopping this frame...
            if image_blank.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > image_blank.tStartRefresh + 2.25-frameTolerance:
                    # keep track of stop time/frame for later
                    image_blank.tStop = t  # not accounting for scr refresh
                    image_blank.tStopRefresh = tThisFlipGlobal  # on global time
                    image_blank.frameNStop = frameN  # exact frame index
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'image_blank.stopped')
                    # update status
                    image_blank.status = FINISHED
                    image_blank.setAutoDraw(False)
            
            # check for quit (typically the Esc key)
            if defaultKeyboard.getKeys(keyList=["escape"]):
                thisExp.status = FINISHED
            if thisExp.status == FINISHED or endExpNow:
                endExperiment(thisExp, win=win)
                return
            # pause experiment here if requested
            if thisExp.status == PAUSED:
                pauseExperiment(
                    thisExp=thisExp, 
                    win=win, 
                    timers=[routineTimer, globalClock], 
                    currentRoutine=blank,
                )
                # skip the frame we paused on
                continue
            
            # has a Component requested the Routine to end?
            if not continueRoutine:
                blank.forceEnded = routineForceEnded = True
            # has the Routine been forcibly ended?
            if blank.forceEnded or routineForceEnded:
                break
            # has every Component finished?
            continueRoutine = False
            for thisComponent in blank.components:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # --- Ending Routine "blank" ---
        for thisComponent in blank.components:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        # store stop times for blank
        blank.tStop = globalClock.getTime(format='float')
        blank.tStopRefresh = tThisFlipGlobal
        thisExp.addData('blank.stopped', blank.tStop)
        # using non-slip timing so subtract the expected duration of this Routine (unless ended on request)
        if blank.maxDurationReached:
            routineTimer.addTime(-blank.maxDuration)
        elif blank.forceEnded:
            routineTimer.reset()
        else:
            routineTimer.addTime(-2.500000)
        # mark thisTrial_item as finished
        if hasattr(thisTrial_item, 'status'):
            thisTrial_item.status = FINISHED
        # if awaiting a pause, pause now
        if trial_item.status == PAUSED:
            thisExp.status = PAUSED
            pauseExperiment(
                thisExp=thisExp, 
                win=win, 
                timers=[globalClock], 
            )
            # once done pausing, restore running status
            trial_item.status = STARTED
        thisExp.nextEntry()
        
    # completed 1.0 repeats of 'trial_item'
    trial_item.status = FINISHED
    
    if thisSession is not None:
        # if running in a Session with a Liaison client, send data up to now
        thisSession.sendExperimentData()
    
    # --- Prepare to start Routine "End_Old_New" ---
    # create an object to store info about Routine End_Old_New
    End_Old_New = data.Routine(
        name='End_Old_New',
        components=[text_end_item, key_resp_2],
    )
    End_Old_New.status = NOT_STARTED
    continueRoutine = True
    # update component parameters for each repeat
    # create starting attributes for key_resp_2
    key_resp_2.keys = []
    key_resp_2.rt = []
    _key_resp_2_allKeys = []
    # store start times for End_Old_New
    End_Old_New.tStartRefresh = win.getFutureFlipTime(clock=globalClock)
    End_Old_New.tStart = globalClock.getTime(format='float')
    End_Old_New.status = STARTED
    thisExp.addData('End_Old_New.started', End_Old_New.tStart)
    End_Old_New.maxDuration = None
    # keep track of which components have finished
    End_Old_NewComponents = End_Old_New.components
    for thisComponent in End_Old_New.components:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    frameN = -1
    
    # --- Run Routine "End_Old_New" ---
    thisExp.currentRoutine = End_Old_New
    End_Old_New.forceEnded = routineForceEnded = not continueRoutine
    while continueRoutine:
        # get current time
        t = routineTimer.getTime()
        tThisFlip = win.getFutureFlipTime(clock=routineTimer)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *text_end_item* updates
        
        # if text_end_item is starting this frame...
        if text_end_item.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            text_end_item.frameNStart = frameN  # exact frame index
            text_end_item.tStart = t  # local t and not account for scr refresh
            text_end_item.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(text_end_item, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'text_end_item.started')
            # update status
            text_end_item.status = STARTED
            text_end_item.setAutoDraw(True)
        
        # if text_end_item is active this frame...
        if text_end_item.status == STARTED:
            # update params
            pass
        
        # *key_resp_2* updates
        waitOnFlip = False
        
        # if key_resp_2 is starting this frame...
        if key_resp_2.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            key_resp_2.frameNStart = frameN  # exact frame index
            key_resp_2.tStart = t  # local t and not account for scr refresh
            key_resp_2.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(key_resp_2, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'key_resp_2.started')
            # update status
            key_resp_2.status = STARTED
            # keyboard checking is just starting
            waitOnFlip = True
            win.callOnFlip(key_resp_2.clock.reset)  # t=0 on next screen flip
            win.callOnFlip(key_resp_2.clearEvents, eventType='keyboard')  # clear events on next screen flip
        if key_resp_2.status == STARTED and not waitOnFlip:
            theseKeys = key_resp_2.getKeys(keyList=['y','n','left','right','space'], ignoreKeys=["escape"], waitRelease=False)
            _key_resp_2_allKeys.extend(theseKeys)
            if len(_key_resp_2_allKeys):
                key_resp_2.keys = _key_resp_2_allKeys[-1].name  # just the last key pressed
                key_resp_2.rt = _key_resp_2_allKeys[-1].rt
                key_resp_2.duration = _key_resp_2_allKeys[-1].duration
                # a response ends the routine
                continueRoutine = False
        
        # check for quit (typically the Esc key)
        if defaultKeyboard.getKeys(keyList=["escape"]):
            thisExp.status = FINISHED
        if thisExp.status == FINISHED or endExpNow:
            endExperiment(thisExp, win=win)
            return
        # pause experiment here if requested
        if thisExp.status == PAUSED:
            pauseExperiment(
                thisExp=thisExp, 
                win=win, 
                timers=[routineTimer, globalClock], 
                currentRoutine=End_Old_New,
            )
            # skip the frame we paused on
            continue
        
        # has a Component requested the Routine to end?
        if not continueRoutine:
            End_Old_New.forceEnded = routineForceEnded = True
        # has the Routine been forcibly ended?
        if End_Old_New.forceEnded or routineForceEnded:
            break
        # has every Component finished?
        continueRoutine = False
        for thisComponent in End_Old_New.components:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # --- Ending Routine "End_Old_New" ---
    for thisComponent in End_Old_New.components:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    # store stop times for End_Old_New
    End_Old_New.tStop = globalClock.getTime(format='float')
    End_Old_New.tStopRefresh = tThisFlipGlobal
    thisExp.addData('End_Old_New.stopped', End_Old_New.tStop)
    # check responses
    if key_resp_2.keys in ['', [], None]:  # No response was made
        key_resp_2.keys = None
    thisExp.addData('key_resp_2.keys',key_resp_2.keys)
    if key_resp_2.keys != None:  # we had a response
        thisExp.addData('key_resp_2.rt', key_resp_2.rt)
        thisExp.addData('key_resp_2.duration', key_resp_2.duration)
    thisExp.nextEntry()
    # the Routine "End_Old_New" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # --- Prepare to start Routine "Explain_2AFC" ---
    # create an object to store info about Routine Explain_2AFC
    Explain_2AFC = data.Routine(
        name='Explain_2AFC',
        components=[text_explain_2afc, key_end_explain_2afc],
    )
    Explain_2AFC.status = NOT_STARTED
    continueRoutine = True
    # update component parameters for each repeat
    # create starting attributes for key_end_explain_2afc
    key_end_explain_2afc.keys = []
    key_end_explain_2afc.rt = []
    _key_end_explain_2afc_allKeys = []
    # store start times for Explain_2AFC
    Explain_2AFC.tStartRefresh = win.getFutureFlipTime(clock=globalClock)
    Explain_2AFC.tStart = globalClock.getTime(format='float')
    Explain_2AFC.status = STARTED
    thisExp.addData('Explain_2AFC.started', Explain_2AFC.tStart)
    Explain_2AFC.maxDuration = None
    # keep track of which components have finished
    Explain_2AFCComponents = Explain_2AFC.components
    for thisComponent in Explain_2AFC.components:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    frameN = -1
    
    # --- Run Routine "Explain_2AFC" ---
    thisExp.currentRoutine = Explain_2AFC
    Explain_2AFC.forceEnded = routineForceEnded = not continueRoutine
    while continueRoutine:
        # get current time
        t = routineTimer.getTime()
        tThisFlip = win.getFutureFlipTime(clock=routineTimer)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *text_explain_2afc* updates
        
        # if text_explain_2afc is starting this frame...
        if text_explain_2afc.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            text_explain_2afc.frameNStart = frameN  # exact frame index
            text_explain_2afc.tStart = t  # local t and not account for scr refresh
            text_explain_2afc.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(text_explain_2afc, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'text_explain_2afc.started')
            # update status
            text_explain_2afc.status = STARTED
            text_explain_2afc.setAutoDraw(True)
        
        # if text_explain_2afc is active this frame...
        if text_explain_2afc.status == STARTED:
            # update params
            pass
        
        # *key_end_explain_2afc* updates
        waitOnFlip = False
        
        # if key_end_explain_2afc is starting this frame...
        if key_end_explain_2afc.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            key_end_explain_2afc.frameNStart = frameN  # exact frame index
            key_end_explain_2afc.tStart = t  # local t and not account for scr refresh
            key_end_explain_2afc.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(key_end_explain_2afc, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'key_end_explain_2afc.started')
            # update status
            key_end_explain_2afc.status = STARTED
            # keyboard checking is just starting
            waitOnFlip = True
            win.callOnFlip(key_end_explain_2afc.clock.reset)  # t=0 on next screen flip
            win.callOnFlip(key_end_explain_2afc.clearEvents, eventType='keyboard')  # clear events on next screen flip
        if key_end_explain_2afc.status == STARTED and not waitOnFlip:
            theseKeys = key_end_explain_2afc.getKeys(keyList=['y','n','left','right','space'], ignoreKeys=["escape"], waitRelease=False)
            _key_end_explain_2afc_allKeys.extend(theseKeys)
            if len(_key_end_explain_2afc_allKeys):
                key_end_explain_2afc.keys = _key_end_explain_2afc_allKeys[-1].name  # just the last key pressed
                key_end_explain_2afc.rt = _key_end_explain_2afc_allKeys[-1].rt
                key_end_explain_2afc.duration = _key_end_explain_2afc_allKeys[-1].duration
                # a response ends the routine
                continueRoutine = False
        
        # check for quit (typically the Esc key)
        if defaultKeyboard.getKeys(keyList=["escape"]):
            thisExp.status = FINISHED
        if thisExp.status == FINISHED or endExpNow:
            endExperiment(thisExp, win=win)
            return
        # pause experiment here if requested
        if thisExp.status == PAUSED:
            pauseExperiment(
                thisExp=thisExp, 
                win=win, 
                timers=[routineTimer, globalClock], 
                currentRoutine=Explain_2AFC,
            )
            # skip the frame we paused on
            continue
        
        # has a Component requested the Routine to end?
        if not continueRoutine:
            Explain_2AFC.forceEnded = routineForceEnded = True
        # has the Routine been forcibly ended?
        if Explain_2AFC.forceEnded or routineForceEnded:
            break
        # has every Component finished?
        continueRoutine = False
        for thisComponent in Explain_2AFC.components:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # --- Ending Routine "Explain_2AFC" ---
    for thisComponent in Explain_2AFC.components:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    # store stop times for Explain_2AFC
    Explain_2AFC.tStop = globalClock.getTime(format='float')
    Explain_2AFC.tStopRefresh = tThisFlipGlobal
    thisExp.addData('Explain_2AFC.stopped', Explain_2AFC.tStop)
    # check responses
    if key_end_explain_2afc.keys in ['', [], None]:  # No response was made
        key_end_explain_2afc.keys = None
    thisExp.addData('key_end_explain_2afc.keys',key_end_explain_2afc.keys)
    if key_end_explain_2afc.keys != None:  # we had a response
        thisExp.addData('key_end_explain_2afc.rt', key_end_explain_2afc.rt)
        thisExp.addData('key_end_explain_2afc.duration', key_end_explain_2afc.duration)
    thisExp.nextEntry()
    # the Routine "Explain_2AFC" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # set up handler to look after randomisation of conditions etc
    trial_ex_2AFC = data.TrialHandler2(
        name='trial_ex_2AFC',
        nReps=1.0, 
        method='random', 
        extraInfo=expInfo, 
        originPath=-1, 
        trialList=data.importConditions('Exemplo_encode.xlsx'), 
        seed=None, 
        isTrials=True, 
    )
    thisExp.addLoop(trial_ex_2AFC)  # add the loop to the experiment
    thisTrial_ex_2AFC = trial_ex_2AFC.trialList[0]  # so we can initialise stimuli with some values
    # abbreviate parameter names if possible (e.g. rgb = thisTrial_ex_2AFC.rgb)
    if thisTrial_ex_2AFC != None:
        for paramName in thisTrial_ex_2AFC:
            globals()[paramName] = thisTrial_ex_2AFC[paramName]
    if thisSession is not None:
        # if running in a Session with a Liaison client, send data up to now
        thisSession.sendExperimentData()
    
    for thisTrial_ex_2AFC in trial_ex_2AFC:
        trial_ex_2AFC.status = STARTED
        if hasattr(thisTrial_ex_2AFC, 'status'):
            thisTrial_ex_2AFC.status = STARTED
        currentLoop = trial_ex_2AFC
        thisExp.timestampOnFlip(win, 'thisRow.t', format=globalClock.format)
        if thisSession is not None:
            # if running in a Session with a Liaison client, send data up to now
            thisSession.sendExperimentData()
        # abbreviate parameter names if possible (e.g. rgb = thisTrial_ex_2AFC.rgb)
        if thisTrial_ex_2AFC != None:
            for paramName in thisTrial_ex_2AFC:
                globals()[paramName] = thisTrial_ex_2AFC[paramName]
        
        # --- Prepare to start Routine "Exemplo_2AFC" ---
        # create an object to store info about Routine Exemplo_2AFC
        Exemplo_2AFC = data.Routine(
            name='Exemplo_2AFC',
            components=[image_ex_2AFC, image_ex_target, image_ex_lure, key_ex_2AFC],
        )
        Exemplo_2AFC.status = NOT_STARTED
        continueRoutine = True
        # update component parameters for each repeat
        image_ex_2AFC.setSize(scene_size)
        image_ex_2AFC.setImage(scene_encode)
        image_ex_target.setPos(target_pos)
        image_ex_target.setSize(object_size)
        image_ex_target.setImage(object_encode)
        image_ex_lure.setPos(lure_pos)
        image_ex_lure.setSize(lure_size)
        image_ex_lure.setImage(lure)
        # create starting attributes for key_ex_2AFC
        key_ex_2AFC.keys = []
        key_ex_2AFC.rt = []
        _key_ex_2AFC_allKeys = []
        # store start times for Exemplo_2AFC
        Exemplo_2AFC.tStartRefresh = win.getFutureFlipTime(clock=globalClock)
        Exemplo_2AFC.tStart = globalClock.getTime(format='float')
        Exemplo_2AFC.status = STARTED
        thisExp.addData('Exemplo_2AFC.started', Exemplo_2AFC.tStart)
        Exemplo_2AFC.maxDuration = None
        # keep track of which components have finished
        Exemplo_2AFCComponents = Exemplo_2AFC.components
        for thisComponent in Exemplo_2AFC.components:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        frameN = -1
        
        # --- Run Routine "Exemplo_2AFC" ---
        thisExp.currentRoutine = Exemplo_2AFC
        Exemplo_2AFC.forceEnded = routineForceEnded = not continueRoutine
        while continueRoutine and routineTimer.getTime() < 2.5:
            # if trial has changed, end Routine now
            if hasattr(thisTrial_ex_2AFC, 'status') and thisTrial_ex_2AFC.status == STOPPING:
                continueRoutine = False
            # get current time
            t = routineTimer.getTime()
            tThisFlip = win.getFutureFlipTime(clock=routineTimer)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *image_ex_2AFC* updates
            
            # if image_ex_2AFC is starting this frame...
            if image_ex_2AFC.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                image_ex_2AFC.frameNStart = frameN  # exact frame index
                image_ex_2AFC.tStart = t  # local t and not account for scr refresh
                image_ex_2AFC.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(image_ex_2AFC, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'image_ex_2AFC.started')
                # update status
                image_ex_2AFC.status = STARTED
                image_ex_2AFC.setAutoDraw(True)
            
            # if image_ex_2AFC is active this frame...
            if image_ex_2AFC.status == STARTED:
                # update params
                pass
            
            # if image_ex_2AFC is stopping this frame...
            if image_ex_2AFC.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > image_ex_2AFC.tStartRefresh + 2.5-frameTolerance:
                    # keep track of stop time/frame for later
                    image_ex_2AFC.tStop = t  # not accounting for scr refresh
                    image_ex_2AFC.tStopRefresh = tThisFlipGlobal  # on global time
                    image_ex_2AFC.frameNStop = frameN  # exact frame index
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'image_ex_2AFC.stopped')
                    # update status
                    image_ex_2AFC.status = FINISHED
                    image_ex_2AFC.setAutoDraw(False)
            
            # *image_ex_target* updates
            
            # if image_ex_target is starting this frame...
            if image_ex_target.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                image_ex_target.frameNStart = frameN  # exact frame index
                image_ex_target.tStart = t  # local t and not account for scr refresh
                image_ex_target.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(image_ex_target, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'image_ex_target.started')
                # update status
                image_ex_target.status = STARTED
                image_ex_target.setAutoDraw(True)
            
            # if image_ex_target is active this frame...
            if image_ex_target.status == STARTED:
                # update params
                pass
            
            # if image_ex_target is stopping this frame...
            if image_ex_target.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > image_ex_target.tStartRefresh + 2.5-frameTolerance:
                    # keep track of stop time/frame for later
                    image_ex_target.tStop = t  # not accounting for scr refresh
                    image_ex_target.tStopRefresh = tThisFlipGlobal  # on global time
                    image_ex_target.frameNStop = frameN  # exact frame index
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'image_ex_target.stopped')
                    # update status
                    image_ex_target.status = FINISHED
                    image_ex_target.setAutoDraw(False)
            
            # *image_ex_lure* updates
            
            # if image_ex_lure is starting this frame...
            if image_ex_lure.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                image_ex_lure.frameNStart = frameN  # exact frame index
                image_ex_lure.tStart = t  # local t and not account for scr refresh
                image_ex_lure.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(image_ex_lure, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'image_ex_lure.started')
                # update status
                image_ex_lure.status = STARTED
                image_ex_lure.setAutoDraw(True)
            
            # if image_ex_lure is active this frame...
            if image_ex_lure.status == STARTED:
                # update params
                pass
            
            # if image_ex_lure is stopping this frame...
            if image_ex_lure.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > image_ex_lure.tStartRefresh + 2.5-frameTolerance:
                    # keep track of stop time/frame for later
                    image_ex_lure.tStop = t  # not accounting for scr refresh
                    image_ex_lure.tStopRefresh = tThisFlipGlobal  # on global time
                    image_ex_lure.frameNStop = frameN  # exact frame index
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'image_ex_lure.stopped')
                    # update status
                    image_ex_lure.status = FINISHED
                    image_ex_lure.setAutoDraw(False)
            
            # *key_ex_2AFC* updates
            waitOnFlip = False
            
            # if key_ex_2AFC is starting this frame...
            if key_ex_2AFC.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                key_ex_2AFC.frameNStart = frameN  # exact frame index
                key_ex_2AFC.tStart = t  # local t and not account for scr refresh
                key_ex_2AFC.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(key_ex_2AFC, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'key_ex_2AFC.started')
                # update status
                key_ex_2AFC.status = STARTED
                # keyboard checking is just starting
                waitOnFlip = True
                win.callOnFlip(key_ex_2AFC.clock.reset)  # t=0 on next screen flip
                win.callOnFlip(key_ex_2AFC.clearEvents, eventType='keyboard')  # clear events on next screen flip
            
            # if key_ex_2AFC is stopping this frame...
            if key_ex_2AFC.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > key_ex_2AFC.tStartRefresh + 2.5-frameTolerance:
                    # keep track of stop time/frame for later
                    key_ex_2AFC.tStop = t  # not accounting for scr refresh
                    key_ex_2AFC.tStopRefresh = tThisFlipGlobal  # on global time
                    key_ex_2AFC.frameNStop = frameN  # exact frame index
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'key_ex_2AFC.stopped')
                    # update status
                    key_ex_2AFC.status = FINISHED
                    key_ex_2AFC.status = FINISHED
            if key_ex_2AFC.status == STARTED and not waitOnFlip:
                theseKeys = key_ex_2AFC.getKeys(keyList=['up','down'], ignoreKeys=["escape"], waitRelease=False)
                _key_ex_2AFC_allKeys.extend(theseKeys)
                if len(_key_ex_2AFC_allKeys):
                    key_ex_2AFC.keys = [key.name for key in _key_ex_2AFC_allKeys]  # storing all keys
                    key_ex_2AFC.rt = [key.rt for key in _key_ex_2AFC_allKeys]
                    key_ex_2AFC.duration = [key.duration for key in _key_ex_2AFC_allKeys]
            
            # check for quit (typically the Esc key)
            if defaultKeyboard.getKeys(keyList=["escape"]):
                thisExp.status = FINISHED
            if thisExp.status == FINISHED or endExpNow:
                endExperiment(thisExp, win=win)
                return
            # pause experiment here if requested
            if thisExp.status == PAUSED:
                pauseExperiment(
                    thisExp=thisExp, 
                    win=win, 
                    timers=[routineTimer, globalClock], 
                    currentRoutine=Exemplo_2AFC,
                )
                # skip the frame we paused on
                continue
            
            # has a Component requested the Routine to end?
            if not continueRoutine:
                Exemplo_2AFC.forceEnded = routineForceEnded = True
            # has the Routine been forcibly ended?
            if Exemplo_2AFC.forceEnded or routineForceEnded:
                break
            # has every Component finished?
            continueRoutine = False
            for thisComponent in Exemplo_2AFC.components:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # --- Ending Routine "Exemplo_2AFC" ---
        for thisComponent in Exemplo_2AFC.components:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        # store stop times for Exemplo_2AFC
        Exemplo_2AFC.tStop = globalClock.getTime(format='float')
        Exemplo_2AFC.tStopRefresh = tThisFlipGlobal
        thisExp.addData('Exemplo_2AFC.stopped', Exemplo_2AFC.tStop)
        # check responses
        if key_ex_2AFC.keys in ['', [], None]:  # No response was made
            key_ex_2AFC.keys = None
        trial_ex_2AFC.addData('key_ex_2AFC.keys',key_ex_2AFC.keys)
        if key_ex_2AFC.keys != None:  # we had a response
            trial_ex_2AFC.addData('key_ex_2AFC.rt', key_ex_2AFC.rt)
            trial_ex_2AFC.addData('key_ex_2AFC.duration', key_ex_2AFC.duration)
        # using non-slip timing so subtract the expected duration of this Routine (unless ended on request)
        if Exemplo_2AFC.maxDurationReached:
            routineTimer.addTime(-Exemplo_2AFC.maxDuration)
        elif Exemplo_2AFC.forceEnded:
            routineTimer.reset()
        else:
            routineTimer.addTime(-2.500000)
        
        # --- Prepare to start Routine "blank" ---
        # create an object to store info about Routine blank
        blank = data.Routine(
            name='blank',
            components=[cross_25, image_blank],
        )
        blank.status = NOT_STARTED
        continueRoutine = True
        # update component parameters for each repeat
        # store start times for blank
        blank.tStartRefresh = win.getFutureFlipTime(clock=globalClock)
        blank.tStart = globalClock.getTime(format='float')
        blank.status = STARTED
        thisExp.addData('blank.started', blank.tStart)
        blank.maxDuration = None
        # keep track of which components have finished
        blankComponents = blank.components
        for thisComponent in blank.components:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        frameN = -1
        
        # --- Run Routine "blank" ---
        thisExp.currentRoutine = blank
        blank.forceEnded = routineForceEnded = not continueRoutine
        while continueRoutine and routineTimer.getTime() < 2.5:
            # if trial has changed, end Routine now
            if hasattr(thisTrial_ex_2AFC, 'status') and thisTrial_ex_2AFC.status == STOPPING:
                continueRoutine = False
            # get current time
            t = routineTimer.getTime()
            tThisFlip = win.getFutureFlipTime(clock=routineTimer)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *cross_25* updates
            
            # if cross_25 is starting this frame...
            if cross_25.status == NOT_STARTED and tThisFlip >= 2.25-frameTolerance:
                # keep track of start time/frame for later
                cross_25.frameNStart = frameN  # exact frame index
                cross_25.tStart = t  # local t and not account for scr refresh
                cross_25.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(cross_25, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'cross_25.started')
                # update status
                cross_25.status = STARTED
                cross_25.setAutoDraw(True)
            
            # if cross_25 is active this frame...
            if cross_25.status == STARTED:
                # update params
                pass
            
            # if cross_25 is stopping this frame...
            if cross_25.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > cross_25.tStartRefresh + 0.25-frameTolerance:
                    # keep track of stop time/frame for later
                    cross_25.tStop = t  # not accounting for scr refresh
                    cross_25.tStopRefresh = tThisFlipGlobal  # on global time
                    cross_25.frameNStop = frameN  # exact frame index
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'cross_25.stopped')
                    # update status
                    cross_25.status = FINISHED
                    cross_25.setAutoDraw(False)
            
            # *image_blank* updates
            
            # if image_blank is starting this frame...
            if image_blank.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                image_blank.frameNStart = frameN  # exact frame index
                image_blank.tStart = t  # local t and not account for scr refresh
                image_blank.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(image_blank, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'image_blank.started')
                # update status
                image_blank.status = STARTED
                image_blank.setAutoDraw(True)
            
            # if image_blank is active this frame...
            if image_blank.status == STARTED:
                # update params
                pass
            
            # if image_blank is stopping this frame...
            if image_blank.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > image_blank.tStartRefresh + 2.25-frameTolerance:
                    # keep track of stop time/frame for later
                    image_blank.tStop = t  # not accounting for scr refresh
                    image_blank.tStopRefresh = tThisFlipGlobal  # on global time
                    image_blank.frameNStop = frameN  # exact frame index
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'image_blank.stopped')
                    # update status
                    image_blank.status = FINISHED
                    image_blank.setAutoDraw(False)
            
            # check for quit (typically the Esc key)
            if defaultKeyboard.getKeys(keyList=["escape"]):
                thisExp.status = FINISHED
            if thisExp.status == FINISHED or endExpNow:
                endExperiment(thisExp, win=win)
                return
            # pause experiment here if requested
            if thisExp.status == PAUSED:
                pauseExperiment(
                    thisExp=thisExp, 
                    win=win, 
                    timers=[routineTimer, globalClock], 
                    currentRoutine=blank,
                )
                # skip the frame we paused on
                continue
            
            # has a Component requested the Routine to end?
            if not continueRoutine:
                blank.forceEnded = routineForceEnded = True
            # has the Routine been forcibly ended?
            if blank.forceEnded or routineForceEnded:
                break
            # has every Component finished?
            continueRoutine = False
            for thisComponent in blank.components:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # --- Ending Routine "blank" ---
        for thisComponent in blank.components:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        # store stop times for blank
        blank.tStop = globalClock.getTime(format='float')
        blank.tStopRefresh = tThisFlipGlobal
        thisExp.addData('blank.stopped', blank.tStop)
        # using non-slip timing so subtract the expected duration of this Routine (unless ended on request)
        if blank.maxDurationReached:
            routineTimer.addTime(-blank.maxDuration)
        elif blank.forceEnded:
            routineTimer.reset()
        else:
            routineTimer.addTime(-2.500000)
        # mark thisTrial_ex_2AFC as finished
        if hasattr(thisTrial_ex_2AFC, 'status'):
            thisTrial_ex_2AFC.status = FINISHED
        # if awaiting a pause, pause now
        if trial_ex_2AFC.status == PAUSED:
            thisExp.status = PAUSED
            pauseExperiment(
                thisExp=thisExp, 
                win=win, 
                timers=[globalClock], 
            )
            # once done pausing, restore running status
            trial_ex_2AFC.status = STARTED
        thisExp.nextEntry()
        
    # completed 1.0 repeats of 'trial_ex_2AFC'
    trial_ex_2AFC.status = FINISHED
    
    if thisSession is not None:
        # if running in a Session with a Liaison client, send data up to now
        thisSession.sendExperimentData()
    
    # --- Prepare to start Routine "Start_Recall" ---
    # create an object to store info about Routine Start_Recall
    Start_Recall = data.Routine(
        name='Start_Recall',
        components=[text_start_recall, key_start_recall],
    )
    Start_Recall.status = NOT_STARTED
    continueRoutine = True
    # update component parameters for each repeat
    # create starting attributes for key_start_recall
    key_start_recall.keys = []
    key_start_recall.rt = []
    _key_start_recall_allKeys = []
    # store start times for Start_Recall
    Start_Recall.tStartRefresh = win.getFutureFlipTime(clock=globalClock)
    Start_Recall.tStart = globalClock.getTime(format='float')
    Start_Recall.status = STARTED
    thisExp.addData('Start_Recall.started', Start_Recall.tStart)
    Start_Recall.maxDuration = None
    # keep track of which components have finished
    Start_RecallComponents = Start_Recall.components
    for thisComponent in Start_Recall.components:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    frameN = -1
    
    # --- Run Routine "Start_Recall" ---
    thisExp.currentRoutine = Start_Recall
    Start_Recall.forceEnded = routineForceEnded = not continueRoutine
    while continueRoutine:
        # get current time
        t = routineTimer.getTime()
        tThisFlip = win.getFutureFlipTime(clock=routineTimer)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *text_start_recall* updates
        
        # if text_start_recall is starting this frame...
        if text_start_recall.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            text_start_recall.frameNStart = frameN  # exact frame index
            text_start_recall.tStart = t  # local t and not account for scr refresh
            text_start_recall.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(text_start_recall, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'text_start_recall.started')
            # update status
            text_start_recall.status = STARTED
            text_start_recall.setAutoDraw(True)
        
        # if text_start_recall is active this frame...
        if text_start_recall.status == STARTED:
            # update params
            pass
        
        # *key_start_recall* updates
        waitOnFlip = False
        
        # if key_start_recall is starting this frame...
        if key_start_recall.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            key_start_recall.frameNStart = frameN  # exact frame index
            key_start_recall.tStart = t  # local t and not account for scr refresh
            key_start_recall.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(key_start_recall, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'key_start_recall.started')
            # update status
            key_start_recall.status = STARTED
            # keyboard checking is just starting
            waitOnFlip = True
            win.callOnFlip(key_start_recall.clock.reset)  # t=0 on next screen flip
            win.callOnFlip(key_start_recall.clearEvents, eventType='keyboard')  # clear events on next screen flip
        if key_start_recall.status == STARTED and not waitOnFlip:
            theseKeys = key_start_recall.getKeys(keyList=['y','n','left','right','space'], ignoreKeys=["escape"], waitRelease=False)
            _key_start_recall_allKeys.extend(theseKeys)
            if len(_key_start_recall_allKeys):
                key_start_recall.keys = _key_start_recall_allKeys[-1].name  # just the last key pressed
                key_start_recall.rt = _key_start_recall_allKeys[-1].rt
                key_start_recall.duration = _key_start_recall_allKeys[-1].duration
                # a response ends the routine
                continueRoutine = False
        
        # check for quit (typically the Esc key)
        if defaultKeyboard.getKeys(keyList=["escape"]):
            thisExp.status = FINISHED
        if thisExp.status == FINISHED or endExpNow:
            endExperiment(thisExp, win=win)
            return
        # pause experiment here if requested
        if thisExp.status == PAUSED:
            pauseExperiment(
                thisExp=thisExp, 
                win=win, 
                timers=[routineTimer, globalClock], 
                currentRoutine=Start_Recall,
            )
            # skip the frame we paused on
            continue
        
        # has a Component requested the Routine to end?
        if not continueRoutine:
            Start_Recall.forceEnded = routineForceEnded = True
        # has the Routine been forcibly ended?
        if Start_Recall.forceEnded or routineForceEnded:
            break
        # has every Component finished?
        continueRoutine = False
        for thisComponent in Start_Recall.components:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # --- Ending Routine "Start_Recall" ---
    for thisComponent in Start_Recall.components:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    # store stop times for Start_Recall
    Start_Recall.tStop = globalClock.getTime(format='float')
    Start_Recall.tStopRefresh = tThisFlipGlobal
    thisExp.addData('Start_Recall.stopped', Start_Recall.tStop)
    # check responses
    if key_start_recall.keys in ['', [], None]:  # No response was made
        key_start_recall.keys = None
    thisExp.addData('key_start_recall.keys',key_start_recall.keys)
    if key_start_recall.keys != None:  # we had a response
        thisExp.addData('key_start_recall.rt', key_start_recall.rt)
        thisExp.addData('key_start_recall.duration', key_start_recall.duration)
    thisExp.nextEntry()
    # the Routine "Start_Recall" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # set up handler to look after randomisation of conditions etc
    trial_asso = data.TrialHandler2(
        name='trial_asso',
        nReps=1.0, 
        method='random', 
        extraInfo=expInfo, 
        originPath=-1, 
        trialList=data.importConditions('encode_pairs.xlsx'), 
        seed=None, 
        isTrials=True, 
    )
    thisExp.addLoop(trial_asso)  # add the loop to the experiment
    thisTrial_asso = trial_asso.trialList[0]  # so we can initialise stimuli with some values
    # abbreviate parameter names if possible (e.g. rgb = thisTrial_asso.rgb)
    if thisTrial_asso != None:
        for paramName in thisTrial_asso:
            globals()[paramName] = thisTrial_asso[paramName]
    if thisSession is not None:
        # if running in a Session with a Liaison client, send data up to now
        thisSession.sendExperimentData()
    
    for thisTrial_asso in trial_asso:
        trial_asso.status = STARTED
        if hasattr(thisTrial_asso, 'status'):
            thisTrial_asso.status = STARTED
        currentLoop = trial_asso
        thisExp.timestampOnFlip(win, 'thisRow.t', format=globalClock.format)
        if thisSession is not None:
            # if running in a Session with a Liaison client, send data up to now
            thisSession.sendExperimentData()
        # abbreviate parameter names if possible (e.g. rgb = thisTrial_asso.rgb)
        if thisTrial_asso != None:
            for paramName in thisTrial_asso:
                globals()[paramName] = thisTrial_asso[paramName]
        
        # --- Prepare to start Routine "trial_2AFC" ---
        # create an object to store info about Routine trial_2AFC
        trial_2AFC = data.Routine(
            name='trial_2AFC',
            components=[image_scene_2AFC, key_2AFC, image_target, image_lure],
        )
        trial_2AFC.status = NOT_STARTED
        continueRoutine = True
        # update component parameters for each repeat
        image_scene_2AFC.setSize(scene_size)
        image_scene_2AFC.setImage(scene_encode)
        # create starting attributes for key_2AFC
        key_2AFC.keys = []
        key_2AFC.rt = []
        _key_2AFC_allKeys = []
        image_target.setPos(target_pos)
        image_target.setSize(object_size)
        image_target.setImage(object_encode)
        image_lure.setPos(lure_pos)
        image_lure.setSize(lure_size)
        image_lure.setImage(lure)
        # Run 'Begin Routine' code from code_debug_2AFC
        print(f"trial {trial_asso.thisN}, image = {image_scene_2AFC}")
        print(f"trial {trial_asso.thisN}, image = {image_target}")
        print(f"trial {trial_asso.thisN}, image = {image_lure}")
        # store start times for trial_2AFC
        trial_2AFC.tStartRefresh = win.getFutureFlipTime(clock=globalClock)
        trial_2AFC.tStart = globalClock.getTime(format='float')
        trial_2AFC.status = STARTED
        thisExp.addData('trial_2AFC.started', trial_2AFC.tStart)
        trial_2AFC.maxDuration = None
        # keep track of which components have finished
        trial_2AFCComponents = trial_2AFC.components
        for thisComponent in trial_2AFC.components:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        frameN = -1
        
        # --- Run Routine "trial_2AFC" ---
        thisExp.currentRoutine = trial_2AFC
        trial_2AFC.forceEnded = routineForceEnded = not continueRoutine
        while continueRoutine and routineTimer.getTime() < 2.5:
            # if trial has changed, end Routine now
            if hasattr(thisTrial_asso, 'status') and thisTrial_asso.status == STOPPING:
                continueRoutine = False
            # get current time
            t = routineTimer.getTime()
            tThisFlip = win.getFutureFlipTime(clock=routineTimer)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *image_scene_2AFC* updates
            
            # if image_scene_2AFC is starting this frame...
            if image_scene_2AFC.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                image_scene_2AFC.frameNStart = frameN  # exact frame index
                image_scene_2AFC.tStart = t  # local t and not account for scr refresh
                image_scene_2AFC.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(image_scene_2AFC, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'image_scene_2AFC.started')
                # update status
                image_scene_2AFC.status = STARTED
                image_scene_2AFC.setAutoDraw(True)
            
            # if image_scene_2AFC is active this frame...
            if image_scene_2AFC.status == STARTED:
                # update params
                pass
            
            # if image_scene_2AFC is stopping this frame...
            if image_scene_2AFC.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > image_scene_2AFC.tStartRefresh + 2.5-frameTolerance:
                    # keep track of stop time/frame for later
                    image_scene_2AFC.tStop = t  # not accounting for scr refresh
                    image_scene_2AFC.tStopRefresh = tThisFlipGlobal  # on global time
                    image_scene_2AFC.frameNStop = frameN  # exact frame index
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'image_scene_2AFC.stopped')
                    # update status
                    image_scene_2AFC.status = FINISHED
                    image_scene_2AFC.setAutoDraw(False)
            
            # *key_2AFC* updates
            waitOnFlip = False
            
            # if key_2AFC is starting this frame...
            if key_2AFC.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                key_2AFC.frameNStart = frameN  # exact frame index
                key_2AFC.tStart = t  # local t and not account for scr refresh
                key_2AFC.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(key_2AFC, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'key_2AFC.started')
                # update status
                key_2AFC.status = STARTED
                # keyboard checking is just starting
                waitOnFlip = True
                win.callOnFlip(key_2AFC.clock.reset)  # t=0 on next screen flip
                win.callOnFlip(key_2AFC.clearEvents, eventType='keyboard')  # clear events on next screen flip
            
            # if key_2AFC is stopping this frame...
            if key_2AFC.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > key_2AFC.tStartRefresh + 2.5-frameTolerance:
                    # keep track of stop time/frame for later
                    key_2AFC.tStop = t  # not accounting for scr refresh
                    key_2AFC.tStopRefresh = tThisFlipGlobal  # on global time
                    key_2AFC.frameNStop = frameN  # exact frame index
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'key_2AFC.stopped')
                    # update status
                    key_2AFC.status = FINISHED
                    key_2AFC.status = FINISHED
            if key_2AFC.status == STARTED and not waitOnFlip:
                theseKeys = key_2AFC.getKeys(keyList=['up','down'], ignoreKeys=["escape"], waitRelease=False)
                _key_2AFC_allKeys.extend(theseKeys)
                if len(_key_2AFC_allKeys):
                    key_2AFC.keys = [key.name for key in _key_2AFC_allKeys]  # storing all keys
                    key_2AFC.rt = [key.rt for key in _key_2AFC_allKeys]
                    key_2AFC.duration = [key.duration for key in _key_2AFC_allKeys]
            
            # *image_target* updates
            
            # if image_target is starting this frame...
            if image_target.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                image_target.frameNStart = frameN  # exact frame index
                image_target.tStart = t  # local t and not account for scr refresh
                image_target.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(image_target, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'image_target.started')
                # update status
                image_target.status = STARTED
                image_target.setAutoDraw(True)
            
            # if image_target is active this frame...
            if image_target.status == STARTED:
                # update params
                pass
            
            # if image_target is stopping this frame...
            if image_target.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > image_target.tStartRefresh + 2.5-frameTolerance:
                    # keep track of stop time/frame for later
                    image_target.tStop = t  # not accounting for scr refresh
                    image_target.tStopRefresh = tThisFlipGlobal  # on global time
                    image_target.frameNStop = frameN  # exact frame index
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'image_target.stopped')
                    # update status
                    image_target.status = FINISHED
                    image_target.setAutoDraw(False)
            
            # *image_lure* updates
            
            # if image_lure is starting this frame...
            if image_lure.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                image_lure.frameNStart = frameN  # exact frame index
                image_lure.tStart = t  # local t and not account for scr refresh
                image_lure.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(image_lure, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'image_lure.started')
                # update status
                image_lure.status = STARTED
                image_lure.setAutoDraw(True)
            
            # if image_lure is active this frame...
            if image_lure.status == STARTED:
                # update params
                pass
            
            # if image_lure is stopping this frame...
            if image_lure.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > image_lure.tStartRefresh + 2.5-frameTolerance:
                    # keep track of stop time/frame for later
                    image_lure.tStop = t  # not accounting for scr refresh
                    image_lure.tStopRefresh = tThisFlipGlobal  # on global time
                    image_lure.frameNStop = frameN  # exact frame index
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'image_lure.stopped')
                    # update status
                    image_lure.status = FINISHED
                    image_lure.setAutoDraw(False)
            
            # check for quit (typically the Esc key)
            if defaultKeyboard.getKeys(keyList=["escape"]):
                thisExp.status = FINISHED
            if thisExp.status == FINISHED or endExpNow:
                endExperiment(thisExp, win=win)
                return
            # pause experiment here if requested
            if thisExp.status == PAUSED:
                pauseExperiment(
                    thisExp=thisExp, 
                    win=win, 
                    timers=[routineTimer, globalClock], 
                    currentRoutine=trial_2AFC,
                )
                # skip the frame we paused on
                continue
            
            # has a Component requested the Routine to end?
            if not continueRoutine:
                trial_2AFC.forceEnded = routineForceEnded = True
            # has the Routine been forcibly ended?
            if trial_2AFC.forceEnded or routineForceEnded:
                break
            # has every Component finished?
            continueRoutine = False
            for thisComponent in trial_2AFC.components:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # --- Ending Routine "trial_2AFC" ---
        for thisComponent in trial_2AFC.components:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        # store stop times for trial_2AFC
        trial_2AFC.tStop = globalClock.getTime(format='float')
        trial_2AFC.tStopRefresh = tThisFlipGlobal
        thisExp.addData('trial_2AFC.stopped', trial_2AFC.tStop)
        # check responses
        if key_2AFC.keys in ['', [], None]:  # No response was made
            key_2AFC.keys = None
        trial_asso.addData('key_2AFC.keys',key_2AFC.keys)
        if key_2AFC.keys != None:  # we had a response
            trial_asso.addData('key_2AFC.rt', key_2AFC.rt)
            trial_asso.addData('key_2AFC.duration', key_2AFC.duration)
        # using non-slip timing so subtract the expected duration of this Routine (unless ended on request)
        if trial_2AFC.maxDurationReached:
            routineTimer.addTime(-trial_2AFC.maxDuration)
        elif trial_2AFC.forceEnded:
            routineTimer.reset()
        else:
            routineTimer.addTime(-2.500000)
        
        # --- Prepare to start Routine "blank" ---
        # create an object to store info about Routine blank
        blank = data.Routine(
            name='blank',
            components=[cross_25, image_blank],
        )
        blank.status = NOT_STARTED
        continueRoutine = True
        # update component parameters for each repeat
        # store start times for blank
        blank.tStartRefresh = win.getFutureFlipTime(clock=globalClock)
        blank.tStart = globalClock.getTime(format='float')
        blank.status = STARTED
        thisExp.addData('blank.started', blank.tStart)
        blank.maxDuration = None
        # keep track of which components have finished
        blankComponents = blank.components
        for thisComponent in blank.components:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        frameN = -1
        
        # --- Run Routine "blank" ---
        thisExp.currentRoutine = blank
        blank.forceEnded = routineForceEnded = not continueRoutine
        while continueRoutine and routineTimer.getTime() < 2.5:
            # if trial has changed, end Routine now
            if hasattr(thisTrial_asso, 'status') and thisTrial_asso.status == STOPPING:
                continueRoutine = False
            # get current time
            t = routineTimer.getTime()
            tThisFlip = win.getFutureFlipTime(clock=routineTimer)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *cross_25* updates
            
            # if cross_25 is starting this frame...
            if cross_25.status == NOT_STARTED and tThisFlip >= 2.25-frameTolerance:
                # keep track of start time/frame for later
                cross_25.frameNStart = frameN  # exact frame index
                cross_25.tStart = t  # local t and not account for scr refresh
                cross_25.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(cross_25, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'cross_25.started')
                # update status
                cross_25.status = STARTED
                cross_25.setAutoDraw(True)
            
            # if cross_25 is active this frame...
            if cross_25.status == STARTED:
                # update params
                pass
            
            # if cross_25 is stopping this frame...
            if cross_25.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > cross_25.tStartRefresh + 0.25-frameTolerance:
                    # keep track of stop time/frame for later
                    cross_25.tStop = t  # not accounting for scr refresh
                    cross_25.tStopRefresh = tThisFlipGlobal  # on global time
                    cross_25.frameNStop = frameN  # exact frame index
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'cross_25.stopped')
                    # update status
                    cross_25.status = FINISHED
                    cross_25.setAutoDraw(False)
            
            # *image_blank* updates
            
            # if image_blank is starting this frame...
            if image_blank.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                image_blank.frameNStart = frameN  # exact frame index
                image_blank.tStart = t  # local t and not account for scr refresh
                image_blank.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(image_blank, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'image_blank.started')
                # update status
                image_blank.status = STARTED
                image_blank.setAutoDraw(True)
            
            # if image_blank is active this frame...
            if image_blank.status == STARTED:
                # update params
                pass
            
            # if image_blank is stopping this frame...
            if image_blank.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > image_blank.tStartRefresh + 2.25-frameTolerance:
                    # keep track of stop time/frame for later
                    image_blank.tStop = t  # not accounting for scr refresh
                    image_blank.tStopRefresh = tThisFlipGlobal  # on global time
                    image_blank.frameNStop = frameN  # exact frame index
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'image_blank.stopped')
                    # update status
                    image_blank.status = FINISHED
                    image_blank.setAutoDraw(False)
            
            # check for quit (typically the Esc key)
            if defaultKeyboard.getKeys(keyList=["escape"]):
                thisExp.status = FINISHED
            if thisExp.status == FINISHED or endExpNow:
                endExperiment(thisExp, win=win)
                return
            # pause experiment here if requested
            if thisExp.status == PAUSED:
                pauseExperiment(
                    thisExp=thisExp, 
                    win=win, 
                    timers=[routineTimer, globalClock], 
                    currentRoutine=blank,
                )
                # skip the frame we paused on
                continue
            
            # has a Component requested the Routine to end?
            if not continueRoutine:
                blank.forceEnded = routineForceEnded = True
            # has the Routine been forcibly ended?
            if blank.forceEnded or routineForceEnded:
                break
            # has every Component finished?
            continueRoutine = False
            for thisComponent in blank.components:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # --- Ending Routine "blank" ---
        for thisComponent in blank.components:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        # store stop times for blank
        blank.tStop = globalClock.getTime(format='float')
        blank.tStopRefresh = tThisFlipGlobal
        thisExp.addData('blank.stopped', blank.tStop)
        # using non-slip timing so subtract the expected duration of this Routine (unless ended on request)
        if blank.maxDurationReached:
            routineTimer.addTime(-blank.maxDuration)
        elif blank.forceEnded:
            routineTimer.reset()
        else:
            routineTimer.addTime(-2.500000)
        # mark thisTrial_asso as finished
        if hasattr(thisTrial_asso, 'status'):
            thisTrial_asso.status = FINISHED
        # if awaiting a pause, pause now
        if trial_asso.status == PAUSED:
            thisExp.status = PAUSED
            pauseExperiment(
                thisExp=thisExp, 
                win=win, 
                timers=[globalClock], 
            )
            # once done pausing, restore running status
            trial_asso.status = STARTED
        thisExp.nextEntry()
        
    # completed 1.0 repeats of 'trial_asso'
    trial_asso.status = FINISHED
    
    if thisSession is not None:
        # if running in a Session with a Liaison client, send data up to now
        thisSession.sendExperimentData()
    
    # --- Prepare to start Routine "end" ---
    # create an object to store info about Routine end
    end = data.Routine(
        name='end',
        components=[text_end],
    )
    end.status = NOT_STARTED
    continueRoutine = True
    # update component parameters for each repeat
    # store start times for end
    end.tStartRefresh = win.getFutureFlipTime(clock=globalClock)
    end.tStart = globalClock.getTime(format='float')
    end.status = STARTED
    thisExp.addData('end.started', end.tStart)
    end.maxDuration = None
    # keep track of which components have finished
    endComponents = end.components
    for thisComponent in end.components:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    frameN = -1
    
    # --- Run Routine "end" ---
    thisExp.currentRoutine = end
    end.forceEnded = routineForceEnded = not continueRoutine
    while continueRoutine and routineTimer.getTime() < 10.0:
        # get current time
        t = routineTimer.getTime()
        tThisFlip = win.getFutureFlipTime(clock=routineTimer)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *text_end* updates
        
        # if text_end is starting this frame...
        if text_end.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            text_end.frameNStart = frameN  # exact frame index
            text_end.tStart = t  # local t and not account for scr refresh
            text_end.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(text_end, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'text_end.started')
            # update status
            text_end.status = STARTED
            text_end.setAutoDraw(True)
        
        # if text_end is active this frame...
        if text_end.status == STARTED:
            # update params
            pass
        
        # if text_end is stopping this frame...
        if text_end.status == STARTED:
            # is it time to stop? (based on global clock, using actual start)
            if tThisFlipGlobal > text_end.tStartRefresh + 10.0-frameTolerance:
                # keep track of stop time/frame for later
                text_end.tStop = t  # not accounting for scr refresh
                text_end.tStopRefresh = tThisFlipGlobal  # on global time
                text_end.frameNStop = frameN  # exact frame index
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'text_end.stopped')
                # update status
                text_end.status = FINISHED
                text_end.setAutoDraw(False)
        
        # check for quit (typically the Esc key)
        if defaultKeyboard.getKeys(keyList=["escape"]):
            thisExp.status = FINISHED
        if thisExp.status == FINISHED or endExpNow:
            endExperiment(thisExp, win=win)
            return
        # pause experiment here if requested
        if thisExp.status == PAUSED:
            pauseExperiment(
                thisExp=thisExp, 
                win=win, 
                timers=[routineTimer, globalClock], 
                currentRoutine=end,
            )
            # skip the frame we paused on
            continue
        
        # has a Component requested the Routine to end?
        if not continueRoutine:
            end.forceEnded = routineForceEnded = True
        # has the Routine been forcibly ended?
        if end.forceEnded or routineForceEnded:
            break
        # has every Component finished?
        continueRoutine = False
        for thisComponent in end.components:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # --- Ending Routine "end" ---
    for thisComponent in end.components:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    # store stop times for end
    end.tStop = globalClock.getTime(format='float')
    end.tStopRefresh = tThisFlipGlobal
    thisExp.addData('end.stopped', end.tStop)
    # using non-slip timing so subtract the expected duration of this Routine (unless ended on request)
    if end.maxDurationReached:
        routineTimer.addTime(-end.maxDuration)
    elif end.forceEnded:
        routineTimer.reset()
    else:
        routineTimer.addTime(-10.000000)
    thisExp.nextEntry()
    
    # mark experiment as finished
    endExperiment(thisExp, win=win)


def saveData(thisExp):
    """
    Save data from this experiment
    
    Parameters
    ==========
    thisExp : psychopy.data.ExperimentHandler
        Handler object for this experiment, contains the data to save and information about 
        where to save it to.
    """
    filename = thisExp.dataFileName
    # these shouldn't be strictly necessary (should auto-save)
    thisExp.saveAsWideText(filename + '.csv', delim='auto')
    thisExp.saveAsPickle(filename)


def endExperiment(thisExp, win=None):
    """
    End this experiment, performing final shut down operations.
    
    This function does NOT close the window or end the Python process - use `quit` for this.
    
    Parameters
    ==========
    thisExp : psychopy.data.ExperimentHandler
        Handler object for this experiment, contains the data to save and information about 
        where to save it to.
    win : psychopy.visual.Window
        Window for this experiment.
    """
    if win is not None:
        # remove autodraw from all current components
        win.clearAutoDraw()
        # Flip one final time so any remaining win.callOnFlip() 
        # and win.timeOnFlip() tasks get executed
        win.flip()
    # return console logger level to WARNING
    logging.console.setLevel(logging.WARNING)
    # mark experiment handler as finished
    thisExp.status = FINISHED
    # run any 'at exit' functions
    for fcn in runAtExit:
        fcn()
    logging.flush()


def quit(thisExp, win=None, thisSession=None):
    """
    Fully quit, closing the window and ending the Python process.
    
    Parameters
    ==========
    win : psychopy.visual.Window
        Window to close.
    thisSession : psychopy.session.Session or None
        Handle of the Session object this experiment is being run from, if any.
    """
    thisExp.abort()  # or data files will save again on exit
    # make sure everything is closed down
    if win is not None:
        # Flip one final time so any remaining win.callOnFlip() 
        # and win.timeOnFlip() tasks get executed before quitting
        win.flip()
        win.close()
    logging.flush()
    if thisSession is not None:
        thisSession.stop()
    # terminate Python process
    core.quit()


# if running this experiment as a script...
if __name__ == '__main__':
    # call all functions in order
    expInfo = showExpInfoDlg(expInfo=expInfo)
    thisExp = setupData(expInfo=expInfo)
    logFile = setupLogging(filename=thisExp.dataFileName)
    win = setupWindow(expInfo=expInfo)
    setupDevices(expInfo=expInfo, thisExp=thisExp, win=win)
    run(
        expInfo=expInfo, 
        thisExp=thisExp, 
        win=win,
        globalClock='float'
    )
    saveData(thisExp=thisExp)
    quit(thisExp=thisExp, win=win)
